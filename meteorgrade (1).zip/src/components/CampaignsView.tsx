import React, { useState, useEffect } from 'react';
import { db } from '../lib/db';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, deleteDoc, doc, updateDoc } from '../lib/db';
import { Calendar, Plus, Target, CheckCircle2, Clock, MapPin, ChevronRight, HelpCircle, X, Shield, Activity, Zap, Lock, Trash2, Settings, RefreshCw, Database, Terminal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getMissionTelemetry } from '../services/geminiService';

interface CampaignsViewProps {
  user: any;
  forecasts: any[];
}

export default function CampaignsView({ user, forecasts }: CampaignsViewProps) {
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<'active' | 'archives'>('active');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [telemetryData, setTelemetryData] = useState<any | null>(null);
  const [isGeneratingTelemetry, setIsGeneratingTelemetry] = useState(false);
  const [newCampaign, setNewCampaign] = useState({ title: '', startDate: '', endDate: '', description: '', isGlobal: false });

  useEffect(() => {
    // Listen for personal and global campaigns
    const q = query(collection(db, 'missions'));
    const unsubscribeCampaigns = onSnapshot(q, (snapshot) => {
      const allMissions = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      const isAdmin = user.role === 'admin' || user.email?.toLowerCase() === 'tylerleedixon@gmail.com';
      
      const filtered = allMissions.filter((m: any) => 
        isAdmin ||
        (m.user_id === user.uid || m.userId === user.uid) || 
        (m.is_global === true || m.isGlobal === true)
      );
      setCampaigns(filtered);
    }, (err) => console.error("Campaigns Listener Error:", err));

    return () => {
      unsubscribeCampaigns();
    };
  }, [user.uid]);

  const getForecastsForCampaign = (campaign: any) => {
    return forecasts.filter(f => {
      const forecastDate = new Date(f.targetDate);
      const start = new Date(campaign.start_date || campaign.startDate);
      const end = new Date(campaign.end_date || campaign.endDate);
      return forecastDate >= start && forecastDate <= end;
    });
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const isAdmin = user.role === 'admin' || user.email?.toLowerCase() === 'tylerleedixon@gmail.com';
      const isGlobal = isAdmin ? newCampaign.isGlobal : false;
      
      console.log("[MISSIONS] Creating mission with is_global:", isGlobal, "User:", user.email, "IsAdmin:", isAdmin);

      const missionData = {
        title: newCampaign.title,
        description: newCampaign.description,
        start_date: newCampaign.startDate,
        end_date: newCampaign.endDate,
        user_id: user.uid,
        userId: user.uid,
        status: 'active',
        is_global: isGlobal,
        isGlobal: isGlobal,
        global_id: isGlobal ? (newCampaign.title.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + Date.now()) : null,
        createdAt: serverTimestamp()
      };

      console.log("[MISSIONS] Final mission data payload:", missionData);

      await addDoc(collection(db, 'missions'), missionData);
      setShowCreate(false);
      setNewCampaign({ title: '', startDate: '', endDate: '', description: '', isGlobal: false });
    } catch (err) {
      console.error("[MISSIONS] Create Error:", err);
    }
  };

  const handleDelete = async (missionId: string, isGlobal: boolean) => {
    const isAdmin = user.role === 'admin' || user.email?.toLowerCase() === 'tylerleedixon@gmail.com';
    console.log(`[MISSIONS] DELETION_FINALIZE: ID=${missionId}, IsGlobal=${isGlobal}, AdminAccess=${isAdmin}`);

    try {
      console.log(`[MISSIONS] DELETION_EXECUTING: Target=${missionId}, User=${user.uid}`);
      
      // Optimistic update: Remove from local state immediately for instant feedback
      setCampaigns(prev => prev.filter(c => c.id !== missionId));

      if (selectedCampaign?.id === missionId) {
        setSelectedCampaign(null);
      }
      
      await deleteDoc(doc(db, 'missions', missionId));
      console.log("[MISSIONS] DELETION_SUCCESS: Remote entry purged.");
      setDeletingId(null);
    } catch (err: any) {
      console.error("[MISSIONS] DELETION_FAILURE:", err);
      if (err.message?.includes('not found') || err.code === 'PGRST116') {
        setDeletingId(null);
        return;
      }
      alert(`Decommissioning Failed: ${err.message || "Uplink timed out"}`);
    }
  };

  const handleUpdateStatus = async (missionId: string, status: 'active' | 'completed', isReviewed?: boolean) => {
    const isAdmin = user.role === 'admin' || user.email?.toLowerCase() === 'tylerleedixon@gmail.com';
    const mission = campaigns.find(c => c.id === missionId);
    const isGlobal = mission?.is_global || mission?.isGlobal;

    if (isGlobal && !isAdmin) {
      alert("Unauthorized: Only administrators can adjust global mission parameters.");
      return;
    }

    const updates: any = { status };
    if (typeof isReviewed === 'boolean') {
      updates.is_reviewed = isReviewed;
      updates.isReviewed = isReviewed;
    }

    try {
      await updateDoc(doc(db, 'missions', missionId), updates);
      if (selectedCampaign?.id === missionId) {
        setSelectedCampaign({ ...selectedCampaign, ...updates });
      }
    } catch (err) {
      console.error("[MISSIONS] Status Update Error:", err);
      alert("Failed to update mission parameters.");
    }
  };

  const handleInitializeArchive = async () => {
    if (!selectedCampaign) return;
    setIsGeneratingTelemetry(true);
    setTelemetryData(null);
    try {
      const data = await getMissionTelemetry(selectedCampaign);
      setTelemetryData(data);
    } catch (err: any) {
      console.error("Telemetry Error:", err);
      alert(err.message || "Uplink Error");
    } finally {
      setIsGeneratingTelemetry(false);
    }
  };

  const filteredCampaigns = campaigns.filter(c => {
    if (activeTab === 'active') return c.status === 'active';
    return c.status === 'completed';
  });

  return (
    <div className="space-y-12">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Mission Intelligence</span>
            <button 
              onClick={() => setShowTutorial(true)}
              className="flex items-center gap-1.5 text-[9px] font-bold theme-text-muted uppercase tracking-widest hover:text-indigo-600 transition-colors"
            >
              <HelpCircle size={12} /> Strategic Mission Guide
            </button>
          </div>
          <h2 className="text-2xl md:text-4xl font-light uppercase tracking-tighter mt-1 theme-text-primary">Strategic <span className="font-bold">Missions</span></h2>
        </div>
        <div className="flex items-center gap-4 w-full sm:w-auto">
          <div className="flex theme-bg-secondary p-1 font-bold text-[9px] uppercase tracking-widest border theme-border">
            <button 
              onClick={() => setActiveTab('active')}
              className={`px-4 py-2 transition-all ${activeTab === 'active' ? 'theme-bg-primary shadow-sm text-indigo-600 dark:text-indigo-400' : 'theme-text-muted hover:theme-text-secondary'}`}
            >
              Active Operations
            </button>
            <button 
              onClick={() => setActiveTab('archives')}
              className={`px-4 py-2 transition-all ${activeTab === 'archives' ? 'theme-bg-primary shadow-sm text-indigo-600 dark:text-indigo-400' : 'theme-text-muted hover:theme-text-secondary'}`}
            >
              Historical Archives
            </button>
          </div>
          <button 
            onClick={() => setShowCreate(true)}
            className="flex-1 sm:flex-none bg-slate-900 dark:bg-indigo-600 text-white p-4 hover:opacity-80 transition-all flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest shadow-lg"
          >
            <Plus size={16} /> Deploy New Mission
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {filteredCampaigns.map((campaign) => {
          const campaignForecasts = getForecastsForCampaign(campaign);
          const completedCount = campaignForecasts.filter(f => f.status === 'completed').length;
          
            return (
            <motion.div 
              key={campaign.id}
              layout
              className="group theme-bg-secondary border theme-border p-8 hover:border-slate-900 dark:hover:border-indigo-400 transition-all cursor-pointer relative overflow-hidden h-full flex flex-col justify-between theme-shadow"
              onClick={(e) => {
                if ((e.target as HTMLElement).closest('.admin-action')) return;
                setSelectedCampaign(campaign);
              }}
            >
              {deletingId === campaign.id && (
                <div className="absolute inset-0 z-50 bg-red-600 text-white p-6 flex flex-col justify-center items-center text-center space-y-4 animate-in fade-in slide-in-from-bottom-4">
                  <Trash2 size={32} className="animate-bounce" />
                  <div className="space-y-1">
                    <p className="text-[10px] font-black uppercase tracking-widest">Confirm Decommission</p>
                    <p className="text-[8px] opacity-80 uppercase tracking-widest leading-relaxed">This operational data will be permanently purged.</p>
                  </div>
                  <div className="flex gap-2 w-full pt-2">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeletingId(null);
                      }}
                      className="flex-1 py-3 border border-white/30 text-[9px] font-bold uppercase tracking-widest hover:bg-white/10 transition-all"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(campaign.id, !!(campaign.is_global || campaign.isGlobal));
                      }}
                      className="flex-1 py-3 bg-white text-red-600 text-[9px] font-bold uppercase tracking-widest hover:theme-bg-primary transition-all shadow-lg"
                    >
                      Purge
                    </button>
                  </div>
                </div>
              )}
              <div className="space-y-6">
                {/* Status & Action Eyebrow */}
                <div className="flex justify-between items-start">
                  <div className="flex flex-wrap gap-2">
                    {(campaign.is_global || campaign.isGlobal) && (
                      <span className="flex items-center gap-1.5 px-2 py-0.5 bg-red-600 text-white text-[8px] font-bold uppercase tracking-widest animate-pulse">
                        <Zap size={10} fill="currentColor" /> Live Bureau Operation
                      </span>
                    )}
                    {(campaign.is_reviewed || campaign.isReviewed) && (
                      <div className="px-2 py-0.5 theme-bg-success border theme-border theme-text-success text-[8px] font-black uppercase tracking-widest flex items-center gap-1">
                        <CheckCircle2 size={10} /> Intelligence Verified
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-3">
                    {(user.role === 'admin' || user.email?.toLowerCase() === 'tylerleedixon@gmail.com' || campaign.user_id === user.uid || campaign.userId === user.uid) && (
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeletingId(campaign.id);
                        }}
                        className="admin-action p-1.5 theme-text-muted hover:text-red-600 transition-colors theme-bg-app rounded-full border theme-border hover:theme-border"
                        title="Decommission Mission"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                    <div className={campaign.status === 'active' ? 'text-indigo-600 dark:text-indigo-400' : 'text-emerald-600 dark:text-emerald-400'}>
                      {campaign.status === 'active' ? <Clock size={18} /> : <CheckCircle2 size={18} />}
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-xl font-bold uppercase tracking-tight leading-tight theme-text-primary">{campaign.title}</h3>
                  <p className="text-xs theme-text-muted mt-1 uppercase tracking-widest leading-relaxed">
                    {campaign.start_date || campaign.startDate} → {campaign.end_date || campaign.endDate}
                  </p>
                </div>

                <p className="text-sm theme-text-secondary leading-relaxed max-w-md line-clamp-3">
                  {campaign.description || "Operational parameters established. Awaiting sensor synchronization and historical verification telemetry for this session window."}
                </p>

                <div className="flex items-center justify-between pt-6 border-t theme-border">
                  <div className="flex gap-4">
                    <div className="flex flex-col">
                      <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest">Forecast Points</span>
                      <span className="text-xs font-mono">{campaignForecasts.length} Units</span>
                    </div>
                    <div className="flex flex-col border-l theme-border pl-4">
                      <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest">Progress</span>
                      <span className="text-xs font-mono">{completedCount}/{campaignForecasts.length || '-'} Verified</span>
                    </div>
                  </div>
                  <div className="w-10 h-10 border theme-border flex items-center justify-center group-hover:bg-slate-900 dark:group-hover:bg-indigo-600 group-hover:text-white transition-all">
                    <ChevronRight size={18} />
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}

        {filteredCampaigns.length === 0 && !showCreate && (
          <div className="md:col-span-2 border-2 border-dashed theme-border p-20 flex flex-col items-center justify-center space-y-4 theme-bg-secondary">
            <Target size={40} className="theme-text-muted opacity-20" />
            <p className="text-xs font-bold uppercase tracking-[0.2em] theme-text-muted">No {activeTab} Missions Found</p>
            {activeTab === 'active' && (
              <button 
                onClick={() => setShowCreate(true)}
                className="theme-text-success text-[10px] font-bold uppercase border-b theme-border pb-1 hover:opacity-80 transition-opacity"
              >
                Initialize First Campaign
              </button>
            )}
          </div>
        )}
      </div>

      <AnimatePresence>
        {/* Campaign Detail Modal */}
        {selectedCampaign && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedCampaign(null)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="theme-bg-secondary max-w-3xl w-full max-h-[85vh] overflow-y-auto theme-shadow border theme-border relative z-10 flex flex-col"
            >
              <div className="p-8 md:p-12 border-b theme-border">
                <div className="flex justify-between items-start mb-8">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Campaign Summary</span>
                    <h3 className="text-3xl font-light uppercase tracking-tighter theme-text-primary">{selectedCampaign.title}</h3>
                    <p className="text-sm theme-text-muted font-mono">{(selectedCampaign.start_date || selectedCampaign.startDate)} → {(selectedCampaign.end_date || selectedCampaign.endDate)}</p>
                  </div>
                  <button onClick={() => setSelectedCampaign(null)} className="theme-text-muted hover:theme-text-primary transition-colors">
                    <X size={24} />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="space-y-2">
                    <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest">Status Report</span>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${selectedCampaign.status === 'active' ? 'bg-indigo-600 animate-pulse' : 'bg-emerald-500'}`} />
                      <span className="text-xs font-bold uppercase tracking-widest theme-text-primary">{selectedCampaign.status}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest">Data Streams</span>
                    <p className="text-xs font-bold theme-text-primary uppercase tracking-tighter">{getForecastsForCampaign(selectedCampaign).length} Forecasts Linked</p>
                  </div>
                  <div className="space-y-2">
                    <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest">Campaign Objective</span>
                    <p className="text-xs font-bold theme-text-primary uppercase tracking-tighter">Atmospheric Synchronization</p>
                  </div>
                </div>
              </div>

              <div className="p-8 md:p-12 theme-bg-primary flex-1">
                <div className="space-y-8">
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-bold theme-text-primary uppercase tracking-widest flex items-center gap-2">
                      <Shield size={14} className="text-indigo-600 dark:text-indigo-400" /> Campaign Description
                    </h4>
                    <p className="text-sm theme-text-secondary leading-relaxed italic border-l-2 border-indigo-500 pl-4 py-2 bg-indigo-500/5">
                      "{selectedCampaign.description || "No campaign description provided. Accumulating atmospheric data points for regional window."}"
                    </p>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold theme-text-primary uppercase tracking-widest flex items-center gap-2">
                      <Shield size={14} className="text-indigo-600 dark:text-indigo-400" /> Operational Assets & Telemetry
                    </h4>
                    
                    {user.membership === 'pro' ? (
                      <div className="theme-bg-secondary border theme-border overflow-hidden theme-shadow">
                        <div className="p-6 space-y-4">
                          <div className="flex items-center justify-between">
                            <p className="text-[10px] font-bold uppercase tracking-widest theme-text-primary">High-Fidelity Telemetry Archive</p>
                            <span className="text-[9px] px-2 py-0.5 theme-bg-success theme-text-success font-bold uppercase tracking-widest">Active Link</span>
                          </div>
                          
                          {!telemetryData ? (
                            <>
                              <p className="text-xs theme-text-secondary leading-relaxed">
                                Access full-resolution satellite sensor data and raw atmospheric sounding logs synthesized directly from operational archives for this mission window.
                              </p>
                              <button 
                                onClick={handleInitializeArchive}
                                disabled={isGeneratingTelemetry}
                                className="w-full py-4 border-2 theme-border theme-text-primary text-[10px] font-bold uppercase tracking-widest hover:bg-slate-900 hover:text-white dark:hover:bg-indigo-600 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                              >
                                {isGeneratingTelemetry ? (
                                  <>
                                    <RefreshCw size={14} className="animate-spin" /> RETRIEVING VERIFIED TELEMETRY...
                                  </>
                                ) : (
                                  <>
                                    <Database size={14} /> Synchronize Intelligence Archive
                                  </>
                                )}
                              </button>
                            </>
                          ) : (
                            <div className="animate-in fade-in zoom-in duration-300 space-y-6">
                              <div className="p-3 sm:p-4 bg-slate-900 text-emerald-400 font-mono text-[10px] leading-relaxed border-l-4 border-emerald-500 overflow-hidden">
                                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 text-slate-100 border-b border-slate-800 pb-2 gap-2">
                                  <div className="flex items-center gap-2">
                                    <Terminal size={12} className="shrink-0" />
                                    <span className="uppercase tracking-widest font-bold text-[9px] sm:text-[10px] break-all sm:break-normal">ATMOSPHERIC_LOGS // {telemetryData.status}</span>
                                  </div>
                                  <span className="text-[8px] opacity-40 tabular-nums shrink-0">UTC_TIME_STAMP: {new Date().toISOString().slice(11, 19)}Z</span>
                                </div>
                                <div className="space-y-2 h-64 overflow-y-auto custom-scrollbar pr-2">
                                  {telemetryData.findings.map((log: string, idx: number) => (
                                    <div key={idx} className="flex gap-2">
                                      <span className="text-emerald-800 tabular-nums">[{idx + 1}]</span>
                                      <p className="opacity-80 italic tracking-tight">{log}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              <div className="grid grid-cols-1 gap-2">
                                {Object.entries(telemetryData.dataPoints).map(([key, value]: [string, any]) => (
                                  <div key={key} className="p-4 theme-bg-app border theme-border group hover:border-indigo-600 transition-colors">
                                    <p className="text-[8px] font-bold theme-text-muted uppercase tracking-widest mb-1 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{key.replace(/_/g, ' ')}</p>
                                    <p className="text-[11px] font-black theme-text-primary leading-normal">{value}</p>
                                  </div>
                                ))}
                              </div>

                              <div className="p-5 theme-bg-success theme-text-success border theme-border italic text-[11px] leading-relaxed font-medium">
                                <span className="block font-bold uppercase not-italic mb-2 text-[9px] theme-text-success tracking-widest border-b border-green-500/20 pb-1">Operational Synthesis:</span> 
                                {telemetryData.summary}
                              </div>

                              <div className="flex items-center gap-4">
                                <button 
                                  onClick={() => setTelemetryData(null)}
                                  className="flex-1 py-3 text-[9px] font-bold theme-text-muted uppercase tracking-widest hover:theme-text-primary transition-colors border theme-border hover:border-indigo-500"
                                >
                                  Reset Uplink
                                </button>
                                <div className="text-[8px] font-bold theme-text-success uppercase tracking-widest flex items-center gap-1">
                                  <Shield size={10} /> Data Verified
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="bg-slate-900 dark:bg-indigo-950 text-white p-6 space-y-4 relative overflow-hidden group border theme-border shadow-xl">
                        <div className="absolute top-0 right-0 p-8 opacity-10 rotate-12 group-hover:rotate-0 transition-transform">
                          <Lock size={48} />
                        </div>
                        <div className="relative z-10">
                          <h5 className="text-xs font-bold uppercase tracking-widest italic flex items-center gap-2">
                            <Lock size={12} className="text-amber-400" /> Pro Feature: Telemetry Archives
                          </h5>
                          <p className="text-[10px] text-slate-400 leading-relaxed mt-2 max-w-[80%]">
                            Upgrade to <span className="text-indigo-400 font-bold">MeteorGrade Pro</span> to unlock detailed atmospheric telemetry for strategic practice and refinement.
                          </p>
                          <button 
                            onClick={() => window.dispatchEvent(new CustomEvent('open-subscription'))}
                            className="mt-4 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2 text-[9px] font-bold uppercase tracking-widest transition-all shadow-lg"
                          >
                            Explore Pro Intel
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Admin Management Section */}
                    {(user.role === 'admin' || user.email?.toLowerCase() === 'tylerleedixon@gmail.com') && (selectedCampaign.is_global || selectedCampaign.isGlobal) && (
                      <div className="bg-amber-50 dark:bg-amber-950 border-2 border-amber-200 dark:border-amber-900 p-8 space-y-6 theme-shadow">
                        <div className="flex items-center gap-3">
                          <Settings size={18} className="text-amber-600" />
                          <h4 className="text-xs font-black uppercase tracking-[0.2em] text-amber-900 dark:text-amber-100">Admin Management Matrix</h4>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-4">
                            <p className="text-[9px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-widest">Operational Status</p>
                            <div className="flex theme-bg-secondary border theme-border p-1">
                               <button 
                                onClick={() => handleUpdateStatus(selectedCampaign.id, 'active')}
                                className={`flex-1 py-3 text-[9px] font-bold uppercase tracking-widest transition-all ${selectedCampaign.status === 'active' ? 'bg-amber-600 text-white' : 'text-amber-600 hover:bg-amber-100 dark:hover:bg-amber-900'}`}
                               >
                                 Active
                               </button>
                               <button 
                                onClick={() => handleUpdateStatus(selectedCampaign.id, 'completed')}
                                className={`flex-1 py-3 text-[9px] font-bold uppercase tracking-widest transition-all ${selectedCampaign.status === 'completed' ? 'bg-amber-600 text-white' : 'text-amber-600 hover:bg-amber-100 dark:hover:bg-amber-900'}`}
                               >
                                 Completed
                               </button>
                            </div>
                          </div>

                          <div className="space-y-4">
                            <p className="text-[9px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-widest">Bureau Verification</p>
                            <button 
                              onClick={() => handleUpdateStatus(selectedCampaign.id, selectedCampaign.status, !(selectedCampaign.is_reviewed || selectedCampaign.isReviewed))}
                              className={`w-full py-3 text-[9px] font-bold uppercase tracking-widest transition-all border-2 ${
                                (selectedCampaign.is_reviewed || selectedCampaign.isReviewed) 
                                ? 'bg-emerald-600 border-emerald-600 text-white hover:bg-emerald-700 font-black' 
                                : 'border-amber-600 text-amber-600 hover:bg-amber-600 hover:text-white'
                              }`}
                            >
                               {(selectedCampaign.is_reviewed || selectedCampaign.isReviewed) ? 'Revoke Verification' : 'Verify Operational Intel'}
                            </button>
                          </div>

                          <div className="sm:col-span-2 space-y-4">
                             <p className="text-[9px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-widest">Destructive Actions</p>
                             {deletingId === selectedCampaign.id ? (
                               <div className="flex gap-2">
                                 <button 
                                   onClick={() => setDeletingId(null)}
                                   className="flex-1 py-4 border-2 border-red-200 theme-text-error text-[10px] font-bold uppercase tracking-widest hover:theme-bg-error transition-all"
                                 >
                                   Abort Decommission
                                 </button>
                                 <button 
                                   onClick={() => handleDelete(selectedCampaign.id, true)}
                                   className="flex-1 py-4 bg-red-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg animate-pulse"
                                 >
                                   Finalize Purge
                                 </button>
                               </div>
                             ) : (
                               <button 
                                onClick={() => setDeletingId(selectedCampaign.id)}
                                className="w-full py-4 bg-red-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-red-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-red-600/20"
                               >
                                 <Trash2 size={14} /> Decommission Operation
                               </button>
                             )}
                          </div>
                        </div>

                        <div className="p-4 theme-bg-secondary border theme-border">
                           <p className="text-[9px] theme-text-muted leading-relaxed font-mono">
                             <span className="font-bold text-amber-600">ADMIN NOTICE:</span> Changes to Global Bureau Operations affect all active analysts synchronously. Exercise extreme discretion before decommissioning.
                           </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold theme-text-primary uppercase tracking-widest flex items-center gap-2">
                      <Activity size={14} className="text-indigo-600 dark:text-indigo-400" /> Linked Forecast Data
                    </h4>
                    
                    <div className="space-y-3">
                      {getForecastsForCampaign(selectedCampaign).length > 0 ? (
                        getForecastsForCampaign(selectedCampaign).map((f: any) => (
                          <div key={f.id} className="theme-bg-secondary border theme-border p-4 flex justify-between items-center group hover:border-indigo-600 transition-all uppercase tracking-widest">
                            <div className="flex items-center gap-4">
                              <MapPin size={14} className="theme-text-muted opacity-40" />
                              <div>
                                <p className="text-[11px] font-bold theme-text-primary">{f.location}</p>
                                <p className="text-[9px] theme-text-muted font-mono">{f.targetDate}</p>
                              </div>
                            </div>
                            <div className="flex flex-col items-end">
                              <span className={`text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 border ${
                                f.status === 'completed' ? 'theme-border theme-text-success theme-bg-success' : 'theme-border theme-text-muted'
                              }`}>
                                {f.status}
                              </span>
                              {f.actualGrade && (
                                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 mt-1">{f.actualGrade.score}% Precision</span>
                              )}
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="border-2 border-dashed theme-border p-8 text-center bg-indigo-500/5">
                          <p className="text-[10px] theme-text-muted uppercase tracking-widest italic">No forecast data detected for this window.</p>
                          <p className="text-[9px] theme-text-muted mt-1 opacity-70">Submit new forecasts matching this time range to populate dossier.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-8 border-t theme-border theme-bg-secondary sticky bottom-0">
                <button 
                  onClick={() => setSelectedCampaign(null)}
                  className="w-full bg-slate-900 dark:bg-indigo-600 text-white py-4 text-[10px] font-bold uppercase tracking-[0.2em] hover:opacity-80 transition-all shadow-lg"
                >
                  Return to Campaign Overview
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* Tutorial Briefing Modal */}
        {showTutorial && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              className="theme-bg-secondary max-w-2xl w-full p-8 md:p-12 theme-shadow relative border theme-border"
            >
              <button 
                onClick={() => setShowTutorial(false)}
                className="absolute top-6 right-6 theme-text-muted hover:theme-text-primary transition-colors"
              >
                <X size={24} />
              </button>

                <div className="space-y-10">
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.3em]">Mission Logistics</span>
                  <h3 className="text-3xl font-light uppercase tracking-tighter theme-text-primary">Strategic <span className="font-bold">Theatres</span></h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 theme-text-primary">
                      <Shield size={20} className="text-indigo-600 dark:text-indigo-400" />
                      <h4 className="text-[11px] font-bold uppercase tracking-widest leading-none">The Mission</h4>
                    </div>
                    <p className="text-xs theme-text-secondary leading-relaxed">
                      Missions are multiday forecasting operations. The Intelligence Bureau auto-generates "Theatres of Operation" when severe weather systems are projected globally.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 theme-text-primary">
                      <Activity size={20} className="text-indigo-600 dark:text-indigo-400" />
                      <h4 className="text-[11px] font-bold uppercase tracking-widest leading-none">Performance Evaluation</h4>
                    </div>
                    <p className="text-xs theme-text-secondary leading-relaxed">
                      Your Precision Index (PI) is heavily weighted by mission success. We analyze your trend detection across the entire theatre duration, prioritizing accuracy under pressure.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 theme-text-primary">
                      <Zap size={20} className="text-indigo-600 dark:text-indigo-400" />
                      <h4 className="text-[11px] font-bold uppercase tracking-widest leading-none">Intelligence Synthesis</h4>
                    </div>
                    <p className="text-xs theme-text-secondary leading-relaxed">
                      Bureau AI tracks NWS models to identify potential storm weekend events 48-72 hours in advance. Monitoring occurs in real-time to adjust mission parameters.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 theme-text-primary">
                      <Zap size={20} className="text-red-500" />
                      <h4 className="text-[11px] font-bold uppercase tracking-widest leading-none">Flashpoint Alerts</h4>
                    </div>
                    <p className="text-xs theme-text-secondary leading-relaxed">
                      Tornado and Severe Thunderstorm detections trigger instant "Flashpoints." These are high-speed intercepts required during active hazardous warnings.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 theme-text-primary">
                      <Calendar size={20} className="text-indigo-600 dark:text-indigo-400" />
                      <h4 className="text-[11px] font-bold uppercase tracking-widest leading-none">Operational Cycle</h4>
                    </div>
                    <p className="text-xs theme-text-secondary leading-relaxed">
                      Accept a mission, then submit forecasts for the duration. Data is verified against ground truth telemetry 24 hours after each window closes.
                    </p>
                  </div>
                </div>

                <button 
                  onClick={() => setShowTutorial(false)}
                  className="w-full bg-slate-900 dark:bg-indigo-600 text-white font-bold py-5 text-[11px] uppercase tracking-[0.3em] hover:opacity-80 transition-all shadow-lg"
                >
                  Close Mission Briefing
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {showCreate && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[120] flex items-center justify-center p-6"
          >
            <motion.form 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              onSubmit={handleCreate}
              className="theme-bg-secondary max-w-lg w-full p-6 sm:p-12 space-y-8 theme-shadow border theme-border overflow-y-auto max-h-[90vh]"
            >
              <div>
                <h3 className="text-2xl font-light uppercase tracking-tighter theme-text-primary">Mission <span className="font-bold">Directive</span></h3>
                <p className="text-xs theme-text-muted uppercase tracking-widest mt-2">Define multiday regional window</p>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted">Mission Title</label>
                  <input 
                    required
                    value={newCampaign.title}
                    onChange={e => setNewCampaign({...newCampaign, title: e.target.value})}
                    placeholder="E.g., Coastal Storm Watch or Summer Solstice Heat"
                    className="w-full theme-bg-input border theme-border p-3 focus:border-indigo-600 outline-none transition-all text-sm uppercase font-bold theme-text-primary"
                  />
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted">Start Date</label>
                    <input 
                      required
                      type="date"
                      value={newCampaign.startDate}
                      onChange={e => setNewCampaign({...newCampaign, startDate: e.target.value})}
                      className="w-full theme-bg-input border theme-border p-3 outline-none text-sm font-mono theme-text-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted">End Date</label>
                    <input 
                      required
                      type="date"
                      value={newCampaign.endDate}
                      onChange={e => setNewCampaign({...newCampaign, endDate: e.target.value})}
                      className="w-full theme-bg-input border theme-border p-3 outline-none text-sm font-mono theme-text-primary"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted">Analysis Notes</label>
                  <textarea 
                    value={newCampaign.description}
                    onChange={e => setNewCampaign({...newCampaign, description: e.target.value})}
                    className="w-full theme-bg-input border theme-border p-4 focus:border-indigo-600 outline-none transition-all text-sm h-24 theme-text-primary"
                    placeholder="Objectives, regional locations, or expected anomalies..."
                  />
                </div>

                {(user.role === 'admin' || (user.email && user.email.toLowerCase() === 'tylerleedixon@gmail.com')) && (
                  <div className="flex items-center gap-3 p-4 theme-bg-primary border theme-border">
                    <input 
                      type="checkbox"
                      id="global-mission"
                      checked={newCampaign.isGlobal}
                      onChange={e => setNewCampaign({...newCampaign, isGlobal: e.target.checked})}
                      className="w-4 h-4 accent-indigo-600"
                    />
                    <label htmlFor="global-mission" className="text-[10px] font-bold uppercase tracking-widest theme-text-primary cursor-pointer">
                      Broadcast as <span className="theme-text-error font-black">Global Bureau Operation</span>
                    </label>
                  </div>
                )}
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={() => setShowCreate(false)}
                  className="flex-1 theme-bg-secondary border theme-border py-4 text-[10px] font-bold uppercase tracking-widest hover:theme-bg-primary transition-all theme-text-primary"
                >
                  Cancel
                </button>
                <button 
                  className="flex-1 bg-slate-900 dark:bg-indigo-600 text-white py-4 text-[10px] font-bold uppercase tracking-widest hover:opacity-80 transition-all shadow-lg"
                >
                  Create Campaign
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
