import React, { useMemo, useState, useEffect, useRef } from 'react';
import { auth, db } from '../lib/db';
import { doc, getDoc, collection, query, where, orderBy, onSnapshot, limit, updateDoc } from '../lib/db';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis
} from 'recharts';
import { TrendingUp, Activity, Award, MapPin, UserSquare2, Radio, AlertTriangle, Info, BellRing, X, ShieldCheck, Zap, Filter, Navigation, Clock, Search, Target } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getGlobalThreatLevel } from '../services/nwsService';
import { usePreferences } from '../lib/preferences';

interface AnalyticsDashboardProps {
  forecasts: any[];
  flashpoints?: any[];
  profile?: any;
  onTrackSignal?: (fp: any) => void;
}

export default function AnalyticsDashboard({ forecasts, flashpoints = [], profile: initialProfile, onTrackSignal }: AnalyticsDashboardProps) {
  const { unitPreference, setUnitPreference, windUnit, setWindUnit } = usePreferences();
  const [profile, setProfile] = useState<any>(initialProfile || null);
  const [threatLevel, setThreatLevel] = useState<any>(null);
  const [stormFilter, setStormFilter] = useState<'all' | 'extreme' | 'severe'>('all');
  const [announcements, setAnnouncements] = useState<any[]>([]);

  const filteredStorms = useMemo(() => {
    return flashpoints.filter(fp => {
      if (stormFilter === 'extreme') return fp.severity === 'Extreme' || fp.severity === 'extreme';
      if (stormFilter === 'severe') return fp.severity === 'Severe' || fp.severity === 'severe';
      return true;
    }).sort((a, b) => {
      const timeA = a.createdAt ? new Date(a.createdAt.toDate ? a.createdAt.toDate() : a.createdAt).getTime() : 0;
      const timeB = b.createdAt ? new Date(b.createdAt.toDate ? b.createdAt.toDate() : b.createdAt).getTime() : 0;
      return timeB - timeA;
    });
  }, [flashpoints, stormFilter]);

  const [stormSearch, setStormSearch] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialProfile) {
      setProfile(initialProfile);
    }
  }, [initialProfile]);

  useEffect(() => {
    if (profile) {
      // Logic removed as it is now in ProfileSettingsModal
    }
  }, [profile]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 512) { // 512KB limit for base64 strings in DB fields
      alert("Image too large. Please select a file under 512KB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      const img = new Image();
      img.onload = async () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 128;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        const resizedBase64 = canvas.toDataURL('image/jpeg', 0.8);

        try {
          await updateDoc(doc(db, 'users', auth.currentUser!.uid), { avatarUrl: resizedBase64 });
          setProfile((prev: any) => ({ ...prev, avatarUrl: resizedBase64 }));
        } catch (err) {
          console.error(err);
          alert("Failed to upload photo.");
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const groupedStorms = useMemo(() => {
    const groups: Record<string, any[]> = {};
    
    filteredStorms.forEach(storm => {
      const areaText = (storm.area || storm.location || '').toLowerCase();
      const isMatch = areaText.includes(stormSearch.toLowerCase()) || 
                     (storm.event?.toLowerCase() || '').includes(stormSearch.toLowerCase());
      
      if (!isMatch) return;

      const event = (storm.event?.toLowerCase() || '');
      let category = 'Other Hazards';
      
      if (event.includes('tornado')) category = 'Tornado Alerts';
      else if (event.includes('flood')) category = 'Flood Systems';
      else if (event.includes('thunderstorm')) category = 'Severe Storms';
      else if (event.includes('winter') || event.includes('snow') || event.includes('blizzard')) category = 'Winter Systems';
      else if (event.includes('fire') || event.includes('red flag')) category = 'Fire / Red Flag';
      else if (event.includes('heat')) category = 'Heat Advisories';
      else if (event.includes('wind') && !event.includes('thunderstorm')) category = 'Wind Alerts';

      if (!groups[category]) groups[category] = [];
      groups[category].push(storm);
    });

    return Object.entries(groups).sort((a, b) => b[1].length - a[1].length);
  }, [filteredStorms, stormSearch]);

  const toggleCategory = (cat: string) => {
    setExpandedCategories(prev => ({ ...prev, [cat]: !prev[cat] }));
  };

  useEffect(() => {
    const fetchProfile = async () => {
      if (auth.currentUser) {
        const snap = await getDoc(doc(db, 'users', auth.currentUser.uid));
        if (snap.exists()) {
          setProfile(snap.data());
        }
      }
    };
    fetchProfile();

    const fetchThreat = async () => {
      const level = await getGlobalThreatLevel();
      setThreatLevel(level);
    };
    fetchThreat();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('createdAt', 'desc'), limit(3));
    const unsub = onSnapshot(q, (snap) => {
      const allAnnouncements = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      const now = new Date();
      const filtered = allAnnouncements.filter(ann => {
        if (!ann.expiresAt) return true;
        const expiry = new Date(ann.expiresAt?.toDate ? ann.expiresAt.toDate() : ann.expiresAt);
        return expiry > now;
      });
      setAnnouncements(filtered);
    }, (err) => console.error("Announcements Fetch Error:", err));
    return () => unsub();
  }, []);

  const completedForecasts = useMemo(() => 
    forecasts.filter(f => f.status === 'completed' && f.actualGrade)
      .sort((a, b) => new Date(a.targetDate).getTime() - new Date(b.targetDate).getTime())
  , [forecasts]);

  const deviationData = useMemo(() => {
    return completedForecasts.map(f => {
      const hErr = Math.abs((f.highTemp || 0) - (f.actualGrade.actualHigh || 0));
      const lErr = Math.abs((f.lowTemp || 0) - (f.actualGrade.actualLow || 0));
      return {
        date: f.targetDate?.slice(5) || '??', // MM-DD
        highError: isNaN(hErr) ? 0 : hErr,
        lowError: isNaN(lErr) ? 0 : lErr,
        deviation: (isNaN(hErr) ? 0 : hErr) + (isNaN(lErr) ? 0 : lErr)
      };
    });
  }, [completedForecasts]);

  const regionalData = useMemo(() => {
    const locations: Record<string, { totalScore: number, count: number }> = {};
    completedForecasts.forEach(f => {
      const city = f.location.split(',')[0];
      if (!locations[city]) locations[city] = { totalScore: 0, count: 0 };
      locations[city].totalScore += f.actualGrade.score;
      locations[city].count += 1;
    });
    return Object.entries(locations).map(([city, data]) => ({
      city,
      score: data.count > 0 ? Math.round(data.totalScore / data.count) : 0
    })).sort((a, b) => (b.score || 0) - (a.score || 0)).slice(0, 5);
  }, [completedForecasts]);

  const biasData = useMemo(() => {
    if (completedForecasts.length === 0) {
      return [
        { subject: 'High Temp Bias', A: 0, fullMark: 10 },
        { subject: 'Low Temp Bias', A: 0, fullMark: 10 },
        { subject: 'Hum. Accuracy', A: 0, fullMark: 10 },
        { subject: 'Prec. Sensitivity', A: 0, fullMark: 10 },
        { subject: 'Condition Drift', A: 0, fullMark: 10 }
      ];
    }

    const highBias = completedForecasts.reduce((acc, f) => acc + ((f.highTemp || 0) - (f.actualGrade?.actualHigh || 0)), 0) / completedForecasts.length;
    const lowBias = completedForecasts.reduce((acc, f) => acc + ((f.lowTemp || 0) - (f.actualGrade?.actualLow || 0)), 0) / completedForecasts.length;
    
    // Calculate Condition Drift (Inverse of score contribution from conditions)
    // For now, let's just use the real precision index as a proxy for sensing balance
    const totalScoreSum = completedForecasts.reduce((acc, f) => acc + (f.actualGrade?.score || 0), 0);
    const avgScore = totalScoreSum / completedForecasts.length;
    const humidityAcc = completedForecasts.filter(f => f.humidity !== undefined).length > 0 ? (avgScore / 10) : 0;

    return [
      { subject: 'High Temp Bias', A: Math.min(Math.abs(isNaN(highBias) ? 0 : highBias), 10), fullMark: 10 },
      { subject: 'Low Temp Bias', A: Math.min(Math.abs(isNaN(lowBias) ? 0 : lowBias), 10), fullMark: 10 },
      { subject: 'Hum. Accuracy', A: isNaN(humidityAcc) ? 0 : humidityAcc, fullMark: 10 },
      { subject: 'Prec. Sensitivity', A: isNaN(avgScore / 10) ? 0 : (avgScore / 10), fullMark: 10 },
      { subject: 'Condition Drift', A: isNaN(10 - (avgScore / 10)) ? 10 : 10 - (avgScore / 10), fullMark: 10 }
    ];
  }, [completedForecasts]);

  return (
    <div className="space-y-8 md:space-y-12 selection:bg-indigo-600 selection:text-white">
      {/* Official Bulletins */}
      <AnimatePresence>
        {announcements.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-4 mb-2">
              <BellRing size={16} className="text-indigo-600" />
              <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] theme-text-muted">Official Bureau Bulletins</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {announcements.map((ann) => (
                <motion.div 
                  key={ann.id}
                  layout
                  className="theme-bg-secondary border theme-border border-l-4 border-l-indigo-600 p-5 theme-shadow hover:translate-y-[-2px] transition-all group"
                >
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-[9px] font-black uppercase tracking-widest theme-text-muted font-mono">
                      {ann.createdAt ? new Date(ann.createdAt?.toDate ? ann.createdAt.toDate() : ann.createdAt).toLocaleDateString() : 'Active'}
                    </span>
                    <Info size={12} className="theme-text-muted group-hover:text-indigo-400 transition-colors" />
                  </div>
                  <h4 className="font-bold theme-text-primary text-sm mb-1 uppercase tracking-tight">{ann.title}</h4>
                  <p className="text-xs theme-text-secondary leading-relaxed line-clamp-2 mb-2">{ann.content || ann.description}</p>
                  {ann.expiresAt && (
                    <div className="flex items-center gap-1.5 text-[8px] font-bold theme-text-muted uppercase tracking-widest mt-auto pt-2 border-t theme-border">
                      <Clock size={10} /> Expires: {new Date(ann.expiresAt?.toDate ? ann.expiresAt.toDate() : ann.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {profile && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-12">
          <div className="md:col-span-2 theme-bg-secondary border theme-border theme-text-primary p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 theme-shadow">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-indigo-600 flex items-center justify-center border-2 border-indigo-400/50 overflow-hidden shadow-lg">
                {profile.avatarUrl ? (
                  <img src={profile.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <UserSquare2 size={32} className="text-white" />
                )}
              </div>
              <div>
                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] block mb-1.5">
                  Analyst Profile
                </span>
                <h2 className="text-2xl md:text-3xl font-light tracking-tight flex items-baseline gap-2">
                  <span className="font-mono text-indigo-300">@</span>{profile.displayName?.split(' ')[0].toLowerCase() || 'analyst'}
                </h2>
                <div className="flex flex-wrap items-center gap-3 mt-4 pt-4 border-t border-white/10">
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="group flex items-center gap-3 px-4 py-2 theme-bg-primary border theme-border theme-text-primary hover:theme-bg-secondary text-[10px] font-black uppercase tracking-widest transition-all shadow-md active:translate-y-0.5"
                  >
                    <Activity size={12} className="group-hover:rotate-180 transition-transform" />
                    Upload Signal
                  </button>
                  <button 
                    onClick={() => window.dispatchEvent(new CustomEvent('open-profile-settings'))}
                    className="group flex items-center gap-3 px-4 py-2 bg-white/5 hover:bg-white/10 text-white text-[10px] font-black uppercase tracking-widest transition-all border border-white/10"
                  >
                    <Filter size={12} />
                    Parameters
                  </button>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleFileUpload} 
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-6 md:gap-12 pl-20 md:pl-0 border-t md:border-t-0 border-white/10 pt-6 md:pt-0 w-full md:w-auto">
              {[
                { label: 'Analyst Level', val: profile.tier || 'Novice', color: 'text-amber-400' },
                { label: 'Precision Index', val: `${(profile.precisionIndex !== undefined && !isNaN(profile.precisionIndex)) ? Number(profile.precisionIndex).toFixed(1) : '0.0'} PI`, color: 'text-white' },
                { label: 'Verified Forecasts', val: profile.totalForecasts || 0, color: 'text-white' }
              ].map((stat, i) => (
                <div key={i} className="flex flex-col">
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-widest block mb-1">{stat.label}</span>
                  <span className={`text-lg font-mono font-bold ${stat.color}`}>{stat.val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Global Threat Widget (Real NWS Status) */}
          <div className="theme-bg-secondary border-2 border-slate-900 dark:border-indigo-600 p-6 md:p-8 flex flex-col justify-between theme-shadow relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <Radio size={120} />
             </div>
             <div className="flex justify-between items-start relative z-10">
               <span className="text-[10px] font-black theme-text-muted uppercase tracking-[0.2em]">Active Severity Index</span>
               <ShieldCheck size={20} className={threatLevel?.color || 'theme-text-muted'} />
             </div>
             <div className="relative z-10">
               <div className="flex items-baseline gap-3 mt-6">
                 <span className={`text-5xl font-black tracking-tighter ${threatLevel?.color || 'theme-text-primary'}`}>
                   {threatLevel?.level || '3'}
                 </span>
                 <span className={`text-xs font-black uppercase tracking-widest ${threatLevel?.color || 'theme-text-muted'}`}>
                   {threatLevel?.label || 'STABLE'}
                 </span>
               </div>
               <p className="text-[10px] theme-text-secondary font-medium uppercase tracking-widest mt-4 leading-relaxed">
                 {threatLevel?.description || 'Synchronizing with NWS Satellite Feed...'}
               </p>
             </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
        {/* Deviation Chart */}
        <div className="lg:col-span-2 theme-bg-secondary border theme-border p-6 md:p-8 theme-shadow">
          <div className="flex items-center justify-between mb-10">
            <div>
              <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.3em]">Precision Tracking</span>
              <h3 className="text-xl font-light uppercase tracking-tighter mt-1 theme-text-primary">Atmospheric Deviation</h3>
            </div>
            <div className="p-2 theme-bg-primary rounded-sm theme-text-muted">
              <TrendingUp size={20} />
            </div>
          </div>
          <div className="h-[250px] md:h-[300px] w-full relative">
            {deviationData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <LineChart data={deviationData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border-color)" />
                  <XAxis dataKey="date" stroke="var(--text-muted)" fontSize={9} tickLine={false} axisLine={false} />
                  <YAxis stroke="var(--text-muted)" fontSize={9} tickLine={false} axisLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: '0px' }}
                    itemStyle={{ fontSize: '10px', color: 'var(--text-primary)', textTransform: 'uppercase', letterSpacing: '0.1em' }}
                    labelStyle={{ fontSize: '10px', color: 'var(--text-muted)', marginBottom: '8px' }}
                  />
                  <Line type="monotone" dataKey="highError" stroke="#ef4444" strokeWidth={3} dot={{ r: 4, fill: '#ef4444' }} activeDot={{ r: 6 }} isAnimationActive={false} />
                  <Line type="monotone" dataKey="lowError" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4, fill: '#3b82f6' }} activeDot={{ r: 6 }} isAnimationActive={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center border-2 border-dashed theme-border theme-bg-primary">
                <span className="text-[10px] font-bold theme-text-muted uppercase tracking-widest italic">Awaiting Telemetry Validation</span>
              </div>
            )}
          </div>
          <div className="mt-8 flex flex-wrap gap-8 text-[9px] font-black uppercase tracking-[0.25em] theme-text-muted">
            <div className="flex items-center gap-3"><div className="w-3 h-3 bg-red-500 rounded-full"></div> High Temp Divergence</div>
            <div className="flex items-center gap-3"><div className="w-3 h-3 bg-blue-500 rounded-full"></div> Low Temp Divergence</div>
          </div>
        </div>

        {/* Bias Radar */}
        <div className="theme-bg-secondary border-2 theme-border theme-text-primary p-6 md:p-8 theme-shadow">
          <div className="mb-10 border-b theme-border pb-4">
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">Meteorological Profile</span>
            <h3 className="text-xl font-light uppercase tracking-tighter mt-1">Sensing Bias</h3>
          </div>
          <div className="h-[250px] md:h-[300px] w-full relative">
            {completedForecasts.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={biasData}>
                  <PolarGrid stroke="#334155" />
                  <PolarAngleAxis dataKey="subject" stroke="#94a3b8" fontSize={8} />
                  <Radar name="User Bias" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.6} isAnimationActive={false} />
                </RadarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center border theme-border bg-white/5 p-8 text-center">
                <Radio size={40} className="text-slate-700 mb-4 opacity-30" />
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] leading-relaxed">
                  Insufficient Samples<br/>for Bias Synthesis
                </p>
              </div>
            )}
          </div>
          <div className="mt-6 p-4 bg-white/5 border border-white/10 font-mono">
            <p className="text-[9px] text-indigo-400 leading-relaxed uppercase tracking-tighter">
              // Analysis focus: High-pressure optimistic bias active.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-10">
        {/* Condensed Storm Event Navigator */}
        <div className="theme-bg-secondary border theme-border flex flex-col min-h-[450px] shadow-2xl">
          <div className="p-6 md:p-10 pb-6 border-b theme-border theme-bg-primary">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
              <div className="flex items-center gap-4">
                <div className="bg-amber-400 p-2 rounded-sm shadow-lg shadow-amber-900/20">
                  <Zap size={24} className="text-slate-900" />
                </div>
                <div>
                  <span className="text-[10px] font-black text-amber-500 uppercase tracking-[0.4em] block">Threat Intelligence</span>
                  <h3 className="text-xl font-light uppercase tracking-tight text-white mt-0.5">Atmospheric Flashpoints</h3>
                </div>
              </div>
              <div className="flex items-center gap-1 theme-bg-input p-1 rounded-sm shadow-inner">
                {(['all', 'extreme', 'severe'] as const).map(type => (
                  <button 
                    key={type}
                    onClick={() => setStormFilter(type)}
                    className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-widest transition-all ${stormFilter === type ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Search and Summary */}
            <div className="space-y-5">
              <div className="relative group">
                <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                <input 
                  type="text" 
                  placeholder="FILTER BY LOCATION OR HAZARD..."
                  value={stormSearch}
                  onChange={(e) => setStormSearch(e.target.value)}
                  className="w-full theme-bg-input border theme-border py-3 pl-12 pr-4 text-[10px] font-black uppercase tracking-[0.2em] text-white outline-none focus:border-indigo-500 transition-all shadow-inner"
                />
              </div>
              
              <div className="flex flex-wrap gap-3">
                {groupedStorms.map(([cat, storms]) => (
                  <div key={cat} className="flex items-center theme-bg-input border theme-border px-3 py-1.5 rounded-sm backdrop-blur-md">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mr-3">{cat}</span>
                    <span className="text-[10px] font-mono text-indigo-400 font-bold">{storms.length}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar p-1 space-y-px">
            {groupedStorms.map(([category, storms]) => (
              <div key={category} className="overflow-hidden">
                <button 
                  onClick={() => toggleCategory(category)}
                  className="w-full flex items-center justify-between p-4 theme-bg-secondary hover:theme-bg-primary transition-colors group"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-1.5 h-4 ${category.includes('Tornado') ? 'bg-red-600' : category.includes('Severe') ? 'bg-amber-500' : 'bg-indigo-500'}`} />
                    <span className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-400 group-hover:text-white transition-colors">{category}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{storms.length} ACTIVE</span>
                    <motion.div
                      animate={{ rotate: expandedCategories[category] ? 180 : 0 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                    >
                      <Navigation size={12} className="text-slate-600 rotate-90" />
                    </motion.div>
                  </div>
                </button>
                
                <AnimatePresence initial={false}>
                  {expandedCategories[category] && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden theme-bg-primary"
                    >
                      <div className="p-1 space-y-px">
                        {storms.map(storm => (
                          <div key={storm.id} className="theme-bg-secondary p-4 flex items-center justify-between gap-6 border-l-2 border-transparent hover:border-indigo-600 hover:bg-white/5 transition-all group">
                            <div className="min-w-0">
                               <div className="flex items-center gap-3 mb-1.5">
                                  <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-sm ${storm.severity === 'Extreme' ? 'bg-red-600 text-white' : 'bg-amber-500 text-slate-900'}`}>
                                    {storm.severity}
                                  </span>
                                  <span className="text-[10px] font-bold text-slate-100 uppercase tracking-wider truncate">{storm.event}</span>
                               </div>
                               <p className="text-[10px] text-slate-500 font-medium uppercase tracking-widest truncate pl-1 border-l theme-border theme-border ml-1">{storm.area || storm.location || 'Coordinated Sector'}</p>
                            </div>
                            <button 
                              onClick={() => onTrackSignal?.(storm)}
                              className="shrink-0 p-3 theme-bg-input theme-text-muted hover:theme-text-primary hover:bg-indigo-600 transition-all rounded shadow-lg"
                              title="Engage Satellite Targeting"
                            >
                              <Target size={14} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}

             {groupedStorms.length === 0 && (
               <div className="h-full flex flex-col items-center justify-center p-16 text-center">
                  <ShieldCheck size={56} className="text-slate-800 mb-6 opacity-50" />
                  <p className="text-[12px] font-black text-slate-500 uppercase tracking-[0.3em]">Sector Clean // No Flashpoints Detected</p>
               </div>
             )}
          </div>
        </div>

        <div className="space-y-6 md:space-y-10">
          {/* Regional Strengths */}
          <div className="theme-bg-secondary border theme-border p-6 md:p-10 theme-shadow">
            <div className="flex items-center gap-4 mb-10 pb-4 border-b theme-border">
              <MapPin size={22} className="text-indigo-600" />
              <h3 className="text-[11px] font-black uppercase tracking-[0.3em] theme-text-muted">Geographic Precision Network</h3>
            </div>
            <div className="space-y-8">
              {regionalData.map((item, i) => (
                <div key={i} className="flex items-center gap-6 group">
                  <span className="text-xl font-black theme-text-muted w-8 opacity-20 group-hover:opacity-100 transition-opacity">0{i+1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-end mb-2.5 gap-4">
                      <span className="text-[11px] font-black uppercase tracking-widest theme-text-primary truncate">{item.city}</span>
                      <span className="text-[11px] font-mono font-bold text-indigo-600 shrink-0">{(item.score !== undefined && !isNaN(item.score)) ? item.score : 0}%</span>
                    </div>
                    <div className="w-full h-1.5 theme-bg-primary rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(item.score !== undefined && !isNaN(item.score)) ? item.score : 0}%` }}
                        className="h-full bg-indigo-600 rounded-full shadow-[0_0_8px_rgba(99,102,241,0.5)]"
                      />
                    </div>
                  </div>
                </div>
              ))}
              {regionalData.length === 0 && <p className="text-xs theme-text-muted italic text-center p-8 border-2 border-dashed theme-border">Geographic telemetry pending first verification cycle.</p>}
            </div>
          </div>

          {/* Global Stats Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 lg:gap-10">
            <div className="theme-bg-secondary border-2 border-slate-900 p-8 flex flex-col justify-between shadow-[8px_8px_0px_var(--shadow-color)] group hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all">
              <div className="p-3 theme-bg-primary w-fit rounded-sm mb-6 theme-text-primary">
                <Activity size={24} />
              </div>
              <div>
                <span className="text-5xl md:text-6xl font-black tracking-tighter theme-text-primary leading-none">{completedForecasts.length}</span>
                <p className="text-[10px] font-black uppercase theme-text-muted tracking-[0.3em] mt-3">Events Verified</p>
              </div>
            </div>
            <div className="bg-indigo-600 text-white p-8 flex flex-col justify-between shadow-[8px_8px_0px_#312e81] group hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all">
              <div className="p-3 bg-white/10 w-fit rounded-sm mb-6">
                <Award size={24} className="text-white" />
              </div>
              <div>
                <span className="text-5xl md:text-6xl font-black tracking-tighter leading-none">
                  {(() => {
                    const raw = completedForecasts.reduce((a, b) => a + (b.actualGrade?.score || 0), 0) / (completedForecasts.length || 1);
                    return isNaN(raw) ? 0 : Math.round(raw);
                  })()}%
                </span>
                <p className="text-[10px] font-black uppercase text-indigo-200 tracking-[0.3em] mt-3">Network Precision</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Accolades (Achievements/Badges) */}
      <div className="theme-bg-secondary border theme-border p-6 md:p-10 theme-shadow relative overflow-hidden">
        <div className="relative z-10 flex items-center gap-5 mb-12">
          <div className="p-2 bg-amber-400 rounded-sm">
            <Award size={24} className="text-slate-900" />
          </div>
          <div>
            <span className="text-[10px] font-black text-amber-500 uppercase tracking-[0.4em] block">Analyst Recognition</span>
            <h3 className="text-xl font-light uppercase tracking-tighter theme-text-primary">Professional Accolades</h3>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
          {[
            {
              id: 'bust-proofer',
              title: 'Bust-Proofer',
              desc: 'Successfully predicted a low-impact event when models anticipated a major storm.',
              styles: 'bg-orange-500 text-white',
              unlocked: profile?.achievements?.some((a: any) => a.id === 'bust-proofer')
            },
            {
              id: 'seven-day-streak',
              title: 'Precision Streak (7D)',
              desc: 'Maintained less than 2° temperature variance for 7 consecutive forecasts.',
              styles: 'bg-emerald-600 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]',
              unlocked: profile?.achievements?.some((a: any) => a.id === 'seven-day-streak') || (profile?.streak >= 7)
            },
            {
              id: 'first_forecast',
              title: 'Forecasting Entry',
              desc: 'Successfully submit your first valid forecast.',
              styles: 'bg-slate-700 text-white',
              unlocked: forecasts.length >= 1
            },
            {
              id: 'veteran',
              title: 'Expert Analyst',
              desc: 'Complete accuracy benchmarks for 5 forecasting cycles.',
              styles: 'bg-indigo-600 text-white',
              unlocked: forecasts.length >= 5
            },
            {
              id: 'contrarian-king',
              title: 'Contrarian King',
              desc: 'Accurately pivoted away from crowd consensus by >= 4 degrees.',
              styles: 'bg-emerald-600 shadow-emerald-500/20 text-white',
              unlocked: profile?.achievements?.some((a: any) => a.id === 'contrarian-king')
            },
            {
              id: 'model-defiance',
              title: 'Model Defiance',
              desc: 'Disagreed with global models and was proven correct (>90% accuracy).',
              styles: 'bg-amber-600 shadow-amber-500/20 text-white',
              unlocked: profile?.achievements?.some((a: any) => a.id === 'model-defiance')
            },
            {
              id: 'sharpshooter',
              title: 'Precision Excellence',
              desc: 'Achieve a verification precision score of 95% or greater.',
              styles: 'bg-amber-500 text-slate-900',
              unlocked: completedForecasts.some(f => (f.actualGrade?.score || 0) >= 95)
            },
            {
              id: 'flawless',
              title: 'Absolute Synergy',
              desc: 'Achieve absolute 100% precision on a verified forecast.',
              styles: 'bg-slate-900 border-2 border-amber-300 text-amber-300',
              unlocked: completedForecasts.some(f => (f.actualGrade?.score || 0) === 100)
            },
            {
              id: 'global_reach',
              title: 'Regional Network',
              desc: 'Verify accuracy across at least 3 distinct geographic regions.',
              styles: 'bg-purple-600 text-white',
              unlocked: new Set(completedForecasts.map(f => f.location.split(',')[0])).size >= 3
            },
            {
              id: 'tempest',
              title: 'Hydrological Insight',
              desc: 'Accurately predict an active precipitation event (Score > 70%).',
              styles: 'bg-cyan-600 text-white',
              unlocked: completedForecasts.some(f => (f.actualGrade?.actualPrecip || 0) > 0 && (f.actualGrade?.score || 0) >= 70)
            },
            {
              id: 'streak_badge',
              title: 'Ironclad Consistency',
              desc: 'Maintain a 90% or higher precision average across at least 5 verified forecasts.',
              styles: 'bg-blue-600 text-white',
              unlocked: completedForecasts.length >= 5 && (completedForecasts.reduce((a, b) => a + (b.actualGrade?.score || 0), 0) / (completedForecasts.length || 1)) >= 90
            },
            {
              id: 'flashpoint_operative',
              title: 'Flashpoint Operative',
              desc: 'Successfully grade a high-severity flash transmission with over 80% precision.',
              styles: 'bg-red-600 text-white',
              unlocked: completedForecasts.some(f => f.type === 'flash' && (f.actualGrade?.score || 0) >= 80)
            },
            {
              id: 'neural_investigator',
              title: 'Neural Investigator',
              desc: 'Run an AI Deep Dive Synthesis on a verified forecast.',
              styles: 'bg-indigo-900 border border-indigo-500 text-white',
              unlocked: completedForecasts.some(f => f.deepDiveAnalysis)
            },
            {
              id: 'seasoned_vet',
              title: 'Bureau Director',
              desc: 'Complete accuracy benchmarks for 15 verified forecasting cycles.',
              styles: 'bg-slate-900 border border-slate-700 text-white',
              unlocked: completedForecasts.length >= 15
            }
          ].map(badge => (
            <div 
              key={badge.id}
              className={`p-6 border-2 transition-all duration-700 ${
                badge.unlocked 
                  ? `${badge.styles} border-transparent shadow-[8px_8px_0px_var(--shadow-color)] hover:translate-y-[-4px]` 
                  : 'theme-bg-primary theme-border opacity-50 grayscale scale-95'
              }`}
            >
              <div className="flex flex-col h-full justify-between gap-6">
                <div className="flex justify-between items-start">
                  <h4 className="text-[12px] font-black uppercase tracking-widest">{badge.title}</h4>
                  {badge.unlocked ? (
                    <ShieldCheck size={18} className="opacity-80" />
                  ) : (
                    <Clock size={16} className="theme-text-muted" />
                  )}
                </div>
                <p className={`text-[10px] leading-relaxed uppercase font-medium tracking-widest ${badge.unlocked ? 'opacity-90' : 'theme-text-secondary'}`}>
                  {badge.desc}
                </p>
                {!badge.unlocked && (
                  <div className="pt-4 border-t theme-border">
                    <span className="text-[8px] font-black uppercase tracking-[0.2em] theme-text-muted flex items-center gap-2">
                       Awaiting Telemetry Validation
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
