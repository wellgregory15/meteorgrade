import React, { useEffect, useState } from 'react';
import { db } from '../lib/db';
import { collection, query, orderBy, limit, getDocs, where } from '../lib/db';
import { Award, Trophy, Medal, Target, TrendingUp, User as UserIcon, Activity, Zap, Map as MapIcon, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { METEOROLOGICAL_SECTORS } from '../lib/meteorologicalSectors';

// Persistent session cache for leaders to avoid rapid refetching
const leadersCache = new Map<string, { data: any[], timestamp: number }>();
const CACHE_STALE_TIME = 180000; // 3 minutes

export default function LeaderboardView() {
  const [leaders, setLeaders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSector, setActiveSector] = useState<string>('global');
  const [activeLeague, setActiveLeague] = useState<'all' | 'junior' | 'senior'>('all');

  useEffect(() => {
    const fetchLeaders = async () => {
      const cacheKey = `${activeSector}_${activeLeague}`;
      // Check cache first
      const cached = leadersCache.get(cacheKey);
      if (cached && (Date.now() - cached.timestamp < CACHE_STALE_TIME)) {
        setLeaders(cached.data);
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        let results: any[] = [];
        if (activeSector === 'global') {
          // Standard Global User Standings
          let q = query(collection(db, 'users'), orderBy('precisionIndex', 'desc'), limit(50));
          
          if (activeLeague === 'junior') {
            q = query(collection(db, 'users'), where('tier', 'in', ['Novice', 'Specialist']), orderBy('precisionIndex', 'desc'), limit(50));
          } else if (activeLeague === 'senior') {
            q = query(collection(db, 'users'), where('tier', 'in', ['Sage', 'Legend']), orderBy('precisionIndex', 'desc'), limit(50));
          }

          const snapshot = await getDocs(q);
          results = snapshot.docs
            .map(doc => ({ id: doc.id, ...doc.data() } as any))
            .filter(user => (user.totalForecasts || 0) > 0)
            .slice(0, 10);
        } else {
          // Sector Specific Standings (Top Forecasts in this Sector)
          const q = query(
            collection(db, 'forecasts'), 
            where('sectorId', '==', activeSector),
            where('status', '==', 'completed'),
            orderBy('actualGrade.score', 'desc'), 
            limit(100)
          );
          const snapshot = await getDocs(q);
          
          const userMap = new Map();
          snapshot.docs.forEach(doc => {
            const f = doc.data() as any;
            if (!userMap.has(f.userId) && userMap.size < 10) {
              userMap.set(f.userId, {
                id: f.userId,
                displayName: f.displayName || 'Forecaster',
                precisionIndex: f.actualGrade?.score || 0,
                totalForecasts: 1, 
                streak: f.streak || 0,
                tier: 'Specialist',
                avatarUrl: f.avatarUrl
              });
            }
          });
          results = Array.from(userMap.values());
        }
        
        setLeaders(results);
        leadersCache.set(activeSector, { data: results, timestamp: Date.now() });
      } catch (err) {
        console.error("Leaderboard fetch failed", err);
      } finally {
        setLoading(false);
      }
    };
    fetchLeaders();
  }, [activeSector]);

  const getTierColor = (tier: string) => {
    switch(tier) {
      case 'Legend': return 'text-amber-500 border-amber-500 bg-amber-500/10';
      case 'Sage': return 'text-indigo-600 dark:text-indigo-400 border-indigo-600 dark:border-indigo-400 bg-indigo-500/10';
      case 'Specialist': return 'text-emerald-600 dark:text-emerald-400 border-emerald-600 dark:border-emerald-400 bg-emerald-500/10';
      default: return 'theme-text-muted theme-border theme-bg-primary';
    }
  };

  const currentSector = METEOROLOGICAL_SECTORS.find(s => s.id === activeSector);

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-20">
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 text-indigo-600 dark:text-indigo-400">
          <Trophy size={24} />
          <h2 className="text-4xl font-light uppercase tracking-tighter theme-text-primary">
            {activeSector === 'global' ? 'Global' : currentSector?.name.replace('Sector: ', '')} <span className="font-bold">Standings</span>
          </h2>
        </div>
        <p className="theme-text-secondary text-sm max-w-lg mx-auto leading-relaxed uppercase tracking-widest">
          {activeSector === 'global' 
            ? 'The Precision Index (PI) evaluates cumulative accuracy, Lead-Time-Locked bonuses, and multi-day campaign success.' 
            : `Evaluated performance within the ${currentSector?.description}`}
        </p>
      </div>

      {/* League Selection */}
      {activeSector === 'global' && (
        <div className="flex justify-center gap-4 mb-2">
          {[
            { id: 'all', label: 'All Ranks' },
            { id: 'junior', label: 'Junior League' },
            { id: 'senior', label: 'Senior Bureau' }
          ].map(league => (
            <button
              key={league.id}
              onClick={() => setActiveLeague(league.id as any)}
              className={`text-[9px] font-black uppercase tracking-[0.2em] pb-1 border-b-2 transition-all ${activeLeague === league.id ? 'border-indigo-500 text-indigo-400' : 'border-transparent theme-text-muted opacity-40 hover:opacity-100'}`}
            >
              {league.label}
            </button>
          ))}
        </div>
      )}

      {/* Sector Navigation */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        <button
          onClick={() => setActiveSector('global')}
          className={`px-4 py-2 text-[10px] font-bold uppercase tracking-widest border transition-all ${activeSector === 'global' ? 'theme-bg-primary theme-text-primary border-indigo-600' : 'theme-bg-secondary theme-text-muted theme-border opacity-60'}`}
        >
          Global
        </button>
        {METEOROLOGICAL_SECTORS.map(s => (
          <button
            key={s.id}
            onClick={() => setActiveSector(s.id)}
            className={`px-4 py-2 text-[10px] font-bold uppercase tracking-widest border transition-all ${activeSector === s.id ? 'theme-bg-primary theme-text-primary border-indigo-600' : 'theme-bg-secondary theme-text-muted theme-border opacity-60'}`}
          >
            {s.name.replace('Sector: ', '')}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center p-20 gap-4">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-[10px] font-bold uppercase tracking-widest theme-text-muted">Syncing Sector Data...</span>
        </div>
      ) : (
        <div className="theme-bg-secondary border theme-border theme-shadow transition-colors">
          <div className="min-w-0">
            <div className="grid grid-cols-[50px_1fr_80px] md:grid-cols-[80px_1fr_120px_120px] p-4 md:p-6 border-b theme-border theme-bg-primary text-[10px] font-bold uppercase tracking-widest theme-text-muted">
              <div>Rank</div>
              <div>Forecaster {activeSector !== 'global' && <span className="text-indigo-400 ml-1">(Top Performance)</span>}</div>
              <div className="text-right">PI Score</div>
              <div className="text-right hidden md:block">Tier</div>
            </div>

            <div className="divide-y theme-border">
              {leaders.length === 0 ? (
                <div className="p-20 text-center theme-text-muted italic text-sm uppercase tracking-widest">
                  No active transmissions in this sector have been established.
                </div>
              ) : (
                leaders.map((leader, i) => (
                  <motion.div 
                    key={leader.id}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: i * 0.1 }}
                    className="grid grid-cols-[50px_1fr_80px] md:grid-cols-[80px_1fr_120px_120px] p-4 md:p-8 items-center hover:theme-bg-primary transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      {i === 0 ? <Trophy size={18} className="text-amber-500 md:w-5 md:h-5" /> : 
                       i === 1 ? <Medal size={18} className="theme-text-muted md:w-5 md:h-5" /> :
                       i === 2 ? <Medal size={18} className="text-amber-700 md:w-5 md:h-5" /> :
                       <span className="text-xl md:text-2xl font-light theme-text-muted opacity-30 ml-1">{i + 1}</span>}
                    </div>

                    <div className="flex items-center gap-3 md:gap-4 overflow-hidden">
                      <div className="shrink-0 w-8 h-8 md:w-10 md:h-10 theme-bg-primary flex items-center justify-center rounded-sm overflow-hidden border theme-border">
                        {leader.avatarUrl ? (
                          <img src={leader.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                        ) : (
                          <UserIcon size={16} className="theme-text-muted opacity-50 md:w-5 md:h-5" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="font-bold theme-text-primary uppercase tracking-tight truncate text-xs md:text-sm">{leader.displayName || 'Anonymous Observer'}</div>
                        <div className="text-[9px] md:text-[10px] theme-text-muted flex flex-wrap items-center gap-x-2 gap-y-0.5 mt-0.5 uppercase">
                          <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold truncate">@{leader.displayName ? leader.displayName.split(' ')[0].toLowerCase() : 'analyst_pending'}</span>
                          <div className="flex items-center gap-1">
                            <TrendingUp size={10} className="theme-text-muted" />
                            {isNaN(leader.totalForecasts) ? 0 : (leader.totalForecasts || 0)} <span className="hidden xs:inline">{activeSector === 'global' ? 'Forecasts' : 'Sector Record'}</span>
                          </div>
                          {leader.streak > 0 && (
                            <div className="flex items-center gap-1 text-emerald-500 font-bold">
                              <Zap size={10} className="fill-emerald-500" />
                              {leader.streak}d <span className="hidden xs:inline">Streak</span>
                            </div>
                          )}
                        </div>
                        <div className="md:hidden mt-1.5">
                          <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 border rounded-none ${getTierColor(leader.tier)}`}>
                            {leader.tier || 'Novice'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right font-mono text-lg md:text-xl font-bold text-indigo-600 dark:text-indigo-400">
                      {isNaN(leader.precisionIndex) ? '0.0' : Number(leader.precisionIndex || 0).toFixed(1)}
                    </div>

                    <div className="text-right hidden md:block">
                      <span className={`text-[9px] font-black uppercase tracking-widest px-3 py-1 border rounded-none ${getTierColor(leader.tier)}`}>
                        {leader.tier || 'Novice'}
                      </span>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Ranks Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12">
        <div className="theme-bg-secondary border theme-border p-6 space-y-3 shadow-md">
          <Activity size={20} className="theme-text-muted" />
          <h4 className="text-[10px] font-bold uppercase tracking-widest theme-text-primary">Regional Scaling</h4>
          <p className="text-[11px] theme-text-secondary leading-relaxed uppercase tracking-widest opacity-80">
            Sectors like the Central Plains (1.25x) and Gulf Coast (1.20x) award bonus PI points due to high meteorological volatility.
          </p>
        </div>
        <div className="theme-bg-secondary border theme-border p-6 space-y-3 shadow-md">
          <Target size={20} className="theme-text-muted" />
          <h4 className="text-[10px] font-bold uppercase tracking-widest theme-text-primary">PI Weighted Index</h4>
          <p className="text-[11px] theme-text-secondary leading-relaxed uppercase tracking-widest opacity-80">
            Precision Index = (Accuracy + Lock-In Bonus) × Sector Multiplier. Strategic forecasters prioritize complex patterns.
          </p>
        </div>
        <div className="bg-indigo-600 dark:bg-indigo-900 border border-indigo-500/50 p-6 space-y-3 text-white shadow-xl shadow-indigo-500/20">
          <Award size={20} className="text-indigo-200" />
          <h4 className="text-[10px] font-bold uppercase tracking-widest">Bureau Calibration</h4>
          <p className="text-[11px] text-indigo-100 leading-relaxed uppercase tracking-widest opacity-90">
             Top regional performers are invited to join the Intelligence Synthesis board for high-value operations.
          </p>
        </div>
      </div>
    </div>
  );
}
