import React, { useState, useEffect } from 'react';
import { db } from '../lib/db';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp } from '../lib/db';
import { Send, Clock, CheckCircle, Mail, AlertCircle, RefreshCw } from 'lucide-react';
import { User } from '../lib/db';


export default function SupportView({ 
  user, 
  onRestartOnboarding 
}: { 
  user: User,
  onRestartOnboarding?: () => void
}) {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  useEffect(() => {
    const q = query(
      collection(db, 'supportTickets'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsub = onSnapshot(q, (snap) => {
      setTickets(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });

    return () => unsub();
  }, [user.uid]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');
    if (!subject.trim() || !description.trim()) {
      setSubmitError('Both subject and description are required.');
      return;
    }
    
    if (subject.length > 150) {
      setSubmitError('Subject is too long (max 150 characters).');
      return;
    }

    if (description.length > 2000) {
      setSubmitError('Description is too long (max 2000 characters).');
      return;
    }

    setIsSubmitting(true);
    
    // Create an optimistic ticket to show immediately
    const optimisticTicket = {
      id: crypto.randomUUID(),
      userId: user.uid,
      subject: subject.trim(),
      description: description.trim(),
      status: 'open',
      createdAt: new Date(), // Local fallback for immediate display
      isOptimistic: true
    };

    // Prepend to the tickets list immediately
    setTickets(prev => [optimisticTicket, ...prev]);

    try {
      await addDoc(collection(db, 'supportTickets'), {
        userId: user.uid,
        subject: subject.trim(),
        description: description.trim(),
        status: 'open',
        createdAt: serverTimestamp()
      });
      setSubject('');
      setDescription('');
    } catch (err: any) {
      console.error(err);
      // Remove the optimistic ticket on failure if needed, 
      // although onSnapshot will usually correct the state anyway.
      setTickets(prev => prev.filter(t => t.id !== optimisticTicket.id));
      setSubmitError(err.message || 'Failed to submit ticket');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full theme-bg-app">
      <div className="p-6 md:p-8 lg:p-12 max-w-5xl mx-auto w-full flex-1 overflow-y-auto">
        <div className="mb-8">
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase theme-text-muted mb-2 block">Bureau Channel</span>
          <h1 className="text-3xl md:text-4xl font-light tracking-tight theme-text-primary">
            Professional <span className="font-bold">Support</span>
          </h1>
          <p className="theme-text-secondary mt-2">Encountered an anomaly? Submit a support request for analysis.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Main Content: Support History */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center justify-between border-b theme-border pb-4">
              <h2 className="text-sm font-bold uppercase tracking-widest theme-text-primary flex items-center gap-2">
                <Clock size={16} className="theme-text-muted" />
                Support History
              </h2>
            </div>
            
            {loading ? (
              <div className="text-center py-12 theme-text-muted text-sm font-mono flex flex-col items-center gap-4 border theme-border border-dashed theme-bg-primary">
                <RefreshCw size={24} className="animate-spin text-indigo-400" />
                Syncing records...
              </div>
            ) : tickets.length === 0 ? (
              <div className="theme-bg-primary border theme-border border-dashed p-12 text-center theme-text-muted text-sm flex flex-col items-center gap-4">
                <Mail size={32} className="theme-text-muted opacity-50" />
                No prior support requests found in your records.
              </div>
            ) : (
              <div className="space-y-4">
              {tickets.map(ticket => (
                <div key={ticket.id} className="theme-bg-secondary border theme-border p-6 flex flex-col gap-4 theme-shadow hover:border-indigo-400 transition-colors">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h3 className="font-bold theme-text-primary">{ticket.subject}</h3>
                      <div className="text-xs theme-text-muted font-mono mt-1 flex items-center gap-2">
                        {ticket.createdAt ? new Date(ticket.createdAt?.toDate ? ticket.createdAt.toDate() : ticket.createdAt).toLocaleDateString() : 'Just now'} • {ticket.createdAt ? new Date(ticket.createdAt?.toDate ? ticket.createdAt.toDate() : ticket.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                      </div>
                    </div>
                    <div className="shrink-0">
                      {ticket.status === 'open' && <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-sm theme-bg-warning theme-text-warning text-[10px] font-bold uppercase tracking-widest border theme-border"><Clock size={12}/> Open</span>}
                      {ticket.status === 'in_progress' && <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-sm theme-bg-primary text-blue-600 dark:text-blue-400 text-[10px] font-bold uppercase tracking-widest border theme-border"><AlertCircle size={12}/> In Progress</span>}
                      {ticket.status === 'resolved' && <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-sm theme-bg-success theme-text-success text-[10px] font-bold uppercase tracking-widest border theme-border"><CheckCircle size={12}/> Resolved</span>}
                    </div>
                  </div>
                  <p className="text-sm theme-text-secondary whitespace-pre-wrap">{ticket.description}</p>
                  
                  {ticket.adminReply && (
                    <div className="mt-4 pt-4 border-t theme-border theme-bg-primary p-4 border-l-2 border-l-indigo-500">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400 mb-2">Bureau Response</div>
                      <p className="text-sm theme-text-primary whitespace-pre-wrap">{ticket.adminReply}</p>
                    </div>
                  )}
                </div>
              ))}
              </div>
            )}
          </div>

          {/* Right Sidebar: Actions */}
          <div className="lg:col-span-5 space-y-6">
            <div className="theme-bg-secondary border theme-border p-6 theme-shadow">
              <h2 className="text-sm font-bold uppercase tracking-widest theme-text-primary mb-6 flex items-center gap-2">
                <Mail size={16} className="text-indigo-600 dark:text-indigo-400" />
                New Request
              </h2>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest theme-text-muted mb-2">Subject</label>
                  <input
                    type="text"
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                    className="w-full theme-bg-input border theme-border px-3 py-2 text-sm focus:border-indigo-600 outline-none transition-all theme-text-primary font-mono placeholder:theme-text-muted"
                    placeholder="Brief description of the issue"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest theme-text-muted mb-2">Details</label>
                  <textarea
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    rows={5}
                    className="w-full theme-bg-input border theme-border px-3 py-2 text-sm focus:border-indigo-600 outline-none transition-all resize-none theme-text-primary font-mono placeholder:theme-text-muted"
                    placeholder="Provide full context about the anomaly..."
                  />
                </div>
                
                {submitError && (
                  <div className="p-3 theme-bg-error theme-text-error text-xs flex items-center gap-2 border theme-border font-mono">
                    <AlertCircle size={14} className="shrink-0" />
                    {submitError}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`w-full flex items-center justify-center gap-2 py-3 px-4 font-bold uppercase tracking-widest text-[11px] transition-all border theme-border ${
                    isSubmitting ? 'opacity-50 cursor-not-allowed theme-bg-primary theme-text-muted' : 'bg-slate-900 dark:bg-indigo-600 text-white hover:opacity-90 shadow-[4px_4px_0px_var(--shadow-color)]'
                  }`}
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Request'}
                  {!isSubmitting && <Send size={14} />}
                </button>
              </form>
            </div>

            <div className="space-y-6">

              <button 
                onClick={onRestartOnboarding}
                className="w-full border theme-border theme-bg-secondary hover:theme-bg-primary theme-text-secondary px-4 py-3 text-[10px] font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all theme-shadow group"
              >
                <RefreshCw size={14} className="theme-text-muted group-hover:text-indigo-400 transition-colors" />
                Restart Terminal Onboarding
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}