import { useState, useEffect, useRef } from 'react';
import { db, collection, query, where, addDoc, serverTimestamp, onSnapshot, orderBy, limit, deleteDoc, doc } from '../lib/db';
import { Send, User, Shield, Target, Radio, AlertTriangle, MoreVertical, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SyndicateChatProps {
  syndicateId: string;
  user: any;
  profile: any;
}

export default function SyndicateChat({ syndicateId, user, profile }: SyndicateChatProps) {
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [showReportModal, setShowReportModal] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!syndicateId) return;

    const messagesQuery = query(
      collection(db, 'syndicate_messages'),
      where('syndicateId', '==', syndicateId),
      orderBy('createdAt', 'asc'),
      limit(100)
    );

    const unsubscribe = onSnapshot(messagesQuery, (snap: any) => {
      const msgs = snap.docs.map((d: any) => ({ id: d.id, ...d.data() }));
      setMessages(msgs);
      
      // Auto scroll
      setTimeout(() => {
        if (scrollRef.current) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
      }, 100);
    });

    return () => unsubscribe();
  }, [syndicateId]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || isSending) return;

    const content = newMessage.trim();
    const tempId = `temp-${Date.now()}`;
    
    // Optimistic Update
    const optimisticMsg = {
      id: tempId,
      syndicateId,
      userId: user.uid,
      userName: profile?.displayName || user.displayName || 'Analyst',
      content: content,
      createdAt: new Date().toISOString(),
      isOptimistic: true
    };
    
    setMessages(prev => [...prev, optimisticMsg]);
    setNewMessage('');
    
    setTimeout(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
    }, 10);

    setIsSending(true);
    try {
      await addDoc(collection(db, 'syndicate_messages'), {
        syndicateId,
        userId: user.uid,
        userName: profile?.displayName || user.displayName || 'Analyst',
        content: content,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.error("Chat send error:", err);
      setMessages(prev => prev.filter(m => m.id !== tempId));
    } finally {
      setIsSending(false);
    }
  };

  const handleReport = async () => {
    if (!showReportModal || !reportReason.trim()) return;

    try {
      await addDoc(collection(db, 'chat_reports'), {
        messageId: showReportModal,
        syndicateId,
        reporterId: user.uid,
        reason: reportReason,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setShowReportModal(null);
      setReportReason('');
      alert("Message reported for review.");
    } catch (err) {
      console.error("Report error:", err);
    }
  };

  const handleDelete = async (msgId: string) => {
    if (!window.confirm("Delete this message?")) return;
    try {
      await deleteDoc(doc(db, 'syndicate_messages', msgId));
    } catch (err) {
      console.error("Delete error:", err);
    }
  };

  return (
    <div className="flex flex-col h-[600px] theme-bg-secondary border theme-border overflow-hidden relative">
      {/* Report Modal */}
      <AnimatePresence>
        {showReportModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <div className="bg-white dark:bg-slate-900 border theme-border p-8 max-w-sm w-full shadow-2xl">
              <h3 className="text-sm font-black uppercase tracking-widest mb-4">Report Message</h3>
              <p className="text-[10px] theme-text-muted uppercase tracking-widest mb-4">Select violation reason:</p>
              <select 
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full theme-bg-secondary border theme-border p-3 text-xs mb-6 focus:outline-none focus:border-indigo-600"
              >
                <option value="">Choose reason...</option>
                <option value="harassment">Harassment</option>
                <option value="spam">Spam / Low Logic</option>
                <option value="misinfo">Dangerous Misinformation</option>
                <option value="other">Other Violation</option>
              </select>
              <div className="flex gap-4">
                <button 
                  onClick={() => setShowReportModal(null)}
                  className="flex-1 py-3 text-[10px] font-bold uppercase tracking-widest border theme-border hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleReport}
                  disabled={!reportReason}
                  className="flex-1 py-3 text-[10px] font-bold uppercase tracking-widest bg-red-600 text-white hover:bg-red-700 disabled:opacity-50"
                >
                  Submit Report
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Header */}
      <div className="p-4 border-b theme-border flex items-center justify-between bg-slate-900/5 dark:bg-white/5">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] theme-text-primary">Syndicate Secure Channel</h3>
        </div>
        <div className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">End-to-End Encrypted Logic</div>
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar"
      >
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center opacity-30 text-center space-y-4">
            <Radio size={32} />
            <p className="text-[10px] font-bold uppercase tracking-widest">Awaiting Communication...</p>
          </div>
        ) : (
          messages.map((msg, i) => {
            const isMe = msg.userId === user.uid;
            const isAdmin = profile?.role === 'admin' || profile?.role === 'commander';
            const isOptimistic = msg.isOptimistic;

            return (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: isOptimistic ? 0.7 : 1, y: 0 }}
                key={msg.id || i}
                className={`flex flex-col group ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div className={`flex items-center gap-2 mb-1 ${isMe ? 'flex-row-reverse text-right' : 'text-left'}`}>
                  <span className="text-[9px] font-black uppercase tracking-tight text-indigo-600">
                    {msg.userName}
                  </span>
                  <span className="text-[7px] font-bold text-slate-400 uppercase">
                    {msg.createdAt ? new Date(msg.createdAt?.toDate ? msg.createdAt.toDate() : msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '...'}
                  </span>
                  
                  {/* Action Menu */}
                  {!isMe && !isOptimistic && (
                    <button 
                      onClick={() => setShowReportModal(msg.id)}
                      className="opacity-40 hover:opacity-100 p-1 text-slate-400 hover:text-red-500 transition-all ml-2 flex items-center gap-1"
                      title="Report message"
                    >
                      <AlertTriangle size={14} />
                      <span className="text-[8px] font-bold uppercase hidden group-hover:block">Report</span>
                    </button>
                  )}
                  {isAdmin && !isOptimistic && (
                    <button 
                      onClick={() => handleDelete(msg.id)}
                      className="opacity-40 hover:opacity-100 p-1 text-slate-400 hover:text-red-500 transition-all ml-1"
                      title="Delete message"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
                <div 
                  className={`max-w-[80%] p-3 text-xs leading-relaxed ${
                    isMe 
                      ? 'bg-indigo-600 text-white rounded-l-lg rounded-tr-sm shadow-[4px_4px_0px_rgba(79,70,229,0.2)]' 
                      : 'theme-bg-primary theme-text-primary border theme-border rounded-r-lg rounded-tl-sm'
                  } ${isOptimistic ? 'animate-pulse' : ''}`}
                >
                  {msg.content}
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-4 border-t theme-border theme-bg-primary">
        <div className="flex gap-2">
          <input 
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Transmit tactical data..."
            className="flex-1 theme-bg-secondary border theme-border px-4 py-3 text-xs focus:outline-none focus:border-indigo-600 theme-text-primary"
            disabled={isSending}
          />
          <button 
            type="submit"
            disabled={!newMessage.trim() || isSending}
            className="px-6 bg-indigo-600 text-white flex items-center justify-center hover:bg-slate-900 transition-all disabled:opacity-50"
          >
            <Send size={16} />
          </button>
        </div>
      </form>
    </div>
  );
}
