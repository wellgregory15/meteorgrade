import { useState, useEffect, useRef } from 'react';
import { db, getAuth } from '../lib/db';
import { collection, query, where, getDocs, addDoc, serverTimestamp, onSnapshot, doc, getDoc, updateDoc, deleteDoc, orderBy, limit } from '../lib/db';
import { Users, Shield, Trophy, Map, ArrowRight, Loader2, Search, Plus, MessageSquare, Check, LogOut, ChevronRight, MoreVertical, UserMinus, UserPlus, ShieldAlert, Zap, Target, Radio, TrendingUp, Lock, Upload, BookOpen, GraduationCap, ExternalLink, AlertTriangle, Trash2, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import StrategicDeploymentMap from './StrategicDeploymentMap';
import SyndicateChat from './SyndicateChat';
import WeatherLabReport from './WeatherLabReport';

interface SyndicateViewProps {
  user: any;
  profile?: any;
}

export default function SyndicateView({ user, profile }: SyndicateViewProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'leaderboard' | 'create' | 'ops' | 'map' | 'chat' | 'classroom'>('overview');
  const [syndicate, setSyndicate] = useState<any>(null);
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Create Form
  const [newName, setNewName] = useState('');
  const [newTag, setNewTag] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [isInviteOnly, setIsInviteOnly] = useState(false);
  const [isClassroom, setIsClassroom] = useState(false);
  const [orgName, setOrgName] = useState('');
  const [learningObjectives, setLearningObjectives] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [isJoiningCode, setIsJoiningCode] = useState(false);
  const [isMigrating, setIsMigrating] = useState(false);

  const handleMigrateJoinCodes = async () => {
    if (!window.confirm("This will generate unique join codes for ALL existing classroom syndicates that lack them. Proceed?")) return;
    
    setIsMigrating(true);
    try {
      const q = query(collection(db, 'syndicates'), where('is_classroom', '==', true));
      const snap = await getDocs(q);
      
      let updatedCount = 0;
      for (const docSnap of snap.docs) {
        const data = docSnap.data();
        if (!data.join_code && !data.joinCode) {
          const newCode = Math.random().toString(36).substring(2, 8).toUpperCase();
          const docRef = doc(db, 'syndicates', docSnap.id);
          await updateDoc(docRef, { join_code: newCode });
          updatedCount++;
        }
      }
      alert(`Migration complete. ${updatedCount} classroom syndicates updated with new join codes.`);
    } catch (err: any) {
      alert("Migration failed: " + err.message);
    } finally {
      setIsMigrating(false);
    }
  };

  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteTagInput, setDeleteTagInput] = useState('');

  const handleDeleteSyndicate = async () => {
    console.log("Decommission triggered...");
    if (!syndicate) {
      alert("System Error: Syndicate data not loaded.");
      return;
    }
    
    // Check both camelCase and snake_case for creator ID
    const cId = syndicate.creatorId || syndicate.creator_id;
    const isOwner = cId === user.uid;
    
    if (!isCommander && !isOwner) {
      alert(`Unauthorized: Your current rank (${userRole}) does not permit decommissioning.`);
      return;
    }

    if (deleteTagInput !== syndicate.tag) {
      alert(`Verification Failed: Please type "${syndicate.tag}" exactly.`);
      return;
    }

    setIsDeleting(true);
    try {
      await deleteDoc(doc(db, 'syndicates', syndicate.id));
      alert("Syndicate successfully decommissioned. Redirecting to Hub...");
      window.location.reload(); 
    } catch (err: any) {
      console.error("Decommissioning error:", err);
      alert("Decommissioning failed: " + err.message);
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
      setDeleteTagInput('');
    }
  };

  // Requests
  const [pendingRequests, setPendingRequests] = useState<any[]>([]);
  const [myPendingRequest, setMyPendingRequest] = useState<any>(null);

  // Search
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const [globalSyndicates, setGlobalSyndicates] = useState<any[]>([]);
  const [sectorControl, setSectorControl] = useState<any[]>([]);

  const [briefings, setBriefings] = useState<any[]>([]);
  const [broadcasts, setBroadcasts] = useState<any[]>([]);
  const [activeOperations, setActiveOperations] = useState<any[]>([]);
  const [memberForecasts, setMemberForecasts] = useState<any[]>([]);
  const [selectedReportForecast, setSelectedReportForecast] = useState<any>(null);
  
  // Commander Actions
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Operation Creation
  const [showOpForm, setShowOpForm] = useState(false);
  const [opTitle, setOpTitle] = useState('');
  const [opDesc, setOpDesc] = useState('');
  const [opEndDate, setOpEndDate] = useState('');
  const [opCategory, setOpCategory] = useState('Verification');
  const [isCreatingOp, setIsCreatingOp] = useState(false);

  const handleCreateOperation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!opTitle || !opEndDate) return;
    setIsCreatingOp(true);
    try {
      await addDoc(collection(db, 'missions'), {
        title: opTitle,
        description: opDesc,
        category: opCategory,
        end_date: opEndDate,
        syndicate_id: syndicate.id,
        user_id: user.uid,
        status: 'active',
        is_global: false,
        created_at: serverTimestamp()
      });
      setShowOpForm(false);
      setOpTitle('');
      setOpDesc('');
      setOpEndDate('');
    } catch (err: any) {
      alert("Operation failed to launch: " + err.message);
    } finally {
      setIsCreatingOp(false);
    }
  };

  const childUnsubscribesRef = useRef<(() => void)[]>([]);

  useEffect(() => {
    // 1. Listen for user profile membership status changes
    setLoading(true);
    const memberQuery = query(collection(db, 'syndicate_members'), where('userId', '==', user.uid));
    
    const unsubscribeUserMembership = onSnapshot(memberQuery, async (snap: any) => {
      // Clean up previous syndicate-specific listeners
      childUnsubscribesRef.current.forEach(u => u());
      childUnsubscribesRef.current = [];

      if (snap.empty) {
        setSyndicate(null);
        setMembers([]);
        setLoading(false);
        
        // Fetch my pending request if not in a syndicate
        const reqQuery = query(collection(db, 'syndicate_requests'), where('userId', '==', user.uid), where('status', '==', 'pending'));
        const reqSnap = await getDocs(reqQuery);
        if (!reqSnap.empty) {
          setMyPendingRequest(reqSnap.docs[0].data());
        } else {
          setMyPendingRequest(null);
        }
        return;
      }

      const membership = snap.docs[0].data();
      const synDocId = membership.syndicateId;

      // 2. Set up syndicate-specific listeners
      const synDocRef = doc(db, 'syndicates', synDocId);
      
      const unsubscribeSyn = onSnapshot(synDocRef, (sDoc: any) => {
        if (sDoc.exists()) {
          setSyndicate({ id: sDoc.id, ...sDoc.data() });
        }
        setLoading(false);
      });
      childUnsubscribesRef.current.push(unsubscribeSyn);

      // Listen for members
      const squadMemberQuery = query(collection(db, 'syndicate_members'), where('syndicateId', '==', synDocId));
      const unsubscribeMembers = onSnapshot(squadMemberQuery, async (mSnap: any) => {
        const memberList = mSnap.docs.map((d: any) => d.data());
        const profiles = await Promise.all(memberList.map(async (m: any) => {
          const uDoc = await getDoc(doc(db, 'users', m.userId));
          return { ...m, profile: uDoc.exists() ? uDoc.data() : null };
        }));
        setMembers(profiles);
      });
      childUnsubscribesRef.current.push(unsubscribeMembers);

      // Listen for briefings
      const briefingsQuery = query(
        collection(db, 'forecasts'), 
        where('syndicate_id', '==', synDocId),
        where('status', '!=', 'completed')
      );
      const unsubscribeBriefings = onSnapshot(briefingsQuery, (fSnap: any) => {
        const list = fSnap.docs.map((d: any) => ({ id: d.id, ...d.data() }));
        list.sort((a: any, b: any) => {
          const dateA = a.createdAt?.toDate ? a.createdAt.toDate() : a.createdAt;
          const dateB = b.createdAt?.toDate ? b.createdAt.toDate() : b.createdAt;
          return new Date(dateB).getTime() - new Date(dateA).getTime();
        });
        setBriefings(list);
      });
      childUnsubscribesRef.current.push(unsubscribeBriefings);

      // Listen for broadcasts
      const broadcastsQuery = query(
        collection(db, 'syndicate_broadcasts'),
        where('syndicate_id', '==', synDocId),
        orderBy('created_at', 'desc'),
        limit(5)
      );
      const unsubscribeBroadcasts = onSnapshot(broadcastsQuery, (bSnap: any) => {
        setBroadcasts(bSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      });
      childUnsubscribesRef.current.push(unsubscribeBroadcasts);


      // Listen for Join Requests if commander/officer
      if (membership.role === 'commander' || membership.role === 'officer') {
        const requestsQuery = query(
          collection(db, 'syndicate_requests'),
          where('syndicate_id', '==', synDocId),
          where('status', '==', 'pending')
        );
        const unsubscribeRequests = onSnapshot(requestsQuery, async (rSnap: any) => {
          const reqList = rSnap.docs.map((d: any) => ({ id: d.id, ...d.data() }));
          const withProfiles = await Promise.all(reqList.map(async (r: any) => {
            const uDoc = await getDoc(doc(db, 'users', r.user_id));
            return { ...r, profile: uDoc.exists() ? uDoc.data() : null };
          }));
          setPendingRequests(withProfiles);
        });
        childUnsubscribesRef.current.push(unsubscribeRequests);
      }

      // Initial sector setup (one-time fetch or separate listener if needed)
      const fetchSectorData = async () => {
        const forecastQuery = query(collection(db, 'forecasts'), where('syndicate_id', '==', synDocId), where('status', '==', 'completed'));
        const fSnap = await getDocs(forecastQuery);
        const sectorMap: Record<string, number> = {};
        fSnap.docs.forEach(d => {
          const f = d.data();
          if (f.sectorId) {
            sectorMap[f.sectorId] = (sectorMap[f.sectorId] || 0) + (f.actualGrade?.weightedScore || 0);
          }
        });
        const sectorData = Object.entries(sectorMap).map(([id, score]) => ({
          id,
          influence: Math.min(100, Math.round(score / 5)) 
        })).sort((a,b) => b.influence - a.influence);
        setSectorControl(sectorData.slice(0, 3));
      };
      
      fetchSectorData();

      // Listen for all forecasts in this syndicate (for classroom/leaderboard depth)
      const allForecastsQuery = query(
        collection(db, 'forecasts'),
        where('syndicate_id', '==', synDocId),
        orderBy('createdAt', 'desc')
      );
      const unsubscribeAllForecasts = onSnapshot(allForecastsQuery, (fSnap: any) => {
        setMemberForecasts(fSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      });
      childUnsubscribesRef.current.push(unsubscribeAllForecasts);

      // Listen for syndicate-specific operations (missions)
      const opsQuery = query(
        collection(db, 'missions'),
        where('syndicateId', '==', synDocId),
        orderBy('createdAt', 'desc')
      );
      const unsubscribeOps = onSnapshot(opsQuery, (oSnap: any) => {
        const list = oSnap.docs.map((d: any) => ({ id: d.id, ...d.data() }));
        setActiveOperations(list);
      });
      childUnsubscribesRef.current.push(unsubscribeOps);
    });

    // Global Rankings Listener
    const q = query(collection(db, 'syndicates'), orderBy('totalPi', 'desc'), limit(10));
    const unsubscribeGlobal = onSnapshot(q, (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      // Filter out classroom syndicates from public discovery
      setGlobalSyndicates(list.filter((s: any) => !s.is_classroom));
    }, (err) => {
      console.error("Global rankings fetch error", err);
    });

    return () => {
      unsubscribeUserMembership();
      unsubscribeGlobal();
      childUnsubscribesRef.current.forEach(u => u());
    };
  }, [user.uid]);


  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newTag || newTag.length > 4) return;
    
    setIsCreating(true);
    try {
      const joinCode = isClassroom ? Math.random().toString(36).substring(2, 8).toUpperCase() : null;
      
      const synRef = await addDoc(collection(db, 'syndicates'), {
        name: newName,
        tag: newTag.toUpperCase(),
        description: newDesc,
        isInviteOnly: isClassroom ? true : isInviteOnly,
        isClassroom: isClassroom,
        organization_name: orgName,
        learning_objectives: learningObjectives,
        join_code: joinCode,
        creatorId: user.uid,
        totalPi: 0,
        memberCount: 1,
        createdAt: serverTimestamp()
      });

      await addDoc(collection(db, 'syndicate_members'), {
        syndicate_id: synRef.id,
        user_id: user.uid,
        role: 'commander',
        joined_at: serverTimestamp()
      });

        await updateDoc(doc(db, 'users', user.uid), { syndicateId: synRef.id });

      setNewName('');
      setNewTag('');
      setNewDesc('');
      setActiveTab('overview');
    } catch (err: any) {
      alert("Creation failed: " + err.message);
    } finally {
      setIsCreating(false);
    }
  };

  const handleJoin = async (synId: string, inviteOnly: boolean) => {
    try {
      if (inviteOnly) {
        // Create request
        await addDoc(collection(db, 'syndicate_requests'), {
          syndicate_id: synId,
          user_id: user.uid,
          status: 'pending',
          created_at: serverTimestamp()
        });
        setMyPendingRequest({ syndicate_id: synId, status: 'pending' });
        alert("Enlistment Request Transmitted: Awaiting Commander approval.");
        return;
      }

      await addDoc(collection(db, 'syndicate_members'), {
        syndicate_id: synId,
        user_id: user.uid,
        role: 'analyst',
        joined_at: serverTimestamp()
      });
      // Update user profile
      await updateDoc(doc(db, 'users', user.uid), { syndicateId: synId });

      // Increment member count
      const synDoc = await getDoc(doc(db, 'syndicates', synId));
      if (synDoc.exists()) {
        const currentCount = synDoc.data().memberCount || 0;
        await updateDoc(doc(db, 'syndicates', synId), { memberCount: currentCount + 1 });
      }
    } catch (err: any) {
      alert("Join failed: " + err.message);
    }
  };

  const handleJoinByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCodeInput || isJoiningCode) return;
    
    setIsJoiningCode(true);
    try {
      const q = query(collection(db, 'syndicates'), where('join_code', '==', joinCodeInput.toUpperCase()));
      const snap = await getDocs(q);
      
      if (snap.empty) {
        alert("Invalid Join Code: No classroom found with this identifier.");
        return;
      }
      
      const synData = snap.docs[0].data();
      const synId = snap.docs[0].id;
      
      // Check if already a member (should be handled by security rules but good for UI)
      const existingQuery = query(collection(db, 'syndicate_members'), where('syndicate_id', '==', synId), where('user_id', '==', user.uid));
      const existingSnap = await getDocs(existingQuery);
      if (!existingSnap.empty) {
        alert("Already Enrolled: You are already a member of this syndicate.");
        return;
      }
      
      await handleJoin(synId, synData.isInviteOnly || false);
      setJoinCodeInput('');
    } catch (err: any) {
      alert("Enrollment failed: " + err.message);
    } finally {
      setIsJoiningCode(false);
    }
  };

  const handlePostBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMsg || !syndicate) return;
    setIsBroadcasting(true);
    try {
      await addDoc(collection(db, 'syndicate_broadcasts'), {
        syndicate_id: syndicate.id,
        title: broadcastTitle,
        message: broadcastMsg,
        created_at: serverTimestamp(),
        author_id: user.uid
      });
      setBroadcastTitle('');
      setBroadcastMsg('');
    } catch (err: any) {
      alert("Broadcast failed: " + err.message);
    } finally {
      setIsBroadcasting(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !syndicate) return;

    if (file.size > 1024 * 512) {
      alert("Logo too large. Max 512KB.");
      return;
    }

    setIsUploadingLogo(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        await updateDoc(doc(db, 'syndicates', syndicate.id), {
          logo_url: base64String
        });
        alert("Syndicate Logo Updated.");
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      alert("Upload failed: " + err.message);
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleSearch = async () => {
    if (!searchTerm) return;
    try {
      const q = query(collection(db, 'syndicates'), where('tag', '==', searchTerm.toUpperCase()));
      const snap = await getDocs(q);
      setSearchResults(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    }
  };

  const currentMemberRecord = members.find(m => m.userId === user.uid);
  const userRole = currentMemberRecord?.role || 'analyst';
  const isCommander = userRole === 'commander' || userRole === 'officer';

  const handleActionRequest = async (requestId: string, action: 'approved' | 'denied') => {
    try {
      const reqDoc = await getDoc(doc(db, 'syndicate_requests', requestId));
      if (!reqDoc.exists()) return;
      
      const reqData = reqDoc.data();
      
      if (action === 'approved') {
        // Add to members
        await addDoc(collection(db, 'syndicate_members'), {
          syndicate_id: syndicate.id,
          user_id: reqData.user_id,
          role: 'analyst',
          joined_at: serverTimestamp()
        });
        
        // Update user
        await updateDoc(doc(db, 'users', reqData.user_id), { syndicate_id: syndicate.id });
        
        // Increment count
        await updateDoc(doc(db, 'syndicates', syndicate.id), { 
          memberCount: (syndicate.memberCount || 0) + 1 
        });
      }
      
      // Update request status
      await updateDoc(doc(db, 'syndicate_requests', requestId), { status: action });
      
      // Force refresh as requested by user
      window.location.reload();
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateRole = async (targetUserId: string, newRole: string) => {
    if (userRole !== 'commander') return;
    try {
      const q = query(
        collection(db, 'syndicate_members'), 
        where('syndicateId', '==', syndicate.id),
        where('userId', '==', targetUserId)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        await updateDoc(doc(db, 'syndicate_members', snap.docs[0].id), { role: newRole });
      }
    } catch (err) {
      console.error("Role update failed:", err);
    }
  };

  const handleKickMember = async (targetUserId: string) => {
    const targetMember = members.find(m => m.userId === targetUserId);
    if (!targetMember) return;

    // Permissions check
    const canKick = (userRole === 'commander') || (userRole === 'officer' && targetMember.role === 'analyst');
    if (!canKick) return;

    if (!confirm(`Are you sure you want to remove ${targetMember.profile?.displayName || 'this member'}?`)) return;

    try {
      const q = query(
        collection(db, 'syndicate_members'), 
        where('syndicateId', '==', syndicate.id),
        where('userId', '==', targetUserId)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        // Delete membership
        for (const d of snap.docs) {
          await deleteDoc(doc(db, 'syndicate_members', d.id));
        }

        // Update user profile
        await updateDoc(doc(db, 'users', targetUserId), { syndicateId: null });

        // Decrement member count
        const currentCount = syndicate.memberCount || 1;
        await updateDoc(doc(db, 'syndicates', syndicate.id), { 
          memberCount: Math.max(1, currentCount - 1) 
        });
      }
    } catch (err) {
      console.error("Kick failed:", err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="animate-spin text-indigo-600" size={32} />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8 relative">
      {/* Classroom Lab Report Overlay */}
      <AnimatePresence>
        {selectedReportForecast && (
          <WeatherLabReport 
            forecast={selectedReportForecast}
            student={members.find(m => m.userId === selectedReportForecast.userId)}
            syndicate={syndicate}
            onClose={() => setSelectedReportForecast(null)}
          />
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
        <div className="space-y-1">
          <span className="text-[10px] font-bold tracking-[0.3em] uppercase text-indigo-600">Operations Hub</span>
          <h1 className="text-4xl font-black tracking-tighter theme-text-primary uppercase">
            Syndicate <span className="text-slate-400">Terminal</span>
          </h1>
          <p className="text-xs theme-text-muted max-w-md uppercase tracking-wider font-medium">
            Form high-precision squads to dominate regional sectors and share deep-atmosphere logic.
          </p>
        </div>

        {syndicate ? (
          <div className="flex items-center gap-4 p-4 border theme-border theme-bg-secondary rounded-sm relative group overflow-hidden">
            {/* Background Glow for important info */}
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-indigo-600/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="w-16 h-16 flex items-center justify-center theme-bg-primary border-2 border-indigo-600 text-indigo-600 font-black text-xl overflow-hidden relative shadow-[4px_4px_0px_rgba(79,70,229,0.1)]">
              {syndicate.logo_url ? (
                <img src={syndicate.logo_url} className="w-full h-full object-cover" />
              ) : (
                syndicate.tag
              )}
              {isCommander && (
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-black/60 text-white opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1"
                >
                  <Upload size={16} />
                  <span className="text-[8px] font-black uppercase tracking-tighter">Update</span>
                </button>
              )}
            </div>
            
            <div className="flex-1">
              <h4 className="text-sm font-black uppercase tracking-widest flex items-center gap-2">
                {syndicate.name}
                {syndicate.is_classroom && <GraduationCap size={14} className="text-indigo-600" />}
              </h4>
              <div className="flex flex-wrap items-center gap-3 mt-1">
                <p className="text-[10px] font-bold text-emerald-500 uppercase tracking-tighter flex items-center gap-2">
                  Status: Active 
                  <span className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                </p>
                {isCommander && (syndicate.joinCode || syndicate.join_code) && (
                  <div className="px-2 py-0.5 theme-bg-primary border theme-border text-[9px] font-black text-indigo-600 flex items-center gap-2 ring-1 ring-indigo-600/20">
                    <span className="opacity-50">JOIN CODE:</span>
                    <span className="tracking-widest">{syndicate.joinCode || syndicate.join_code}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <button 
            onClick={() => setActiveTab('create')}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20"
          >
            Form New Syndicate <Plus size={14} />
          </button>
        )}
      </div>

      {/* Navigation Tabs - Only show if in a syndicate */}
      {syndicate && (
        <div className="flex overflow-x-auto gap-1 mb-8 border-b theme-border no-scrollbar">
          {[
            { id: 'overview', label: 'Command Center', icon: Radio },
            { id: 'ops', label: 'Operations', icon: Target },
            { id: 'chat', label: 'Secure Channel', icon: MessageSquare },
            { id: 'map', label: 'Deployment Map', icon: Map },
            { id: 'leaderboard', label: 'Rankings', icon: Trophy },
            ...(syndicate?.is_classroom ? [{ id: 'classroom', label: isCommander ? 'Teacher HQ' : 'Study Hall', icon: GraduationCap }] : [])
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-4 text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'theme-bg-secondary theme-text-primary border-b-2 border-indigo-600' 
                  : 'theme-text-muted hover:theme-text-primary hover:theme-bg-secondary/50'
              }`}
            >
              <tab.icon size={14} />
              {tab.label}
            </button>
          ))}
        </div>
      )}

      {activeTab === 'leaderboard' ? (
        <div className="space-y-8">
          <button onClick={() => setActiveTab('overview')} className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-indigo-600 transition-colors">
            <ArrowRight className="rotate-180" size={14} /> Back to Hub
          </button>
          
          <div className="grid grid-cols-1 gap-4">
             <div className="flex items-center justify-between border-b theme-border pb-4">
                <div>
                  <h3 className="text-xl font-black uppercase tracking-tighter">Global Rankings</h3>
                  <p className="text-[10px] theme-text-muted uppercase tracking-widest font-bold">The current hierarchy of meteorological intelligence.</p>
                </div>
                <Trophy size={32} className="text-amber-500 opacity-20" />
              </div>

              <div className="theme-bg-secondary border theme-border overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b theme-border bg-slate-900/5 dark:bg-white/5">
                      <th className="p-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Rank</th>
                      <th className="p-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Syndicate</th>
                      <th className="p-4 text-[10px] font-black uppercase tracking-widest text-slate-400 text-center">Members</th>
                      <th className="p-4 text-[10px] font-black uppercase tracking-widest text-slate-400 text-right">Avg Precision Index</th>
                    </tr>
                  </thead>
                  <tbody>
                    {globalSyndicates.map((s, i) => (
                      <tr key={s.id} className="border-b theme-border last:border-0 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                        <td className="p-4">
                          <span className={`text-sm font-black ${i < 3 ? 'text-amber-500' : 'theme-text-muted'}`}>#{i + 1}</span>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 flex items-center justify-center theme-bg-primary border border-indigo-600/30 text-indigo-600 font-black text-[10px] overflow-hidden">
                              {s.logo_url ? (
                                <img src={s.logo_url} className="w-full h-full object-cover" />
                              ) : (
                                s.tag
                              )}
                            </div>
                            <div>
                              <div className="text-sm font-black uppercase tracking-tight">{s.name}</div>
                              <div className="text-[8px] font-bold theme-text-muted uppercase tracking-widest">Active Ops</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-center">
                          <span className="text-xs font-bold theme-text-secondary">{s.memberCount || 0}</span>
                        </td>
                        <td className="p-4 text-right">
                          <span className="text-sm font-black text-emerald-500">{s.totalPi || 0}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      ) : activeTab === 'classroom' ? (
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="flex items-center gap-4">
              <button onClick={() => setActiveTab('overview')} className="p-2 theme-bg-secondary border theme-border hover:theme-bg-primary transition-colors">
                <ChevronRight className="rotate-180" size={20} />
              </button>
              <div>
                <h2 className="text-2xl font-black uppercase tracking-tighter flex items-center gap-3">
                  <GraduationCap className="text-indigo-600" size={28} />
                  {isCommander ? 'Meteor Grade: Teacher HQ' : 'Meteor Grade: Study Hall'}
                </h2>
                <div className="flex items-center gap-2">
                  <p className="text-[10px] theme-text-muted uppercase tracking-widest font-bold">
                    {syndicate?.organization_name || 'Classroom'} Academic Portal
                  </p>
                  <span className="w-1 h-1 rounded-full bg-indigo-600" />
                  <span className="text-[8px] font-black uppercase text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">NGSS-Aligned</span>
                </div>
              </div>
            </div>
            {isCommander && (
              <div className="flex gap-4">
                 <div className="text-right px-4 border-r theme-border">
                   <div className="text-[8px] font-black text-slate-400 uppercase">Admissions Code</div>
                   <div className="text-xl font-black text-indigo-600 tracking-[0.2em] flex items-center gap-2 justify-end">
                     {syndicate?.joinCode || syndicate?.join_code || '------'}
                     <button 
                       onClick={() => {
                         const code = syndicate?.joinCode || syndicate?.join_code || '';
                         if (code) {
                           navigator.clipboard.writeText(code);
                           alert("Admissions code copied to clipboard.");
                         }
                       }}
                       className="p-1 hover:theme-bg-primary transition-colors text-slate-400"
                     >
                       <Upload size={12} className="rotate-90" />
                     </button>
                   </div>
                 </div>
                 <div className="text-right px-4 border-r theme-border hidden sm:block">
                   <div className="text-[8px] font-black text-slate-400 uppercase">Class Average PI</div>
                   <div className="text-xl font-black text-indigo-600">
                     {members.length > 0 ? (members.reduce((acc, m) => acc + (m.profile?.precisionIndex || 0), 0) / members.length).toFixed(1) : 0}
                   </div>
                 </div>
                 <div className="text-right px-4 hidden sm:block">
                   <div className="text-[8px] font-black text-slate-400 uppercase">Total Lab Reports</div>
                   <div className="text-xl font-black text-emerald-500">{memberForecasts.length}</div>
                 </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Sidebar: Curriculum & Roster */}
            <div className="lg:col-span-4 space-y-6">
              {/* Join Code for Teacher (Prominent in Classroom tab) */}
              {isCommander && (
                <div className="theme-bg-secondary border-2 border-indigo-600 p-6 space-y-3 shadow-[8px_8px_0px_#4f46e5]">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-600 flex items-center gap-2">
                    <UserPlus size={14} /> Admissions Terminal
                  </h4>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 theme-bg-primary border-2 border-slate-900 dark:border-white p-3 text-center text-xl font-black tracking-[0.3em] text-indigo-600 uppercase">
                      {syndicate?.joinCode || syndicate?.join_code || '------'}
                    </div>
                    <button 
                      onClick={() => {
                        const code = syndicate?.joinCode || syndicate?.join_code || '';
                        if (code) {
                          navigator.clipboard.writeText(code);
                          alert("Authorization code copied to clipboard.");
                        }
                      }}
                      className="p-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-indigo-600 transition-all font-black"
                    >
                      <Upload size={18} className="rotate-90" />
                    </button>
                  </div>
                  <p className="text-[8px] font-bold theme-text-muted uppercase leading-relaxed">
                    Students must enter this code in their Syndicate Terminal to request enrollment.
                  </p>
                </div>
              )}

              {/* Learning Objectives */}
              <div className="theme-bg-secondary border-2 border-indigo-600/30 p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-10">
                  <BookOpen size={48} />
                </div>
                <h3 className="text-xs font-black uppercase tracking-widest mb-4 flex items-center gap-2">
                  <BookOpen size={16} className="text-indigo-600" /> Current Objectives
                </h3>
                <div className="text-[11px] font-medium leading-relaxed theme-text-primary italic opacity-90 border-l-2 border-indigo-600/30 pl-4">
                  {syndicate?.learning_objectives || "No specific learning objectives have been published for this semester yet."}
                </div>
                <div className="mt-6 space-y-2">
                  <div className="flex items-center justify-between text-[8px] font-black uppercase tracking-widest text-slate-400">
                    <span>Curriculum Mastery</span>
                    <span className="text-indigo-600">Level 4</span>
                  </div>
                  <div className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div className="w-[85%] h-full bg-indigo-600" />
                  </div>
                </div>
              </div>

              {/* Roster */}
              <div className="theme-bg-secondary border theme-border p-6">
                <h3 className="text-xs font-black uppercase tracking-widest mb-6 flex items-center justify-between">
                  <span>Student Roster</span>
                  <span className="text-[10px] font-bold text-slate-400">{members.length} Enrolled</span>
                </h3>
                <div className="space-y-3">
                  {members.sort((a,b) => (b.profile?.precisionIndex || 0) - (a.profile?.precisionIndex || 0)).map((m) => (
                    <div key={m.userId} className="flex items-center justify-between p-3 theme-bg-primary border theme-border hover:border-indigo-600/50 transition-all">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-6 bg-slate-200 dark:bg-slate-800 rounded-sm overflow-hidden text-[0px]">.
                           <div className="w-full bg-indigo-600" style={{ height: `${(m.profile?.precisionIndex || 0)}%` }} />
                        </div>
                        <span className="text-xs font-black uppercase tracking-tight">@{m.profile?.displayName}</span>
                        {m.role === 'commander' && (
                          <span className="text-[7px] font-black bg-amber-500 text-white px-1 py-0.5 rounded-sm">INST</span>
                        )}
                      </div>
                      <span className="text-xs font-black text-indigo-600">{m.profile?.precisionIndex || 0}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Main Content: Activity & Reports */}
            <div className="lg:col-span-8 space-y-6">
              <div className="theme-bg-secondary border theme-border p-6">
                <h3 className="text-xs font-black uppercase tracking-widest mb-6 flex items-center gap-2">
                  <GraduationCap size={16} className="text-indigo-600" /> {isCommander ? 'Gradebook Submissions' : 'My Lab Report Hub'}
                </h3>
                {!isCommander && (
                  <div className="text-[10px] font-black uppercase px-3 py-1 theme-bg-primary border theme-border">
                    {memberForecasts.filter(f => f.userId === user.uid).length} Reports Filed
                  </div>
                )}
                <div className="space-y-4">
                  {memberForecasts.filter(f => isCommander || f.userId === user.uid).length === 0 ? (
                    <div className="p-12 text-center opacity-30 border-2 border-dashed theme-border">
                      <p className="text-[10px] font-bold uppercase">No transmissions recorded yet.</p>
                    </div>
                  ) : (
                    memberForecasts
                      .filter(f => isCommander || f.userId === user.uid)
                      .map((f) => {
                        const student = members.find(m => m.userId === f.userId);
                        return (
                          <div key={f.id} className="p-5 theme-bg-primary border theme-border hover:border-indigo-600 group transition-all">
                            <div className="flex flex-col md:flex-row justify-between gap-6">
                              <div className="flex gap-4">
                                <div className="w-12 h-12 theme-bg-secondary border theme-border flex items-center justify-center relative overflow-hidden">
                                  {student?.profile?.avatarUrl ? <img src={student.profile.avatarUrl} className="w-full h-full object-cover" /> : <span className="text-xs font-black text-slate-500">{student?.profile?.displayName?.slice(0,2).toUpperCase() || '??'}</span>}
                                  {f.actualGrade?.weightedScore >= 90 && (
                                    <div className="absolute top-0 right-0 w-3 h-3 bg-emerald-500" title="A+ Performance" />
                                  )}
                                </div>
                                <div className="space-y-1">
                                  <div className="text-xs font-black uppercase">
                                    {isCommander ? `@${student?.profile?.displayName || 'Unknown Student'}` : f.location}
                                  </div>
                                  <div className="text-[9px] theme-text-muted uppercase tracking-tighter flex items-center gap-2">
                                    <span className="flex items-center gap-1"><BookOpen size={10} /> UNIT: THERMODYNAMICS</span>
                                    <span>•</span>
                                    <span>{new Date(f.createdAt?.toDate ? f.createdAt.toDate() : f.createdAt).toLocaleDateString()}</span>
                                  </div>
                                  <div className="mt-3 text-[10px] font-medium leading-relaxed italic opacity-80 border-l-2 border-slate-200 dark:border-slate-800 pl-3 line-clamp-2">
                                    "{f.logicNotes || 'Direct observation recorded.'}"
                                  </div>
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-6 md:border-l theme-border md:pl-6">
                                <div className="text-center min-w-[70px]">
                                  <div className="text-[8px] font-black text-slate-400 uppercase mb-1">Score</div>
                                  <div className={`text-xl font-black ${f.actualGrade?.weightedScore >= 80 ? 'text-emerald-500' : 'text-indigo-600'}`}>
                                    {f.actualGrade?.weightedScore !== undefined ? f.actualGrade.weightedScore : '--'}
                                  </div>
                                </div>
                                <button 
                                  onClick={() => setSelectedReportForecast(f)}
                                  disabled={f.status !== 'completed'}
                                  className="flex flex-col items-center gap-1 group/btn"
                                >
                                  <div className={`p-3 rounded-full theme-bg-secondary border theme-border group-hover/btn:border-indigo-600 group-hover/btn:theme-bg-primary transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.05)] ${f.status !== 'completed' ? 'opacity-30 cursor-not-allowed' : ''}`}>
                                    <FileText size={18} className="text-indigo-600" />
                                  </div>
                                  <span className="text-[8px] font-black uppercase tracking-tighter">
                                    {f.status === 'completed' ? 'Review Lab' : 'Syncing'}
                                  </span>
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : activeTab === 'chat' ? (
        <div className="flex flex-col gap-6">
          <button onClick={() => setActiveTab('overview')} className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-indigo-600 transition-colors">
            <ArrowRight className="rotate-180" size={14} /> Back to Hub
          </button>
          <SyndicateChat syndicateId={syndicate?.id} user={user} profile={profile} />
        </div>
      ) : activeTab === 'ops' ? (
        <div className="space-y-8">
           <button onClick={() => setActiveTab('overview')} className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-indigo-600 transition-colors">
            <ArrowRight className="rotate-180" size={14} /> Back to Hub
          </button>

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-2xl font-black uppercase tracking-tighter">Strategic Operations</h2>
              <p className="text-[10px] theme-text-muted uppercase tracking-widest font-bold">Synchronized objectives for maximum sector impact.</p>
            </div>
            {isCommander && (
              <button 
                onClick={() => setShowOpForm(!showOpForm)}
                className="px-6 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[10px] font-black uppercase tracking-widest shadow-[4px_4px_0px_#4f46e5] hover:-translate-y-1 hover:shadow-[6px_6px_0px_#4f46e5] transition-all flex items-center gap-2"
              >
                {showOpForm ? 'Cancel Operation' : 'Initialize New Operation'}
                <Plus size={14} />
              </button>
            )}
          </div>

          <AnimatePresence>
            {showOpForm && isCommander && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <form onSubmit={handleCreateOperation} className="p-8 theme-bg-secondary border-2 border-slate-900 space-y-6">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Operation Code Name</label>
                        <input 
                          required
                          value={opTitle}
                          onChange={(e) => setOpTitle(e.target.value)}
                          placeholder="e.g. PROJECT: BOREALIS"
                          className="w-full theme-bg-primary border-b-2 border-slate-900 py-3 text-xs font-black uppercase tracking-widest focus:outline-none focus:border-indigo-600"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Tactical Objective</label>
                        <select 
                          value={opCategory}
                          onChange={(e) => setOpCategory(e.target.value)}
                          className="w-full theme-bg-primary border-b-2 border-slate-900 py-3 text-xs font-black uppercase tracking-widest focus:outline-none"
                        >
                          <option>Verification</option>
                          <option>Severe Weather</option>
                          <option>Precision Training</option>
                          <option>Emergency Drill</option>
                        </select>
                      </div>
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Operation Briefing (Instructions)</label>
                      <textarea 
                        value={opDesc}
                        onChange={(e) => setOpDesc(e.target.value)}
                        placeholder="Detail the mission parameters for your analysts..."
                        rows={3}
                        className="w-full theme-bg-primary border-2 border-slate-900 p-4 text-xs font-bold focus:outline-none focus:border-indigo-600"
                      />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">De-escalation Date (End Date)</label>
                      <input 
                        required
                        type="date"
                        value={opEndDate}
                        onChange={(e) => setOpEndDate(e.target.value)}
                        className="w-full theme-bg-primary border-b-2 border-slate-900 py-3 text-xs font-bold uppercase"
                      />
                   </div>
                   <button 
                     type="submit"
                     disabled={isCreatingOp}
                     className="w-full py-4 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-[0.2em] shadow-[4px_4px_0px_#1e1b4b] hover:bg-slate-900 transition-all flex items-center justify-center gap-2"
                   >
                     {isCreatingOp ? <Loader2 className="animate-spin" /> : <Zap size={14} />}
                     DEPLOY OPERATION
                   </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {activeOperations.map((op) => {
              const opForecasts = memberForecasts.filter(f => f.missionId === op.id);
              const participants = new Set(opForecasts.map(f => f.userId));
              const participationRate = members.length > 0 ? (participants.size / members.length) * 100 : 0;
              const nonParticipants = members.filter(m => !participants.has(m.userId));

              return (
                <div key={op.id} className="p-8 theme-bg-secondary border-2 theme-border relative overflow-hidden group flex flex-col">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-600/5 rotate-45 translate-x-16 -translate-y-16 group-hover:bg-indigo-600/10 transition-colors" />
                  
                  <div className="flex items-center justify-between mb-6">
                    <div className="px-2 py-1 theme-bg-primary border theme-border text-[8px] font-bold text-indigo-600 uppercase tracking-widest">
                      {op.category}
                    </div>
                    <div className="flex items-center gap-2">
                      {op.status === 'active' ? (
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-slate-400" />
                      )}
                      <span className="text-[8px] font-black theme-text-muted uppercase tracking-[0.2em]">Live</span>
                    </div>
                  </div>

                  <h3 className="text-xl font-black uppercase tracking-tighter mb-2">{op.title}</h3>
                  <p className="text-[11px] theme-text-secondary leading-relaxed mb-6 line-clamp-2">
                    {op.description || 'Strategic objective parameters undefined.'}
                  </p>

                  <div className="mt-auto space-y-6">
                    <div>
                      <div className="flex justify-between text-[10px] font-black mb-2">
                        <span className="theme-text-muted uppercase tracking-widest">Participation Load</span>
                        <span className="text-indigo-600">{participationRate.toFixed(0)}%</span>
                      </div>
                      <div className="h-1.5 w-full theme-bg-primary rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-indigo-600 transition-all duration-1000" 
                          style={{ width: `${participationRate}%` }} 
                        />
                      </div>
                      <div className="flex justify-between mt-2 text-[9px] font-bold theme-text-muted uppercase tracking-widest">
                         <span>{participants.size} Reports Captured</span>
                         <span>Ends: {op.endDate}</span>
                      </div>
                    </div>

                    {isCommander && nonParticipants.length > 0 && (
                      <div className="pt-4 border-t theme-border">
                        <h4 className="text-[8px] font-black uppercase tracking-widest text-red-500 mb-3 flex items-center gap-1">
                          <ShieldAlert size={10} /> Pending Intelligence (Missing)
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {nonParticipants.map(m => (
                            <div key={m.userId} className="px-2 py-1 theme-bg-primary border theme-border text-[8px] font-bold theme-text-secondary uppercase">
                              @{m.profile?.displayName}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {!isCommander && !participants.has(user.uid) && (
                      <div className="p-4 bg-amber-500/10 border border-amber-500/20 text-amber-600 flex items-center justify-between">
                         <span className="text-[9px] font-black uppercase tracking-widest">Awaiting your report</span>
                         <Zap size={12} className="animate-pulse" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {activeOperations.length === 0 && (
              <div className="col-span-full p-20 theme-bg-secondary border-2 border-dashed theme-border flex flex-col items-center text-center">
                <Target size={48} className="theme-text-muted mb-6" />
                <h3 className="text-lg font-black uppercase tracking-widest">No Active Deployments</h3>
                <p className="text-xs theme-text-secondary uppercase tracking-widest mt-2">Commander authorization required to initialize unit-wide operations.</p>
              </div>
            )}
          </div>
        </div>
      ) : activeTab === 'map' ? (
        <div className="flex flex-col gap-6">
          <button onClick={() => setActiveTab('overview')} className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-indigo-600 transition-colors">
            <ArrowRight className="rotate-180" size={14} /> Back to Hub
          </button>
          <div className="border theme-border min-h-[600px] flex flex-col">
            <StrategicDeploymentMap user={user} profile={profile} />
          </div>
        </div>
      ) : activeTab === 'create' ? (
        <div className="max-w-2xl mx-auto space-y-8">
          <div className="flex items-center gap-4">
            <button onClick={() => setActiveTab('overview')} className="p-2 theme-bg-secondary border theme-border hover:theme-bg-primary transition-colors">
              <ChevronRight className="rotate-180" size={20} />
            </button>
            <div>
              <h2 className="text-2xl font-black uppercase tracking-tighter">Commission Syndicate</h2>
              <p className="text-[10px] theme-text-muted uppercase tracking-widest font-bold">Draft your squad charter to begin recruitment.</p>
            </div>
          </div>
          
          <div className="p-8 border-[3px] border-slate-900 dark:border-white theme-bg-secondary space-y-10 shadow-[8px_8px_0px_rgba(0,0,0,0.1)]">
            <form onSubmit={handleCreate} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Charter Name</label>
                  <input 
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. STRATOSPHERE SQUADRON"
                    className="w-full theme-bg-primary border-b-2 border-slate-900 dark:border-white py-4 text-xs font-black uppercase tracking-wider focus:outline-none focus:border-indigo-600 transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Tag (4 CHR)</label>
                  <input 
                    required
                    maxLength={4}
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value.toUpperCase())}
                    placeholder="TAG"
                    className="w-full theme-bg-primary border-b-2 border-slate-900 dark:border-white py-4 text-xs font-black uppercase tracking-[0.5em] focus:outline-none focus:border-indigo-600 text-center transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Charter Memo / Tactical Doctrine</label>
                <textarea 
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Define your tactical objectives and recruitment criteria..."
                  rows={3}
                  className="w-full theme-bg-primary border-2 border-slate-900 dark:border-white p-4 text-xs font-bold focus:outline-none focus:border-indigo-600 transition-colors"
                />
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button 
                    type="button"
                    onClick={() => !isClassroom && setIsInviteOnly(!isInviteOnly)}
                    className={`flex items-center gap-3 p-4 border-2 transition-all ${isInviteOnly || isClassroom ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20' : 'border-slate-200 dark:border-slate-800 opacity-60'}`}
                  >
                    <div className={`w-4 h-4 border-2 flex items-center justify-center ${isInviteOnly || isClassroom ? 'border-indigo-600 bg-indigo-600' : 'border-slate-400'}`}>
                      {(isInviteOnly || isClassroom) && <Check size={12} className="text-white" />}
                    </div>
                    <div className="text-left">
                      <div className="text-[10px] font-black uppercase tracking-tighter">Invite Only Mode</div>
                      <div className="text-[8px] font-bold opacity-60 uppercase">Manual Authorization Required</div>
                    </div>
                  </button>

                  <button 
                    type="button"
                    onClick={() => setIsClassroom(!isClassroom)}
                    className={`flex items-center gap-3 p-4 border-2 transition-all ${isClassroom ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-900/20' : 'border-slate-200 dark:border-slate-800 opacity-60'}`}
                  >
                    <div className={`w-4 h-4 border-2 flex items-center justify-center ${isClassroom ? 'border-emerald-600 bg-emerald-600' : 'border-slate-400'}`}>
                      {isClassroom && <Check size={12} className="text-white" />}
                    </div>
                    <div className="text-left">
                      <div className="text-[10px] font-black uppercase tracking-tighter text-emerald-600">Classroom Mode</div>
                      <div className="text-[8px] font-bold opacity-60 uppercase">Educational Lab Features</div>
                    </div>
                  </button>
                </div>

                <AnimatePresence>
                  {isClassroom && (
                    <motion.div 
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="p-6 border-2 border-emerald-600/30 theme-bg-primary space-y-6"
                    >
                      <div className="flex items-center gap-2 pb-2 border-b theme-border">
                        <GraduationCap className="text-emerald-500" size={16} />
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-emerald-600">Educational Metadata</h4>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">School / Institution</label>
                          <input 
                            value={orgName}
                            onChange={(e) => setOrgName(e.target.value)}
                            placeholder="e.g. WESTSIDE HIGH"
                            className="w-full theme-bg-secondary border-b theme-border py-2 text-xs font-bold uppercase focus:outline-none focus:border-emerald-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Learning Objectives (NGSS)</label>
                          <input 
                            value={learningObjectives}
                            onChange={(e) => setLearningObjectives(e.target.value)}
                            placeholder="e.g. MS-ESS2-5 ATMOSPHERICS"
                            className="w-full theme-bg-secondary border-b theme-border py-2 text-xs font-bold uppercase focus:outline-none focus:border-emerald-500"
                          />
                        </div>
                      </div>
                      <div className="text-[9px] font-medium leading-relaxed italic opacity-60">
                        * In Classroom Mode, your syndicate will be private and focused on academic reporting. All member activity will be recorded for Lab Reports.
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button 
                type="submit"
                disabled={isCreating}
                className="w-full py-6 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-black uppercase tracking-[0.2em] hover:bg-indigo-600 dark:hover:bg-indigo-600 dark:hover:text-white transition-all shadow-[8px_8px_0px_rgba(0,0,0,0.1)] flex items-center justify-center gap-2 group disabled:opacity-50"
              >
                {isCreating ? (
                  <Loader2 size={24} className="animate-spin" />
                ) : (
                  <>
                    AUTHORIZE CHARTER
                    <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
                  </>
                )}
              </button>

              <div className="pt-8 border-t theme-border flex flex-col items-center gap-4">
                <p className="text-[8px] font-black uppercase tracking-widest text-slate-400">System Maintenance</p>
                <button 
                  type="button"
                  onClick={handleMigrateJoinCodes}
                  disabled={isMigrating}
                  className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 hover:text-indigo-700 uppercase tracking-widest transition-colors"
                >
                  {isMigrating ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
                  Sync Legacy Classroom Codes
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : syndicate ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Tactical Commander Broadcasts */}
            {isCommander && pendingRequests.length > 0 && (
              <div className="p-6 theme-bg-secondary border-2 border-dashed border-amber-300 dark:border-amber-900/30">
                <div className="flex items-center gap-2 mb-4 border-b theme-border pb-2">
                  <UserPlus size={14} className="text-amber-500" />
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-amber-600">Pending Enrollment Requests</h3>
                </div>
                <div className="space-y-3">
                  {pendingRequests.map((req) => (
                    <div key={req.id} className="flex items-center justify-between p-4 theme-bg-primary border theme-border">
                      <div className="flex items-center gap-3">
                        {req.profile?.avatarUrl ? (
                          <img src={req.profile.avatarUrl} className="w-8 h-8 rounded-full border theme-border" />
                        ) : (
                          <div className="w-8 h-8 theme-bg-secondary flex items-center justify-center text-[10px] font-black uppercase tracking-tighter">
                            {req.profile?.displayName?.slice(0, 2)}
                          </div>
                        )}
                        <div>
                          <div className="text-[10px] font-black uppercase tracking-tight">@{req.profile?.displayName || 'RECRUIT'}</div>
                          <div className="text-[8px] font-bold text-slate-400">PI: {req.profile?.precisionIndex || 0}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => handleActionRequest(req.id, 'approved')}
                          className="px-3 py-1.5 bg-emerald-600 text-white text-[9px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all"
                        >
                          Approve
                        </button>
                        <button 
                          onClick={() => handleActionRequest(req.id, 'denied')}
                          className="px-3 py-1.5 bg-red-600 text-white text-[9px] font-black uppercase tracking-widest hover:bg-red-700 transition-all"
                        >
                          Deny
                        </button>
                      </div>
                    </div>
                   ))}
                </div>
              </div>
            )}

            {isCommander && (
               <div className="p-6 theme-bg-secondary border-2 border-dashed border-red-200 dark:border-red-900/30">
                <form onSubmit={handlePostBroadcast} className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Radio size={14} className="text-red-500" />
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-red-600">Commander Direct Dispatch</h3>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 theme-bg-primary border theme-border mb-4">
                    <div className="flex items-center gap-2">
                      <Shield size={12} className={syndicate.isInviteOnly ? "text-amber-500" : "text-slate-400"} />
                      <span className="text-[9px] font-black uppercase tracking-widest">Enlistment Restricted</span>
                    </div>
                    <button 
                      type="button"
                      onClick={() => updateDoc(doc(db, 'syndicates', syndicate.id), { isInviteOnly: !syndicate.isInviteOnly })}
                      className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-widest transition-all ${
                          syndicate.isInviteOnly 
                          ? 'bg-amber-600 text-white' 
                          : 'theme-bg-secondary theme-text-muted hover:theme-text-primary'
                      }`}
                    >
                      {syndicate.isInviteOnly ? 'Invite Only ACTIVE' : 'Public Enlistment'}
                    </button>
                  </div>
                  <input 
                    value={broadcastTitle}
                    onChange={(e) => setBroadcastTitle(e.target.value)}
                    placeholder="Dispatch Subject (e.g. ALL HANDS: SECTOR ALPHA)"
                    className="w-full theme-bg-primary border theme-border p-3 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:border-red-500"
                  />
                  <textarea 
                    value={broadcastMsg}
                    onChange={(e) => setBroadcastMsg(e.target.value)}
                    placeholder="Enter strategic orders..."
                    rows={2}
                    className="w-full theme-bg-primary border theme-border p-3 text-xs focus:outline-none focus:border-red-500"
                  />
                  <button 
                    type="submit"
                    disabled={isBroadcasting}
                    className="px-6 py-2 bg-red-600 text-white text-[9px] font-black uppercase tracking-widest hover:bg-slate-900 transition-all flex items-center gap-2"
                  >
                    {isBroadcasting ? <Loader2 size={12} className="animate-spin" /> : <Radio size={12} />}
                    Transmit Priority Signal
                  </button>
                </form>

                <div className="mt-8 pt-8 border-t border-red-500/10">
                  <div className="flex items-center gap-2 mb-4">
                    <AlertTriangle size={14} className="text-red-600" />
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-red-600">Danger Zone</h3>
                  </div>
                  <p className="text-[9px] font-medium theme-text-muted mb-4 leading-relaxed">
                    Decommissioning the syndicate will permanently dissolve the charter and remove all classified data.
                  </p>
                  
                  {!showDeleteConfirm ? (
                    <button 
                      onClick={() => setShowDeleteConfirm(true)}
                      className="w-full py-4 bg-red-600/10 border-2 border-red-600/30 text-red-600 text-[10px] font-black uppercase tracking-[0.2em] hover:bg-red-600 hover:text-white transition-all flex items-center justify-center gap-2"
                    >
                      Initialize Decommissioning
                      <Trash2 size={14} />
                    </button>
                  ) : (
                    <div className="space-y-4 p-4 border-2 border-red-600 bg-red-600/5 animate-pulse">
                      <div className="text-[10px] font-black text-red-600 uppercase text-center mb-2">
                        Type "{syndicate.tag}" to confirm destruction
                      </div>
                      <input 
                        type="text"
                        value={deleteTagInput}
                        onChange={(e) => setDeleteTagInput(e.target.value.toUpperCase())}
                        placeholder="ENTER TAG"
                        className="w-full theme-bg-primary border-b-2 border-red-600 py-3 text-center text-sm font-black tracking-widest focus:outline-none"
                      />
                      <div className="flex gap-2">
                         <button 
                          onClick={() => { setShowDeleteConfirm(false); setDeleteTagInput(''); }}
                          className="flex-1 py-3 bg-slate-200 dark:bg-slate-800 text-[9px] font-black uppercase tracking-widest"
                        >
                          Abort
                        </button>
                        <button 
                          onClick={handleDeleteSyndicate}
                          disabled={isDeleting || deleteTagInput !== syndicate.tag}
                          className="flex-2 py-3 bg-red-600 text-white text-[9px] font-black uppercase tracking-widest disabled:opacity-30"
                        >
                          {isDeleting ? "Sequencing..." : "Confirm Deletion"}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {broadcasts.length > 0 && (
               <div className="space-y-4">
                <div className="flex items-center justify-between border-b theme-border pb-2">
                  <h3 className="text-sm font-black uppercase tracking-[0.2em] theme-text-primary flex items-center gap-2">
                    <Radio size={16} className="text-red-500 animate-pulse" /> COMMANDER'S ORDERS
                  </h3>
                </div>
                <div className="space-y-2">
                  {broadcasts.map((b, i) => (
                    <div key={i} className="p-6 bg-red-500/5 border border-red-500/20 rounded-sm relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-1 h-full bg-red-500" />
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black text-red-600 uppercase tracking-widest">High Priority Dispatch</span>
                        <span className="text-[8px] font-mono theme-text-muted italic">{new Date(b.createdAt?.toDate ? b.createdAt.toDate() : b.createdAt).toLocaleTimeString()}</span>
                      </div>
                      <h4 className="text-sm font-bold theme-text-primary uppercase mb-2">{b.title}</h4>
                      <p className="text-xs theme-text-secondary leading-relaxed font-medium">
                        {b.message}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Squad Members */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b theme-border pb-2">
                <h3 className="text-sm font-black uppercase tracking-[0.2em] theme-text-primary flex items-center gap-2">
                  <Users size={16} /> Squad Roster
                </h3>
                <span className="text-[10px] font-bold text-slate-400 uppercase">{members.length} Active Analysts</span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {members.map((m, i) => {
                  const isSelf = m.userId === user.uid;
                  const canManage = (userRole === 'commander' && !isSelf) || 
                                   (userRole === 'officer' && m.role === 'analyst' && !isSelf);

                  return (
                    <div key={i} className="p-4 theme-bg-secondary border theme-border flex items-center gap-4 group hover:border-indigo-600 transition-all">
                      {m.profile?.avatarUrl ? (
                        <img src={m.profile.avatarUrl} className="w-10 h-10 theme-bg-primary p-0.5 border theme-border object-cover" />
                      ) : (
                        <div className="w-10 h-10 theme-bg-primary flex items-center justify-center text-xs font-black text-slate-400 border theme-border">
                          {m.profile?.displayName?.slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-black uppercase tracking-wider">@{m.profile?.displayName}</h4>
                          {m.role === 'commander' && <Shield size={10} className="text-amber-500" />}
                          {m.role === 'officer' && <Shield size={10} className="text-indigo-400" />}
                        </div>
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{m.role}</p>
                      </div>
                      
                      {canManage && (
                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          {userRole === 'commander' && (
                            <button 
                              onClick={() => handleUpdateRole(m.userId, m.role === 'officer' ? 'analyst' : 'officer')}
                              title={m.role === 'officer' ? "Demote to Analyst" : "Promote to Officer"}
                              className="p-1.5 theme-bg-primary border theme-border text-slate-400 hover:text-indigo-600 transition-colors"
                            >
                              {m.role === 'officer' ? <UserMinus size={12} /> : <UserPlus size={12} />}
                            </button>
                          )}
                          <button 
                            onClick={() => handleKickMember(m.userId)}
                            title="Remove from Syndicate"
                            className="p-1.5 theme-bg-primary border theme-border text-slate-400 hover:text-red-500 transition-colors"
                          >
                            <ShieldAlert size={12} />
                          </button>
                        </div>
                      )}

                      <div className="text-right">
                        <div className="text-[10px] font-black text-indigo-600">{m.profile?.precisionIndex || 0}</div>
                        <div className="text-[8px] font-bold text-slate-400 uppercase">PI Rank</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Tactical Briefing Feed */}
            <div className="space-y-4">
               <h3 className="text-sm font-black uppercase tracking-[0.2em] border-b theme-border pb-2 flex items-center gap-2">
                <MessageSquare size={16} /> Live Intelligence Briefings
              </h3>
              {briefings.length > 0 ? (
                <div className="space-y-4">
                  {briefings.map((b, i) => (
                    <div key={i} className="p-6 theme-bg-secondary border theme-border">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Shield size={12} className="text-indigo-600" />
                          <span className="text-[10px] font-black uppercase tracking-widest">{b.location.split(',')[0]} Briefing</span>
                        </div>
                        <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter">
                          {new Date(b.createdAt?.toDate ? b.createdAt.toDate() : b.createdAt).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-xs italic theme-text-secondary leading-relaxed border-l-2 border-indigo-500 pl-4">
                        "{b.logicNotes}"
                      </p>
                      <div className="mt-4 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest">Logic Rating:</span>
                          <div className="flex gap-0.5">
                            {[1,2,3,4,5].map(star => (
                              <div key={star} className={`w-2 h-2 rounded-full ${star <= (b.upvotes || 0) ? 'bg-indigo-600' : 'theme-bg-primary'}`} />
                            ))}
                          </div>
                        </div>
                        <span className="text-[9px] font-black theme-text-primary uppercase tracking-widest">
                          Analyst: {members.find(m => m.userId === b.userId)?.profile?.displayName ? `@${members.find(m => m.userId === b.userId)?.profile?.displayName}` : 'Anonymous'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-12 theme-bg-primary border theme-border text-center opacity-40">
                  <p className="text-[10px] font-bold uppercase tracking-widest">Awaiting sector activity from squad members...</p>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-8">
            {/* Recruitment Terminal (Commander Only) */}
            {isCommander && (
              <div className="p-6 border-2 border-indigo-600 theme-bg-secondary space-y-4 shadow-[4px_4px_0px_rgba(79,70,229,0.2)]">
                <div className="flex items-center justify-between">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600 flex items-center gap-2">
                    <UserPlus size={14} /> Recruitment Terminal
                  </h3>
                  <div className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
                </div>
                
                <div className="space-y-2">
                  <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Active Join Code</label>
                  {(syndicate.joinCode || syndicate.join_code) ? (
                    <div className="flex items-center gap-2">
                      <div className="flex-1 theme-bg-primary border-2 border-slate-900 dark:border-white p-3 text-center text-xl font-black tracking-[0.3em] text-indigo-600 uppercase">
                        {syndicate.joinCode || syndicate.join_code}
                      </div>
                      <button 
                        onClick={() => {
                          const code = syndicate.joinCode || syndicate.join_code;
                          navigator.clipboard.writeText(code);
                          alert("Authorization code copied to clipboard.");
                        }}
                        className="p-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-indigo-600 dark:hover:bg-indigo-600 dark:hover:text-white transition-all shadow-[2px_2px_0px_#4f46e5]"
                        title="Copy Code"
                      >
                        <Upload size={18} className="rotate-90" />
                      </button>
                    </div>
                  ) : (
                    <button 
                      onClick={async () => {
                        const newCode = Math.random().toString(36).substring(2, 8).toUpperCase();
                        await updateDoc(doc(db, 'syndicates', syndicate.id), { join_code: newCode });
                      }}
                      className="w-full theme-bg-primary border-2 border-dashed border-indigo-600 p-4 text-xs font-black text-indigo-600 uppercase tracking-widest hover:bg-indigo-50 transition-colors"
                    >
                      Initialize Deployment Code
                    </button>
                  )}
                  <p className="text-[9px] font-medium theme-text-muted leading-relaxed uppercase tracking-tight">
                    Distribute this code to authorized recruits for instant sector deployment.
                  </p>
                </div>
              </div>
            )}

            {/* Sector Control stats */}
            <div className="p-6 border theme-border theme-bg-secondary space-y-6">
              <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600 flex items-center gap-2">
                <Trophy size={14} /> Sector Influence
              </h3>
              
              <div className="space-y-4">
                {sectorControl.length > 0 ? sectorControl.map((sc, i) => (
                  <div key={i} className="space-y-1">
                    <div className="flex justify-between text-[9px] font-bold uppercase">
                      <span>{sc.id.split('-').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}</span>
                      <span className="text-indigo-600">{sc.influence}% Control</span>
                    </div>
                    <div className="h-1 w-full bg-slate-200 dark:bg-slate-800">
                      <div className="h-full bg-indigo-600" style={{ width: `${sc.influence}%` }}></div>
                    </div>
                  </div>
                )) : (
                  <p className="text-[10px] theme-text-muted uppercase italic">No sector influence established yet.</p>
                )}
              </div>

              <div className="pt-6 border-t theme-border">
                <button 
                  onClick={() => setActiveTab('map')}
                  className="w-full py-3 border border-indigo-600/30 text-[9px] font-black uppercase tracking-[0.2em] text-indigo-600 hover:bg-indigo-600 hover:text-white transition-all"
                >
                  Strategic Deployment Map
                </button>
              </div>
            </div>

            {/* Global Syndicate Standings */}
            <div className="p-6 border theme-border theme-bg-secondary space-y-6">
               <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-amber-600 flex items-center gap-2">
                <Map size={14} /> Syndicate Rankings
              </h3>
              
              <div className="space-y-3">
                {globalSyndicates.map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-3 theme-bg-primary border theme-border">
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-black text-slate-400">#{i+1}</span>
                      <div className="w-6 h-6 flex items-center justify-center border theme-border overflow-hidden">
                        {s.logo_url ? <img src={s.logo_url} className="w-full h-full object-cover" /> : <span className="text-[8px] font-black">{s.tag}</span>}
                      </div>
                      <div>
                        <div className="text-[10px] font-black uppercase">{s.name}</div>
                        <div className="text-[8px] font-bold text-emerald-500">{s.totalPi || 0} PI</div>
                      </div>
                    </div>
                    <ChevronRight size={12} className="text-slate-300" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Join Search & Status */}
          <div className="lg:col-span-2 space-y-8">
            <div className="p-10 border-2 border-dashed theme-border theme-bg-secondary flex flex-col items-center text-center">
              <Shield size={48} className="text-indigo-600 mb-6" />
              <h3 className="text-2xl font-black uppercase tracking-tighter mb-4">Unassigned Analyst</h3>
              <p className="text-xs theme-text-muted uppercase tracking-widest leading-loose mb-8 max-w-md">
                You are currently operating as a lone agent. Join an existing syndicate to share intelligence and multiply your impact.
              </p>
              
              {myPendingRequest ? (
                <div className="w-full p-8 theme-bg-primary border border-amber-500/30 flex flex-col items-center gap-4">
                  <Radio size={32} className="text-amber-500 animate-pulse" />
                  <div className="text-sm font-black uppercase tracking-widest text-amber-600">Enlistment Request Pending</div>
                  <p className="text-[10px] theme-text-secondary leading-relaxed">
                    Your tactical profile has been submitted to the syndicate command. Stand by for approval code.
                  </p>
                  <button 
                    onClick={() => {
                        const q = query(collection(db, 'syndicate_requests'), where('userId', '==', user.uid), where('status', '==', 'pending'));
                        getDocs(q).then(s => s.docs.forEach(d => updateDoc(doc(db, 'syndicate_requests', d.id), { status: 'cancelled' })));
                        setMyPendingRequest(null);
                    }}
                    className="text-[10px] font-bold text-red-500 uppercase tracking-widest underline underline-offset-4"
                  >
                    Abort Request
                  </button>
                </div>
              ) : (
                <div className="w-full space-y-8">
                  <div className="flex flex-col md:flex-row items-center gap-4">
                    <div className="relative flex-1 w-full">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input 
                        type="text"
                        placeholder="Search by Squad Tag..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full theme-bg-primary border theme-border pl-12 pr-4 py-4 text-xs font-black uppercase tracking-widest focus:outline-none focus:border-indigo-600 transition-all placeholder:text-slate-500"
                      />
                    </div>
                    <button 
                      onClick={handleSearch}
                      className="w-full md:w-auto px-10 py-4 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-slate-900 transition-all flex items-center justify-center gap-2 group"
                    >
                      Locate Syndicate <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>

                  {/* Join by Academic Code */}
                  <div className="p-8 border-2 border-emerald-500/20 bg-emerald-500/5 theme-bg-primary">
                    <div className="flex items-center gap-2 mb-4">
                      <GraduationCap className="text-emerald-600" size={16} />
                      <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-600">Join via Academic Code</h4>
                    </div>
                    <form onSubmit={handleJoinByCode} className="flex flex-col md:flex-row gap-4">
                      <input 
                        type="text"
                        placeholder="ENTER 6-CHAR CODE"
                        maxLength={6}
                        value={joinCodeInput}
                        onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                        className="flex-1 theme-bg-primary border-b-2 border-emerald-600 py-3 px-2 text-sm font-black tracking-[0.5em] text-center focus:outline-none"
                      />
                      <button 
                        type="submit"
                        disabled={isJoiningCode || !joinCodeInput}
                        className="px-8 py-3 bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {isJoiningCode ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                        Confirm Enrollment
                      </button>
                    </form>
                    <p className="text-[8px] font-bold text-slate-400 mt-4 uppercase text-center italic">
                      Note: Classroom codes are provided directly by your instructor.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-4 text-left border-b theme-border pb-2">
                       <h4 className="text-[10px] font-black uppercase tracking-[0.2em] theme-text-muted">Syndicate Directory</h4>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       {(searchResults.length > 0 ? searchResults : globalSyndicates).map((res: any) => (
                        <div key={res.id} className="p-6 theme-bg-primary border theme-border flex flex-col gap-4 group hover:border-indigo-600 transition-all">
                          <div className="flex items-center justify-between">
                            <div className="w-10 h-10 flex items-center justify-center bg-indigo-600 text-white font-black text-xs">
                              {res.tag}
                            </div>
                            <div className="text-right">
                              <span className="text-[9px] font-bold text-slate-400 uppercase">{res.memberCount || 1} Analysts</span>
                              <div className="text-[10px] font-black text-emerald-500">{res.totalPi || 0} PI</div>
                            </div>
                          </div>
                          <div>
                            <h4 className="text-sm font-black uppercase tracking-tight">{res.name}</h4>
                            <p className="text-[9px] theme-text-muted mt-1 uppercase tracking-tighter line-clamp-1">{res.description || 'No charter memo found.'}</p>
                          </div>
                          <button 
                            onClick={() => handleJoin(res.id, res.isInviteOnly)}
                            className={`w-full py-2 border font-black text-[9px] uppercase tracking-widest transition-all ${
                                res.isInviteOnly 
                                ? 'border-amber-500 text-amber-600 hover:bg-amber-600 hover:text-white' 
                                : 'border-indigo-600 text-indigo-600 hover:bg-indigo-600 hover:text-white'
                            }`}
                          >
                            {res.isInviteOnly ? 'Request Enlistment' : 'Join Squad'}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-8">
            <div className="flex items-center justify-between border-b theme-border pb-2">
                <h3 className="text-sm font-black uppercase tracking-[0.2em]">Active Recruits</h3>
                <Radio size={14} className="text-indigo-600 animate-pulse" />
            </div>
            <div className="space-y-4">
              {[1,2,3,4,5].map(i => (
                <div key={i} className="flex gap-4 p-4 theme-bg-secondary border theme-border opacity-40 grayscale blur-[1px]">
                  <div className="w-10 h-10 theme-bg-primary rounded-full" />
                  <div className="space-y-1 flex-1">
                    <div className="h-3 w-24 theme-bg-primary rounded" />
                    <div className="h-2 w-32 theme-bg-primary rounded" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
