import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Zap, Star, Shield, Cpu, ChevronRight, Globe, Lock } from 'lucide-react';
import { db, doc, updateDoc } from '../lib/db';

interface SubscriptionViewProps {
  user: any;
  profile: any;
}

export default function SubscriptionView({ user, profile }: SubscriptionViewProps) {
  const [loading, setLoading] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean | string>(false);
  const [error, setError] = useState<string | null>(null);

  const handleUpgrade = async (tier: 'pro') => {
    if (!user) return;
    setLoading(tier);
    setError(null);
    try {
      // Simulate payment processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      await updateDoc(doc(db, 'users', user.uid), {
        membership: tier,
        upgradedAt: new Date().toISOString()
      });
      setSuccess('upgrade');
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Intelligence sync failed. Please check your uplink.");
    } finally {
      setLoading(null);
    }
  };

  const handleDowngrade = async () => {
    if (!user) return;
    setLoading('basic');
    setError(null);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      await updateDoc(doc(db, 'users', user.uid), {
        membership: 'basic',
        upgradedAt: null
      });
      setSuccess('downgrade');
    } catch (err: any) {
      console.error(err);
      setError("Downgrade failed. Tactical retreat rejected by server.");
    } finally {
      setLoading(null);
    }
  };

  const isPro = profile?.membership === 'pro';

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-8 animate-in fade-in zoom-in duration-500">
        <div className={`w-24 h-24 ${success === 'upgrade' ? 'theme-bg-success theme-text-success' : 'theme-bg-secondary theme-text-muted'} rounded-full flex items-center justify-center shadow-lg`}>
          {success === 'upgrade' ? <Check size={48} strokeWidth={3} /> : <Shield size={48} strokeWidth={3} />}
        </div>
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-black italic tracking-tighter theme-text-primary uppercase">
            {success === 'upgrade' ? 'Strategic Uplink Secured' : 'Tier Downgrade Complete'}
          </h2>
          <p className="theme-text-secondary font-mono text-sm max-w-md mx-auto leading-relaxed">
            {success === 'upgrade' 
              ? "Analyst credentials upgraded to Pro Tier. All advanced telemetry, AI synthesis, and historical archives are now active."
              : "Intelligence credentials returned to Standard Tier. Strategic archives and AI deep dives have been restricted."
            }
          </p>
        </div>
        <button 
          onClick={() => {
            setSuccess(false);
            window.location.reload();
          }}
          className="bg-slate-900 dark:bg-indigo-600 text-white px-10 py-4 text-xs font-bold uppercase tracking-widest hover:opacity-80 transition-all shadow-[6px_6px_0px_var(--shadow-color)]"
        >
          Return to Hub
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-20">
      <div className="border-b theme-border pb-8 flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black italic tracking-tighter theme-text-primary uppercase">Intelligence Tiers</h1>
          <p className="theme-text-muted font-mono text-xs mt-2 uppercase tracking-widest">Protocol: MG-SUBS-V2 // Status: {isPro ? 'STRATEGIC_ACTIVE' : 'STANDARD_OPS'}</p>
        </div>
        {error && (
          <div className="theme-bg-error border theme-border p-3 flex items-center gap-3 text-[10px] font-bold theme-text-error uppercase tracking-widest mb-4">
            <Lock size={14} /> {error.includes('column') ? 'Database Schema Sync Required' : 'Sync Error'}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Basic Tier */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative theme-bg-secondary border-2 theme-border p-8 flex flex-col h-full"
        >
          {!isPro && (
             <div className="absolute top-4 right-4 bg-slate-900 dark:bg-slate-700 text-white text-[8px] font-bold px-2 py-1 uppercase tracking-widest">
               Active Protocol
             </div>
          )}
          
          <div className="mb-6">
            <h3 className="text-xl font-bold uppercase tracking-tight theme-text-primary">Basic Analyst</h3>
            <p className="text-[10px] theme-text-muted font-mono uppercase tracking-widest mt-1 font-bold">Standard Intelligence</p>
          </div>

          <div className="flex items-baseline gap-1 mb-8">
            <span className="text-4xl font-black theme-text-primary">$0</span>
            <span className="theme-text-muted text-xs font-mono">/mo</span>
          </div>

          <ul className="space-y-4 mb-12 flex-grow">
            <FeatureItem label="Global Hub Access" active={true} />
            <FeatureItem label="Standard Pulse Alerts" active={true} />
            <FeatureItem label="Basic PI Tracking" active={true} />
            <FeatureItem label="Public Leaderboard" active={true} />
            <FeatureItem label="High-Res Satellite" active={false} />
            <FeatureItem label="AI Post-Game Synthesis" active={false} />
          </ul>

          <button 
            onClick={handleDowngrade}
            disabled={!isPro || loading === 'basic'}
            className={`w-full py-4 text-xs font-bold uppercase tracking-widest border-2 transition-all ${!isPro ? 'theme-bg-primary theme-border theme-text-muted cursor-not-allowed opacity-50' : 'theme-border theme-text-primary hover:theme-bg-primary'}`}
          >
            {loading === 'basic' ? 'Processing...' : !isPro ? 'Current Tier' : 'Downgrade System'}
          </button>
        </motion.div>

        {/* Pro Tier */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative theme-bg-secondary border-2 border-indigo-600 shadow-[10px_10px_0px_rgba(99,102,241,0.2)] p-8 flex flex-col h-full"
        >
          {isPro && (
             <div className="absolute top-4 right-4 bg-indigo-600 text-white text-[8px] font-bold px-2 py-1 uppercase tracking-widest">
               Strategic Access Active
             </div>
          )}

          <div className="mb-6">
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold uppercase tracking-tight text-indigo-600 dark:text-indigo-400">MeteorGrade Pro</h3>
              <Zap size={18} className="text-indigo-600 dark:text-indigo-400 fill-indigo-600 dark:fill-indigo-400" />
            </div>
            <p className="text-[10px] text-indigo-400 font-mono uppercase tracking-widest mt-1 font-bold">Full Spectrum Intelligence</p>
          </div>

          <div className="flex items-baseline gap-1 mb-8">
            <span className="text-4xl font-black theme-text-primary">$19</span>
            <span className="theme-text-muted text-xs font-mono">/mo</span>
          </div>

          <ul className="space-y-4 mb-12 flex-grow">
            <FeatureItem label="All Basic Features" active={true} />
            <FeatureItem label="High-Res Satellite Overlays" active={true} highlight />
            <FeatureItem label="Historical Telemetry Archives" active={true} highlight />
            <FeatureItem label="AI Deep Dive Synthesis" active={true} highlight />
            <FeatureItem label="Priority Pulse Uplink" active={true} highlight />
            <FeatureItem label="Custom UI Themes" active={true} highlight />
          </ul>

          <button 
            onClick={() => handleUpgrade('pro')}
            disabled={isPro || loading === 'pro'}
            className={`w-full py-4 text-xs font-bold uppercase tracking-widest transition-all ${isPro ? 'theme-bg-primary theme-border theme-text-muted cursor-not-allowed opacity-50' : 'bg-indigo-600 text-white hover:opacity-90 shadow-[4px_4px_0px_#1e1b4b]'}`}
          >
            {loading === 'pro' ? 'Initializing Payment...' : isPro ? 'Tier Active' : 'Upgrade to Pro'}
          </button>
        </motion.div>
      </div>

      <div className="theme-bg-secondary border theme-border p-8 max-w-2xl">
        <h4 className="text-[10px] font-bold uppercase tracking-widest theme-text-primary mb-4 flex items-center gap-2">
          <Shield size={14} className="text-indigo-600 dark:text-indigo-400" /> Organizational Deployment
        </h4>
        <p className="text-xs theme-text-secondary leading-relaxed font-mono">
          MeteorGrade enterprise licenses are available for television networks, catastrophe modeling firms, and emergency management agencies. 
          Contact ops@meteorgrade.io for custom integration quotes.
        </p>
      </div>
    </div>
  );
}

function FeatureItem({ label, active, highlight }: { label: string, active: boolean, highlight?: boolean }) {
  return (
    <li className={`flex items-center gap-3 text-xs ${active ? 'theme-text-primary' : 'theme-text-muted opacity-50'}`}>
      <div className={`p-0.5 rounded-full ${active ? (highlight ? 'bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400' : 'theme-bg-primary theme-text-secondary') : 'theme-bg-primary opacity-30 text-slate-200'}`}>
        <Check size={12} strokeWidth={3} />
      </div>
      <span className={`${active && highlight ? 'font-bold' : ''} ${!active ? 'line-through' : ''}`}>
        {label}
      </span>
    </li>
  );
}
