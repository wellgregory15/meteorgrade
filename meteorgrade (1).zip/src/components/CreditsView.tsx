import React from 'react';
import { Zap, ChevronRight } from 'lucide-react';

export default function CreditsView() {
  const tools = [
    { name: 'React', link: 'https://react.dev', category: 'Frontend' },
    { name: 'Tailwind CSS', link: 'https://tailwindcss.com', category: 'Styling' },
    { name: 'Vite', link: 'https://vitejs.dev', category: 'Build Core' },
    { name: 'Firebase', link: 'https://firebase.google.com', category: 'Infrastructure' },
    { name: 'Lucide React', link: 'https://lucide.dev', category: 'Interface Design' },
    { name: 'Motion', link: 'https://motion.dev', category: 'Dynamics' },
  ];

  const apis = [
    { name: 'National Weather Service (NWS) API', link: 'https://www.weather.gov/documentation/services-web-api', description: 'Primary source for active alerts, hazardous condition telemetry, and ground-truth validation.' },
    { name: 'Google Gemini API', link: 'https://deepmind.google/technologies/gemini/', description: 'Powering automated atmospheric debriefs, mission generation, and forensic analysis logic.' },
    { name: 'IEM NEXRAD WMS', link: 'https://mesonet.agron.iastate.edu/ogc/', description: 'Real-time high-resolution NEXRAD composite radar tiles and NWS warning polygons.' },
    { name: 'NOAA GOES Satellite', link: 'https://www.goes-r.gov/', description: 'Near-real-time infrared and multispectral satellite imagery layers.' },
    { name: 'Esri World Imagery', link: 'https://www.esri.com/', description: 'Global high-resolution satellite basemaps for professional terrain analysis.' },
    { name: 'CartoDB', link: 'https://carto.com/', description: 'Technically optimized tactical basemaps designed for high-contrast visibility.' },
  ];

  return (
    <div className="flex-1 flex flex-col h-full theme-bg-app">
      <div className="p-6 md:p-8 lg:p-12 max-w-6xl mx-auto w-full flex-1 overflow-y-auto custom-scrollbar">
        <div className="mb-12">
          <span className="text-[10px] font-black tracking-[0.4em] uppercase text-indigo-600 mb-2 block">System Intelligence</span>
          <h1 className="text-4xl md:text-5xl font-light tracking-tight theme-text-primary uppercase">
            Data <span className="font-bold">Provenance</span>
          </h1>
          <p className="theme-text-secondary mt-3 max-w-2xl text-lg font-medium leading-relaxed">
            MeteorGrade relies on mission-critical integrations with global meteorological networks and next-generation AI architectures to deliver high-precision verification.
          </p>
        </div>

        <section className="mb-20">
          <div className="flex items-center gap-4 mb-8">
            <div className="h-0.5 flex-1 bg-indigo-600/20" />
            <h2 className="text-[11px] font-black tracking-[0.5em] uppercase text-indigo-500">Core Intelligence & Telemetry</h2>
            <div className="h-0.5 flex-1 bg-indigo-600/20" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {apis.map((item) => (
              <a 
                key={item.name} 
                href={item.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="theme-bg-secondary border-2 theme-border p-8 flex flex-col gap-4 hover:border-indigo-400 group transition-all hover:shadow-[12px_12px_0px_var(--shadow-color)]"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold theme-text-primary group-hover:text-indigo-600 transition-colors uppercase tracking-tighter">{item.name}</h3>
                  <Zap className="text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity" size={18} />
                </div>
                <p className="theme-text-secondary text-sm font-medium leading-relaxed">
                  {item.description}
                </p>
                <div className="mt-auto pt-4 flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-indigo-600">
                  Access Provider Documentation <ChevronRight size={10} />
                </div>
              </a>
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center gap-4 mb-8">
            <div className="h-0.5 flex-1 bg-slate-200 dark:bg-slate-800" />
            <h2 className="text-[11px] font-black tracking-[0.5em] uppercase theme-text-muted">Development Ecosystem</h2>
            <div className="h-0.5 flex-1 bg-slate-200 dark:bg-slate-800" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {tools.map((item) => (
              <a 
                key={item.name} 
                href={item.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="theme-bg-secondary border theme-border p-4 flex flex-col items-center text-center gap-2 hover:border-indigo-400 transition-all hover:-translate-y-1"
              >
                <span className="text-[8px] font-bold uppercase tracking-widest text-indigo-500">{item.category}</span>
                <h3 className="font-bold theme-text-primary text-xs">{item.name}</h3>
              </a>
            ))}
          </div>
        </section>

        <div className="mt-20 pt-12 border-t theme-border flex flex-col items-center text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.4em] theme-text-muted mb-6">MeteorGrade Strategic Terminal</p>
          <div className="text-[11px] font-bold theme-text-secondary max-w-xl leading-loose uppercase tracking-tighter">
            This platform is an independent verification tool. All meteorological data is sourced from public and professional networks. Predictions and forensic analyses are processed via proprietary logic and Google Gemini architectures.
          </div>
        </div>
      </div>
    </div>
  );
}
