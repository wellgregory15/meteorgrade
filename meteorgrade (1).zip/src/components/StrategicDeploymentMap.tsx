import { useEffect, useState, useMemo, useRef } from 'react';
import { MapContainer, TileLayer, Rectangle, Popup, useMap, LayersControl, LayerGroup } from 'react-leaflet';
import L from 'leaflet';
import * as d3 from 'd3';
import { db } from '../lib/db';
import { collection, query, getDocs, where, limit, orderBy } from '../lib/db';
import { Loader2, Shield, Target, Zap, Info, ChevronRight, Globe, Users, TrendingUp, Filter, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface StrategicMapProps {
  user: any;
  profile?: any;
}

interface SectorData {
  id: string; // "lat_lon"
  bounds: [[number, number], [number, number]];
  dominatingSyndicate: string | null; // Syndicate ID
  dominatingSyndicateName: string | null;
  dominatingSyndicateTag: string | null;
  totalPi: number;
  syndicatePiMap: Record<string, { name: string, tag: string, pi: number }>;
}

function MapResizer({ setMap }: { setMap: (map: L.Map) => void }) {
  const map = useMap();
  useEffect(() => {
    if (map) {
      setMap(map);
      // Force immediate resize set
      const timer = setTimeout(() => {
        if (map && (map as any)._container) {
          map.invalidateSize();
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [map, setMap]);
  return null;
}

/**
 * D3-Powered Isallobaric Overlay
 * Visualizes "Precision Pressure" - atmospheric dominance through collective accuracy
 */
function IsallobaricOverlay({ data, syndicates, active }: { data: any[], syndicates: any[], active: boolean }) {
  const map = useMap();
  const svgRef = useRef<SVGSVGElement>(null);
  const layerRef = useRef<L.SVG>(null);

  useEffect(() => {
    if (!active) {
      if (svgRef.current) d3.select(svgRef.current).selectAll("*").remove();
      return;
    }

    const svg = d3.select(svgRef.current);
    const g = svg.select("g.isallobaric-layer");

    const update = () => {
      if (!active || !map || !(map as any)._container) return;
      
      const bounds = map.getBounds();
      const topLeft = map.latLngToLayerPoint(bounds.getNorthWest());
      const bottomRight = map.latLngToLayerPoint(bounds.getSouthEast());

      svg
        .attr("width", Math.max(0, bottomRight.x - topLeft.x))
        .attr("height", Math.max(0, bottomRight.y - topLeft.y))
        .style("left", topLeft.x + "px")
        .style("top", topLeft.y + "px");

      g.attr("transform", `translate(${-topLeft.x},${-topLeft.y})`);

      // Project data
      const projectedData = data.filter(d => d.lat && d.lon).map(d => {
        const point = map.latLngToLayerPoint([d.lat, d.lon]);
        return {
          ...d,
          x: point.x,
          y: point.y,
          value: d.actualGrade?.score || 10
        };
      });

      // Define gradients for each syndicate
      const defs = svg.select("defs").empty() ? svg.append("defs") : svg.select("defs");
      syndicates.concat([{ id: 'independent_analysts', tag: 'IND', name: 'Independent' }]).forEach(syn => {
        const id = `grad-${syn.id}`;
        if (defs.select(`#${id}`).empty()) {
          const grad = defs.append("radialGradient").attr("id", id);
          const color = getSynColor(syn.id);
          grad.append("stop").attr("offset", "0%").attr("stop-color", color).attr("stop-opacity", 0.6);
          grad.append("stop").attr("offset", "100%").attr("stop-color", color).attr("stop-opacity", 0);
        }
      });

      // Simple density/pressure circles with radial gradients
      const points = g.selectAll<SVGCircleElement, any>("circle.pressure-point")
        .data(projectedData, d => d.id);

      points.exit()
        .transition()
        .duration(500)
        .attr("r", 0)
        .remove();

      points.enter()
        .append("circle")
        .attr("class", "pressure-point")
        .attr("r", 0)
        .merge(points as any)
        .transition()
        .duration(800)
        .attr("cx", d => d.x)
        .attr("cy", d => d.y)
        .attr("r", d => {
          if (!map || !(map as any)._container) return 0;
          const baseZoom = 4;
          const currentZoom = map.getZoom();
          const zoomScale = Math.pow(1.8, currentZoom - baseZoom);
          return (d.value / 2) * zoomScale;
        })
        .attr("fill", d => `url(#grad-${d.syndicateId || 'independent_analysts'})`)
        .style("mix-blend-mode", "plus-lighter");
    };

    function getSynColor(synId: string | null) {
      if (!synId || synId === 'independent_analysts') return '#94a3b8';
      const colors = ['#6366f1', '#e11d48', '#059669', '#d97706', '#7c3aed', '#db2777', '#2563eb'];
      const index = synId.split('').reduce((acc: number, char: string) => acc + char.charCodeAt(0), 0) % colors.length;
      return colors[index];
    }

    map.on('viewreset moveend', update);
    update();

    return () => {
      map.off('viewreset moveend', update);
    };
  }, [map, data, active]);

  return (
    <svg 
      ref={svgRef} 
      className="pointer-events-none" 
      style={{ position: 'absolute', zIndex: 1000, mixBlendMode: 'screen', top: 0, left: 0 }}
    >
      <g className="isallobaric-layer" />
    </svg>
  );
}

export default function StrategicDeploymentMap({ user, profile }: StrategicMapProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sectors, setSectors] = useState<SectorData[]>([]);
  const [rawForecasts, setRawForecasts] = useState<any[]>([]);
  const [syndicates, setSyndicates] = useState<any[]>([]);
  const [activeMissions, setActiveMissions] = useState<any[]>([]);
  const [mapInstance, setMapInstance] = useState<L.Map | null>(null);
  const [selectedSector, setSelectedSector] = useState<SectorData | null>(null);
  const [gridSize, setGridSize] = useState(2); // 2 degree boxes
  const [isReady, setIsReady] = useState(false);
  const [overlayMode, setOverlayMode] = useState<'territorial' | 'isallobaric'>('territorial');

  useEffect(() => {
    setIsReady(true);
    console.log("[StrategicMap] Component mounted");
  }, []);

  const fetchData = async () => {
    if (!isReady) return;
    
    console.log(`[StrategicMap] Initializing data fetch sequence (Grid: ${gridSize})...`);
    setLoading(true);
    setError(null);

    // Safety timeout: stop loading after 15s
    const timeoutId = setTimeout(() => {
      setLoading(prev => {
        if (prev) {
          console.warn("[StrategicMap] Safety timeout triggered");
          setError("Network sync taking longer than expected. Attempting connection recovery...");
          return false;
        }
        return prev;
      });
    }, 15000);

    try {
      // 1. Fetch Syndicates
      let synList: any[] = [];
      try {
        const synSnap = await getDocs(query(collection(db, 'syndicates')));
        synList = synSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        console.log(`[StrategicMap] Found ${synList.length} syndicates`);
        setSyndicates(synList);
      } catch (e) {
        console.warn("[StrategicMap] Failed to fetch syndicates - moving on", e);
      }

      // 2. Fetch Active Global Missions
      try {
        const missionsSnap = await getDocs(query(
          collection(db, 'missions'), 
          where('status', '==', 'active'), 
          where('is_global', '==', true),
          limit(10)
        ));
        setActiveMissions(missionsSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (e) {
        console.warn("[StrategicMap] Failed to fetch missions", e);
      }

      // 3. Fetch Recent Forecasts (Reduced limit for stability)
      console.log("[StrategicMap] Fetching recent forecasts...");
      const forecastsSnap = await getDocs(query(
        collection(db, 'forecasts'),
        orderBy('created_at', 'desc'),
        limit(500)
      ));
      const allForecasts = forecastsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      console.log(`[StrategicMap] Processed ${allForecasts.length} forecasts`);
      setRawForecasts(allForecasts);

      // 4. Calculate Sectors
      const sectorMap: Record<string, SectorData> = {};
      
      allForecasts.forEach((f: any) => {
        if (!f.lat || !f.lon || isNaN(f.lat) || isNaN(f.lon)) return;
        
        const latBin = Math.floor(f.lat / gridSize) * gridSize;
        const lonBin = Math.floor(f.lon / gridSize) * gridSize;
        const key = `${latBin}_${lonBin}`;
        
        if (!sectorMap[key]) {
          sectorMap[key] = {
            id: key,
            bounds: [[latBin, lonBin], [latBin + gridSize, lonBin + gridSize]],
            dominatingSyndicate: null,
            dominatingSyndicateName: null,
            dominatingSyndicateTag: null,
            totalPi: 0,
            syndicatePiMap: {}
          };
        }
        
        const piGain = f.actualGrade?.score || f.userScore || 10;
        
        if (f.syndicate_id) {
          const syn = synList.find(s => s.id === f.syndicate_id);
          if (syn) {
            if (!sectorMap[key].syndicatePiMap[syn.id]) {
              sectorMap[key].syndicatePiMap[syn.id] = { name: syn.name, tag: syn.tag, pi: 0 };
            }
            sectorMap[key].syndicatePiMap[syn.id].pi += piGain;
            sectorMap[key].totalPi += piGain;
          }
        } else {
          const indId = 'independent_analysts';
          if (!sectorMap[key].syndicatePiMap[indId]) {
            sectorMap[key].syndicatePiMap[indId] = { name: 'Independent Analysts', tag: 'IND', pi: 0 };
          }
          sectorMap[key].syndicatePiMap[indId].pi += piGain;
          sectorMap[key].totalPi += piGain;
        }
      });

      const sectorList = Object.values(sectorMap).map(sector => {
        let winnerId = null;
        let maxPi = -1;
        Object.entries(sector.syndicatePiMap).forEach(([id, data]) => {
          if (data.pi > maxPi) {
            maxPi = data.pi;
            winnerId = id;
          }
        });
        const winnerData = winnerId ? sector.syndicatePiMap[winnerId] : null;
        return {
          ...sector,
          dominatingSyndicate: winnerId,
          dominatingSyndicateName: winnerData?.name || null,
          dominatingSyndicateTag: winnerData?.tag || null
        };
      });

      setSectors(sectorList);
    } catch (err: any) {
      console.error("[StrategicMap] Fatal Data Fetch Error:", err);
      setError(`Critical System Failure: ${err.message || 'Unknown database exception'}`);
    } finally {
      setLoading(false);
      clearTimeout(timeoutId);
    }
  };

  useEffect(() => {
    fetchData();
  }, [isReady, gridSize]);

  const getSyndicateColor = (synId: string | null) => {
    if (!synId) return '#64748b'; // Slate
    if (synId === 'independent_analysts') return '#94a3b8'; // Light Slate
    const colors = ['#6366f1', '#e11d48', '#059669', '#d97706', '#7c3aed', '#db2777', '#2563eb'];
    const index = synId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % colors.length;
    return colors[index];
  };

  const dashboardStats = useMemo(() => {
    return {
      activeSectors: sectors.length,
      contestedSectors: sectors.filter(s => Object.keys(s.syndicatePiMap).length > 1).length,
      unclaimedSectors: sectors.filter(s => !s.dominatingSyndicate).length,
      totalInfluence: sectors.reduce((acc, s) => acc + s.totalPi, 0)
    };
  }, [sectors]);

  return (
    <div className="flex flex-col min-h-[900px] gap-6 p-4">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 shrink-0">
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Territorial Conflict Matrix</span>
          <h2 className="text-3xl font-light uppercase tracking-tighter mt-1 theme-text-primary">Strategic <span className="font-bold">Deployment</span></h2>
        </div>
        
        <div className="flex items-center gap-6">
           {/* Top Stats Bar */}
           <div className="hidden lg:flex items-center gap-8 px-6 py-2 theme-bg-secondary border theme-border">
              <div className="flex flex-col">
                <span className="text-[8px] font-black theme-text-muted uppercase tracking-widest text-right">Operational Sectors</span>
                <span className="text-sm font-mono font-bold theme-text-primary text-right">{dashboardStats.activeSectors}</span>
              </div>
              <div className="flex flex-col border-l theme-border pl-8">
                <span className="text-[8px] font-black theme-text-muted uppercase tracking-widest text-right">Contested Zones</span>
                <span className="text-sm font-mono font-bold text-amber-500 text-right">{dashboardStats.contestedSectors}</span>
              </div>
              <div className="flex flex-col border-l theme-border pl-8">
                <span className="text-[8px] font-black theme-text-muted uppercase tracking-widest text-right">Total Influence</span>
                <span className="text-sm font-mono font-bold text-indigo-600 text-right">{dashboardStats.totalInfluence} PI</span>
              </div>
           </div>

           <div className="flex theme-bg-secondary p-1 border theme-border mr-4">
               <button 
                onClick={() => setOverlayMode('territorial')}
                className={`px-3 py-2 text-[9px] font-bold uppercase transition-all flex items-center gap-2 ${overlayMode === 'territorial' ? 'bg-slate-900 text-white shadow-md' : 'theme-text-muted hover:theme-text-secondary'}`}
               >
                 <Shield size={10} /> Territory
               </button>
               <button 
                onClick={() => setOverlayMode('isallobaric')}
                className={`px-3 py-2 text-[9px] font-bold uppercase transition-all flex items-center gap-2 ${overlayMode === 'isallobaric' ? 'bg-indigo-600 text-white shadow-md' : 'theme-text-muted hover:theme-text-secondary'}`}
               >
                 <Activity size={10} /> Pressure
               </button>
           </div>

           <div className="flex theme-bg-secondary p-1 border theme-border">
             {[1, 2.5, 5].map(size => (
               <button 
                key={size}
                onClick={() => setGridSize(size)}
                className={`px-4 py-2 text-[9px] font-bold uppercase transition-all ${gridSize === size ? 'bg-indigo-600 text-white shadow-md' : 'theme-text-muted hover:theme-text-secondary'}`}
               >
                 {size}°
               </button>
             ))}
           </div>
        </div>
      </div>

      <div className="flex-1 relative min-h-[600px]">
        {loading && (
          <div className="absolute inset-0 z-[2000] flex items-center justify-center bg-slate-950/20 backdrop-blur-[2px] transition-all">
             <div className="flex flex-col items-center gap-4 py-8 px-12 theme-bg-secondary border-2 border-slate-900 shadow-2xl">
               <Loader2 className="animate-spin text-indigo-600" size={32} />
               <p className="text-[10px] font-black uppercase tracking-[0.3em] theme-text-muted">Syncing Intelligence...</p>
             </div>
          </div>
        )}

        {error ? (
          <div className="flex-1 flex items-center justify-center theme-bg-secondary border-2 border-red-500 shadow-[12px_12px_0px_rgba(239,68,68,0.2)] min-h-[600px] font-mono p-8">
             <div className="flex flex-col items-center gap-6 max-w-md text-center">
               <Zap className="text-red-500 animate-pulse" size={48} />
               <div>
                 <h3 className="text-sm font-bold uppercase tracking-widest text-red-500 mb-2">Sync Connection Interrupted</h3>
                 <p className="text-xs theme-text-secondary leading-relaxed uppercase">{error}</p>
               </div>
               <button 
                 onClick={() => fetchData()}
                 className="px-8 py-3 bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-red-500 transition-colors shadow-[6px_6px_0px_#fca5a5]"
               >
                 Force Re-Synchronization
               </button>
             </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col md:flex-row gap-6">
            {/* Map Container */}
            <div className="flex-1 relative border-2 border-slate-900 shadow-[12px_12px_0px_var(--shadow-color)] z-0 overflow-hidden" style={{ minHeight: '600px' }}>
              <MapContainer 
                center={[39.8283, -98.5795]} 
                zoom={4} 
                maxZoom={10}
                minZoom={3}
                style={{ height: '600px', width: '100%', background: '#0f172a' }}
              >
                <MapResizer setMap={setMapInstance} />
                <TileLayer
                  attribution='&copy; <a href="https://carto.com/">CartoDB</a>'
                  url={document.documentElement.classList.contains('dark') 
                    ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                    : "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"}
                />

                <IsallobaricOverlay 
                  data={rawForecasts} 
                  syndicates={syndicates} 
                  active={overlayMode === 'isallobaric'} 
                />

                {/* Strategic Sectors */}
                {overlayMode === 'territorial' && sectors.map((sector) => (
                  <Rectangle
                    key={sector.id}
                    bounds={sector.bounds}
                    pathOptions={{
                      fillColor: getSyndicateColor(sector.dominatingSyndicate),
                      fillOpacity: Math.min(0.6, 0.1 + (sector.totalPi / 500)),
                      color: getSyndicateColor(sector.dominatingSyndicate),
                      weight: 1,
                      opacity: 0.3
                    }}
                    eventHandlers={{
                      click: () => setSelectedSector(sector),
                      mouseover: (e) => e.target.setStyle({ fillOpacity: 0.8, weight: 2, opacity: 1 }),
                      mouseout: (e) => e.target.setStyle({ fillOpacity: Math.min(0.6, 0.1 + (sector.totalPi / 500)), weight: 1, opacity: 0.3 })
                    }}
                  >
                    <Popup>
                      <div className="p-3 theme-bg-secondary min-w-[200px]">
                        <span className="text-[8px] font-black uppercase tracking-widest text-slate-500">Sector Dominance</span>
                        <h3 className="text-sm font-bold theme-text-primary uppercase mt-1">
                          {sector.dominatingSyndicateName ? `[${sector.dominatingSyndicateTag}] ${sector.dominatingSyndicateName}` : 'Unclaimed Territory'}
                        </h3>
                        <div className="mt-4 space-y-2">
                           <div className="flex justify-between text-[10px] font-bold">
                             <span className="theme-text-secondary">Sector Intel</span>
                             <span className="theme-text-primary">{sector.totalPi} TP</span>
                           </div>
                           <div className="w-full bg-slate-200 dark:bg-slate-800 h-1">
                              <div className="h-full bg-indigo-500" style={{ width: `${Math.min(100, sector.totalPi / 10)}%` }} />
                           </div>
                        </div>
                      </div>
                    </Popup>
                  </Rectangle>
                ))}
              </MapContainer>
              
              {sectors.length === 0 && !loading && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-900/5 dark:bg-slate-900/20 pointer-events-none z-10 transition-opacity">
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="theme-bg-secondary p-8 border-b-4 border-indigo-600 shadow-2xl text-center max-w-xs pointer-events-auto"
                  >
                    <Target size={32} className="text-indigo-400 mx-auto mb-4" />
                    <h4 className="text-[11px] font-black uppercase tracking-[0.2em] theme-text-primary">Operational Void</h4>
                    <p className="text-[10px] theme-text-muted mt-2 uppercase leading-relaxed">The strategic matrix is currently dormant. Deploy forecasts to establish territorial influence and populate the matrix.</p>
                  </motion.div>
                </div>
              )}

              {/* Map Overlays */}
              <div className="absolute top-4 left-4 z-[1000] flex flex-col gap-2 pointer-events-none">
                 <div className="bg-slate-900/80 backdrop-blur-md p-4 border border-slate-700 shadow-2xl pointer-events-auto max-w-xs">
                    <h3 className="text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                      <Shield size={10} /> Syndicate Dominance Legend
                    </h3>
                    <div className="space-y-2">
                      {syndicates.map(syn => (
                        <div key={syn.id} className="flex items-center gap-2 text-[10px] font-bold text-white">
                          <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: getSyndicateColor(syn.id) }} />
                          <span className="truncate opacity-80">[{syn.tag}] {syn.name}</span>
                        </div>
                      ))}
                      <div className="flex items-center gap-2 text-[10px] font-bold text-white border-t border-slate-700/50 pt-2 mt-2">
                        <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: getSyndicateColor('independent_analysts') }} />
                        <span className="truncate opacity-80">[IND] Independent Analysts</span>
                      </div>
                      {syndicates.length === 0 && (
                         <p className="text-[8px] text-slate-500 uppercase italic mt-1">No formal syndicates active</p>
                      )}
                    </div>
                 </div>
              </div>
            </div>

            {/* Intelligence Sidebar */}
            <div className="w-full md:w-80 shrink-0 flex flex-col gap-6 min-h-[400px] md:min-h-0">
              {/* Active Sector Details */}
              <div className="theme-bg-secondary border theme-border flex flex-col min-h-0 shadow-lg">
                 <div className="p-4 border-b theme-border flex items-center justify-between theme-bg-primary">
                    <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-secondary flex items-center gap-2">
                      <Globe size={14} className="text-indigo-600" /> Sector Intel
                    </h3>
                 </div>
                 
                 <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                   {overlayMode === 'isallobaric' ? (
                      <div className="space-y-6">
                         <div className="p-4 bg-indigo-600/10 border border-indigo-600/20 text-indigo-600">
                           <span className="text-[8px] font-black uppercase tracking-widest">Global Pressure Index</span>
                           <p className="text-lg font-mono font-bold leading-tight">PRECISION <br/>EQUILIBRIUM</p>
                         </div>
                         
                         <div className="space-y-4">
                           <h4 className="text-[10px] font-black uppercase tracking-widest theme-text-primary border-b theme-border pb-2">
                             Atmospheric Dominance
                           </h4>
                           <div className="p-4 theme-bg-primary border theme-border">
                              <p className="text-[10px] theme-text-muted uppercase leading-relaxed italic">
                                "The Isallobaric overlay visualizes the concentration of successful forecasts. Areas of high intensity represent sectors where Syndicates have successfully achieved accuracy-based territorial capture."
                              </p>
                           </div>
                           
                           <div className="space-y-2">
                              {syndicates.map(syn => {
                                const synForecasts = rawForecasts.filter(f => f.syndicateId === syn.id);
                                const pressure = synForecasts.reduce((acc, f) => acc + (f.actualGrade?.score || 10), 0);
                                if (pressure === 0) return null;
                                return (
                                  <div key={syn.id} className="flex justify-between items-center text-[11px] font-bold">
                                     <div className="flex items-center gap-2">
                                       <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: getSyndicateColor(syn.id) }} />
                                       <span className="theme-text-primary">[{syn.tag}] {syn.name}</span>
                                     </div>
                                     <span className="theme-text-secondary">{pressure} DP</span>
                                  </div>
                                );
                              })}
                           </div>
                         </div>
                         <div className="p-4 theme-bg-secondary border theme-border">
                            <span className="text-[8px] font-black theme-text-muted uppercase tracking-widest">Active Forecast Capture</span>
                            <div className="mt-2 text-xl font-bold font-mono theme-text-primary">
                               {rawForecasts.length}<span className="text-xs text-slate-500 ml-2">UPLINKS</span>
                            </div>
                         </div>
                      </div>
                   ) : selectedSector ? (
                     <div className="space-y-6">
                        <div className="p-4 bg-slate-900 text-white border-l-4 border-indigo-600">
                          <span className="text-[8px] font-black uppercase tracking-widest text-indigo-400">Position</span>
                          <p className="text-lg font-mono font-bold">{selectedSector.bounds[0][0].toFixed(1)}°N, {selectedSector.bounds[0][1].toFixed(1)}°E</p>
                        </div>

                        <div className="space-y-4">
                          <h4 className="text-[10px] font-black uppercase tracking-widest theme-text-primary border-b theme-border pb-2 flex items-center justify-between">
                            Influence Breakdown
                            <TrendingUp size={12} />
                          </h4>
                          <div className="space-y-3">
                            {Object.entries(selectedSector.syndicatePiMap)
                              .sort((a,b) => b[1].pi - a[1].pi)
                              .map(([id, data]) => (
                                <div key={id} className="space-y-1.5">
                                  <div className="flex justify-between text-[11px] font-bold">
                                    <span className="theme-text-primary">[{data.tag}] {data.name}</span>
                                    <span className="theme-text-secondary">{data.pi} PI</span>
                                  </div>
                                  <div className="h-1 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                                    <motion.div 
                                      initial={{ width: 0 }}
                                      animate={{ width: `${(data.pi / selectedSector.totalPi) * 100}%` }}
                                      className="h-full"
                                      style={{ backgroundColor: getSyndicateColor(id) }}
                                    />
                                  </div>
                                </div>
                              ))}
                          </div>
                        </div>

                        <button 
                          onClick={() => setSelectedSector(null)}
                          className="w-full py-3 text-[9px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors border border-dashed theme-border"
                        >
                          Reset Intelligence View
                        </button>
                     </div>
                   ) : (
                     <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-40 grayscale">
                        <Target size={48} className="theme-text-muted mb-4" />
                        <p className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-muted">Select a sector on the map to begin analysis</p>
                     </div>
                   )}
                 </div>
              </div>

              {/* Regional Missions */}
              <div className="theme-bg-secondary border theme-border flex flex-col min-h-0 shadow-lg">
                 <div className="p-4 border-b theme-border flex items-center justify-between theme-bg-primary">
                    <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-secondary flex items-center gap-2">
                      <Zap size={14} className="text-amber-500" /> Active Operations
                    </h3>
                 </div>
                 <div className="flex-1 overflow-y-auto custom-scrollbar">
                   {activeMissions.length > 0 ? (
                     <div className="divide-y theme-border">
                       {activeMissions.map(m => (
                         <div key={m.id} className="p-4 hover:theme-bg-primary transition-colors cursor-pointer group">
                           <h4 className="text-[11px] font-bold uppercase theme-text-primary group-hover:text-indigo-600 transition-colors">{m.title}</h4>
                           <p className="text-[9px] theme-text-secondary mt-1 font-mono uppercase tracking-widest">{m.start_date} → {m.end_date}</p>
                           <div className="mt-3 flex items-center gap-2">
                             <Users size={10} className="theme-text-muted" />
                             <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest">Global Objective</span>
                           </div>
                         </div>
                       ))}
                     </div>
                   ) : (
                     <div className="p-8 text-center text-[10px] font-bold theme-text-muted uppercase tracking-widest">
                       No ongoing global operations
                     </div>
                   )}
                 </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
