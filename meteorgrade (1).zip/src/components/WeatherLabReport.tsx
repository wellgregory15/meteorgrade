import { FileText, Thermometer, Wind, CloudRain, Activity, Award } from 'lucide-react';
import { motion } from 'motion/react';

interface LabReportProps {
  forecast: any;
  student: any;
  syndicate: any;
  onClose: () => void;
}

export default function WeatherLabReport({ forecast, student, syndicate, onClose }: LabReportProps) {
  const printReport = () => {
    window.print();
  };

  const grade = forecast.actualGrade || {};

  return (
    <div className="fixed inset-0 z-[100] bg-white text-slate-900 overflow-y-auto p-4 md:p-12 print:p-0 print:m-0 print:static scrollbar-hide">
      <div className="max-w-[800px] mx-auto bg-white border-[3px] border-slate-900 p-8 md:p-12 relative print:border-none">
        
        {/* Header - Institutional Style */}
        <div className="flex flex-col md:flex-row justify-between items-start border-b-[3px] border-slate-900 pb-8 mb-8 gap-6">
          <div>
            <h1 className="text-3xl font-black uppercase tracking-tighter leading-none mb-2">Weather Lab Investigation</h1>
            <div className="text-[10px] font-black uppercase tracking-widest text-slate-500">
              S-CODE: {syndicate?.tag || 'UNSET'} • {syndicate?.organization_name || 'METEOR GRADE ACADEMY'}
            </div>
            <div className="mt-4 flex flex-wrap gap-4">
              <div className="text-[10px] font-bold uppercase"><span className="text-slate-400">Analyst:</span> {student?.profile?.displayName || 'REDACTED'}</div>
              <div className="text-[10px] font-bold uppercase"><span className="text-slate-400">Date:</span> {new Date(forecast.createdAt?.toDate ? forecast.createdAt.toDate() : forecast.createdAt).toLocaleDateString()}</div>
              <div className="text-[10px] font-bold uppercase"><span className="text-slate-400">Location:</span> {forecast.location}</div>
            </div>
          </div>
          <div className="bg-slate-900 text-white p-4 text-center min-w-[120px]">
            <div className="text-[10px] font-black uppercase tracking-widest mb-1">Final Score</div>
            <div className="text-4xl font-black">{grade.weightedScore || 'N/A'}</div>
            <div className="text-[8px] font-bold uppercase mt-1">NGSS Proficient</div>
          </div>
        </div>

        {/* Section: Hypothesis */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-1.5 h-6 bg-indigo-600" />
            <h2 className="text-sm font-black uppercase tracking-widest">I. Meteorological Hypothesis</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="border border-slate-200 p-4">
              <Thermometer size={16} className="mb-2 text-slate-400" />
              <div className="text-[8px] font-black text-slate-400 uppercase">Target Temp</div>
              <div className="text-lg font-black">{forecast.predictedTemp}°F</div>
            </div>
            <div className="border border-slate-200 p-4">
              <Wind size={16} className="mb-2 text-slate-400" />
              <div className="text-[8px] font-black text-slate-400 uppercase">Wind Velocity</div>
              <div className="text-lg font-black">{forecast.conditions?.windSpeed || '--'} MPH</div>
            </div>
            <div className="border border-slate-200 p-4">
              <CloudRain size={16} className="mb-2 text-slate-400" />
              <div className="text-[8px] font-black text-slate-400 uppercase">Conditions</div>
              <div className="text-lg font-black uppercase text-xs truncate leading-tight">{forecast.conditions?.cloudCover || 'N/A'}</div>
            </div>
            <div className="border border-slate-200 p-4">
              <Activity size={16} className="mb-2 text-slate-400" />
              <div className="text-[8px] font-black text-slate-400 uppercase">Timing</div>
              <div className="text-lg font-black">{forecast.conditions?.timeOfDay || '--'}</div>
            </div>
          </div>
          <div className="bg-slate-50 p-6 border-l-4 border-slate-400">
            <span className="text-[8px] font-black text-slate-400 uppercase block mb-2">Scientific Logic & Reasoning</span>
            <p className="text-xs leading-relaxed font-serif italic text-slate-700">
              "{forecast.logicNotes || 'No logic submission recorded.'}"
            </p>
          </div>
        </section>

        {/* Section: Ground Truth Data */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-1.5 h-6 bg-emerald-600" />
            <h2 className="text-sm font-black uppercase tracking-widest">II. Empirical Observation (Ground Truth)</h2>
          </div>
          {forecast.status === 'completed' && forecast.actualTelemetry ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="flex justify-between items-center text-[10px] pb-2 border-b border-slate-100">
                  <span className="font-bold text-slate-400 uppercase">Observed Temp</span>
                  <span className="font-black text-lg">{forecast.actualTelemetry.temp}°F</span>
                </div>
                <div className="flex justify-between items-center text-[10px] pb-2 border-b border-slate-100">
                  <span className="font-bold text-slate-400 uppercase">Condition Match</span>
                  <span className="font-black text-lg uppercase text-xs">{forecast.actualTelemetry.conditions}</span>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center text-[10px] pb-2 border-b border-slate-100">
                  <span className="font-bold text-slate-400 uppercase">Delta Variance</span>
                  <span className={`font-black text-lg ${Math.abs(forecast.predictedTemp - forecast.actualTelemetry.temp) > 5 ? 'text-red-500' : 'text-emerald-500'}`}>
                    {Math.abs(forecast.predictedTemp - forecast.actualTelemetry.temp).toFixed(1)}°
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center border-2 border-dashed border-slate-200">
              <p className="text-[10px] font-bold uppercase text-slate-400 italic">Instrumentation awaiting sync or station telemetry unavailable.</p>
            </div>
          )}
        </section>

        {/* Section: Post-Analysis */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-1.5 h-6 bg-red-600" />
            <h2 className="text-sm font-black uppercase tracking-widest text-red-600">III. Post-Event Investigation Cleanup</h2>
          </div>
          <div className="space-y-6">
            <div className="p-6 bg-slate-900 text-white">
              <Award size={20} className="mb-4 text-emerald-400" />
              <h4 className="text-[10px] font-black uppercase tracking-widest mb-2 text-indigo-300">Forensic Critique (AI Deep Dive)</h4>
              <p className="text-xs leading-relaxed opacity-90">
                {grade.critique || "Awaiting final terminal processing from local meteorological arrays."}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-slate-200 p-4">
                <h5 className="text-[9px] font-black uppercase mb-1">The Win</h5>
                <p className="text-[10px] text-slate-600 leading-tight">{grade.win || 'Identification of core variables.'}</p>
              </div>
              <div className="border border-slate-200 p-4">
                <h5 className="text-[9px] font-black uppercase mb-1 text-red-500">The Miss</h5>
                <p className="text-[10px] text-slate-600 leading-tight">{grade.miss || 'Bias towards station climatology over local signals.'}</p>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <div className="mt-12 pt-8 border-t-[3px] border-slate-900 flex justify-between items-end">
          <div className="space-y-1">
            <div className="text-[8px] font-black uppercase tracking-widest">NGSS Standard Alignment</div>
            <div className="text-[10px] font-bold">MS-ESS2-5: Atmospheric Circulation Data Analysis</div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="w-32 h-1 border-b border-black md:inline-block hidden" />
            <div className="text-[8px] font-black uppercase text-slate-400">Teacher Signature</div>
          </div>
        </div>
        
        {/* Verification QR Mockup */}
        <div className="absolute top-12 right-12 opacity-5 hidden md:block">
           <div className="w-16 h-16 border-2 border-black p-1">
             <div className="grid grid-cols-4 grid-rows-4 h-full gap-0.5">
               {[...Array(16)].map((_, i) => (
                 <div key={i} className={`bg-black ${Math.random() > 0.5 ? 'opacity-100' : 'opacity-0'}`} />
               ))}
             </div>
           </div>
        </div>
      </div>

      {/* Floating Controls */}
      <div className="fixed bottom-8 right-8 flex gap-4 print:hidden">
        <button 
          onClick={onClose}
          className="px-6 py-3 bg-slate-100 text-slate-900 border-2 border-slate-900 font-black uppercase text-xs hover:bg-slate-200 transition-all shadow-[4px_4px_0px_#000]"
        >
          Close Report
        </button>
        <button 
          onClick={printReport}
          className="px-6 py-3 bg-indigo-600 text-white font-black uppercase text-xs hover:bg-slate-900 transition-all flex items-center gap-2 shadow-[4px_4px_0px_rgba(79,70,229,0.3)]"
        >
          <FileText size={16} /> Export (Print/PDF)
        </button>
      </div>
    </div>
  );
}
