import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, Zap, Target, ArrowRight, X, ChevronUp, ChevronDown } from 'lucide-react';

interface FlashpointOverlayProps {
  alerts: any[];
  onViewAlert: (alert: any) => void;
}

export default function FlashpointOverlay({ alerts, onViewAlert }: FlashpointOverlayProps) {
  const [isDismissed, setIsDismissed] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  if (alerts.length === 0 || isDismissed) return null;

  // We use the most severe alert for the background pulse (usually Level 1)
  const isExtreme = alerts.some(a => a.severityLevel === 1 || a.severity === 'Extreme');
  const visibleAlerts = isExpanded ? alerts : alerts.slice(0, 3);

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:bottom-6 sm:right-6 sm:left-auto z-[100] w-auto sm:w-full sm:max-w-sm pointer-events-none">
      <div className="pointer-events-auto">
        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-slate-900 border border-red-600/50 shadow-2xl overflow-hidden rounded-sm"
        >
          {/* Header */}
          <div className="bg-red-600 p-3 sm:p-2 flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-black uppercase tracking-widest text-[10px] sm:text-[9px]">
              <ShieldAlert size={12} className={isExtreme ? "animate-pulse" : ""} />
              Condition: {isExtreme ? "Critical Severity" : "High Severity"}
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setIsExpanded(!isExpanded)}
                className="text-white/80 hover:text-white transition-colors"
              >
                {isExpanded ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
              </button>
              <button 
                onClick={() => setIsDismissed(true)}
                className="text-white/80 hover:text-white transition-colors border-l border-white/20 pl-2"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          <div className={`transition-all duration-300 ${isExpanded ? 'max-h-[60vh] sm:max-h-[400px]' : 'max-h-[220px] sm:max-h-[180px]'} overflow-y-auto custom-scrollbar`}>
            <div className="p-4 sm:p-3 flex flex-col gap-2">
              {visibleAlerts.map((alert, idx) => (
                <div key={idx} className="flex items-start gap-3 bg-slate-800/40 p-3 sm:p-2 border border-slate-800 hover:border-slate-700 transition-all group">
                  <div className="shrink-0">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${alert.severity === 'Extreme' ? 'bg-red-900/50 text-red-500' : 'bg-amber-900/50 text-amber-500'}`}>
                      <Zap size={12} />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-bold text-[11px] sm:text-[10px] uppercase truncate">{alert.event}</h4>
                    <p className="text-[10px] sm:text-[9px] text-slate-400 font-medium truncate">{alert.location || alert.area}</p>
                  </div>
                  <button 
                    onClick={() => onViewAlert(alert)}
                    className="shrink-0 self-center p-2.5 sm:p-1.5 bg-red-600 hover:bg-red-700 text-white transition-all"
                  >
                    <ArrowRight size={12} />
                  </button>
                </div>
              ))}
              
              {!isExpanded && alerts.length > 3 && (
                <button 
                  onClick={() => setIsExpanded(true)}
                  className="text-[10px] sm:text-[9px] font-bold text-red-500 uppercase tracking-widest hover:text-red-400 transition-colors text-center py-2 sm:py-1 bg-slate-900/50 border border-dashed border-red-900/30"
                >
                  + {alerts.length - 3} More Severe Events
                </button>
              )}
            </div>
          </div>

          <div className="bg-slate-950 p-2 border-t border-slate-800/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-red-600 rounded-full animate-ping" />
              <span className="text-[10px] sm:text-[8px] font-bold text-slate-500 uppercase tracking-widest">Live Intelligence Stream</span>
            </div>
            <span className="text-[9px] sm:text-[8px] font-black text-white/40 uppercase">HQ-GRID-ALPHA</span>
          </div>
        </motion.div>
      </div>

      {/* Extreme Pulse Overlay */}
      <AnimatePresence>
        {isExtreme && !isDismissed && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.05, 0] }}
            exit={{ opacity: 0 }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="fixed inset-0 bg-red-600 pointer-events-none z-[-1] border-[8px] sm:border-[12px] border-red-600/10"
          />
        )}
      </AnimatePresence>
    </div>
  );
}
