import React from 'react';
import { motion } from 'motion/react';
import { 
  LogIn, 
  Radio, 
  Smartphone, 
  ChevronRight, 
  Shield, 
  Activity, 
  Target, 
  Zap, 
  Map as MapIcon,
  Award,
  ArrowRight,
  Database,
  CloudRain
} from 'lucide-react';

interface LandingPageViewProps {
  authMode: 'login' | 'signup' | 'choice';
  setAuthMode: (mode: 'login' | 'signup' | 'choice') => void;
  loginLoading: boolean;
  loginError: string | null;
  handleLogin: () => void;
  handleEmailAuth: (e: React.FormEvent) => void;
  email: string;
  setEmail: (email: string) => void;
  password: string;
  setPassword: (password: string) => void;
  setShowInstallGuide: (show: boolean) => void;
  isIframe: boolean;
}

export default function LandingPageView({
  authMode,
  setAuthMode,
  loginLoading,
  loginError,
  handleLogin,
  handleEmailAuth,
  email,
  setEmail,
  password,
  setPassword,
  setShowInstallGuide,
  isIframe
}: LandingPageViewProps) {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const isConfigured = !!supabaseUrl && !supabaseUrl.includes('placeholder');

  return (
    <div className="min-h-screen theme-bg-app theme-text-primary font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {!isConfigured && (
        <div className="bg-amber-500 text-white py-3 px-6 text-[10px] font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-4 sticky top-0 z-[100] shadow-md">
          <Shield size={14} className="animate-pulse" />
          <span>System Offline: Supabase Configuration Required. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.</span>
          <div className="hidden md:block w-px h-4 bg-white/20 mx-2" />
          <span className="opacity-80 italic hidden md:inline">Consult the setup documentation to initialize the bureau database.</span>
        </div>
      )}
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 theme-bg-secondary/80 backdrop-blur-md border-b theme-border">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-slate-900 dark:bg-indigo-600 flex items-center justify-center rounded-sm">
              <Shield size={16} className="text-white" />
            </div>
            <span className="text-lg font-light tracking-tighter uppercase theme-text-primary">
              Meteor<span className="font-extrabold text-indigo-600 dark:text-blue-400">Academy</span>
            </span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-[10px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors">The Hub</a>
            <a href="#scoring" className="text-[10px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors">Scoring Logic</a>
            <a href="#mission" className="text-[10px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors">Our Mission</a>
            <div className="flex items-center gap-3 ml-4">
              <button 
                onClick={() => {
                  setAuthMode('login');
                  const el = document.getElementById('auth-section');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-[10px] font-bold uppercase tracking-widest theme-text-primary px-3 hover:text-indigo-600 transition-colors"
              >
                Sign In
              </button>
              <button 
                onClick={() => {
                  setAuthMode('signup');
                  const el = document.getElementById('auth-section');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="bg-slate-900 dark:bg-indigo-600 text-white px-5 py-2 text-[10px] font-bold uppercase tracking-widest hover:opacity-80 transition-all rounded-sm shadow-[4px_4px_0px_transparent] active:shadow-none"
              >
                Join Network
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden border-b theme-border">
        <div className="absolute inset-0 z-0 opacity-10 dark:opacity-5 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(var(--border-color)_1px,transparent_1px)] [background-size:20px_20px]" />
          <CloudRain size={800} className="absolute -right-40 -top-40 rotate-12 theme-text-muted/10" />
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <div className="inline-flex items-center gap-3 px-3 py-1 bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800 rounded-full">
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.2em]">Live Atmospheric Feed Active</span>
              </div>
              <h1 className="text-5xl md:text-7xl font-light leading-[1.1] tracking-tight theme-text-primary">
                Where Science <br />
                <span className="font-extrabold text-slate-900 dark:text-indigo-400">Meets Intuition.</span>
              </h1>
              <p className="text-lg md:text-xl theme-text-secondary max-w-lg leading-relaxed">
                The hub for weather enthusiasts to master the atmosphere. Define probability distributions, challenge the ensemble consensus, and learn the science behind every storm.
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                <button 
                   onClick={() => {
                    setAuthMode('signup');
                    const el = document.getElementById('auth-section');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-slate-900 dark:bg-indigo-600 text-white px-8 py-4 text-[11px] font-bold uppercase tracking-[0.2em] hover:opacity-90 transition-all shadow-[10px_10px_0px_var(--shadow-color)] flex items-center gap-3 group"
                >
                  Start Your Training <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button 
                   onClick={() => {
                    setAuthMode('login');
                    const el = document.getElementById('auth-section');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="theme-bg-secondary border theme-border theme-text-primary px-8 py-4 text-[11px] font-bold uppercase tracking-[0.2em] hover:opacity-80 transition-all flex items-center gap-3"
                >
                  Sign In to Terminal
                </button>
              </div>
              <div className="flex items-center gap-6 pt-8 border-t theme-border">
                <div className="flex flex-col">
                  <span className="text-[10px] theme-text-muted font-bold uppercase tracking-widest">Powered By</span>
                  <span className="text-sm font-bold theme-text-primary uppercase tracking-tight">Gemini Pro 1.5</span>
                </div>
                <div className="w-px h-8 theme-border" />
                <div className="flex flex-col">
                  <span className="text-[10px] theme-text-muted font-bold uppercase tracking-widest">Network</span>
                  <span className="text-sm font-bold theme-text-primary uppercase tracking-tight">NWS Satellite Sync</span>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="relative"
            >
              <div className="theme-bg-secondary border theme-border p-2 theme-shadow relative overflow-hidden group">
                <div className="aspect-[4/3] theme-bg-primary flex items-center justify-center p-4">
                   <div className="w-full h-full border theme-border theme-bg-secondary shadow-sm flex flex-col">
                      <div className="h-8 border-b theme-border theme-bg-primary flex items-center px-4 gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-red-400" />
                        <div className="w-2 h-2 rounded-full bg-amber-400" />
                        <div className="w-2 h-2 rounded-full bg-emerald-400" />
                      </div>
                      <div className="flex-1 p-6 space-y-6">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1">
                             <div className="h-2 w-24 theme-bg-primary rounded-full" />
                             <div className="h-4 w-40 theme-bg-primary rounded-full opacity-50" />
                          </div>
                          <div className="w-12 h-12 border-2 border-indigo-600 rounded-sm flex items-center justify-center text-indigo-600 font-bold">A+</div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="h-20 theme-bg-primary border theme-border rounded-sm" />
                          <div className="h-20 theme-bg-primary border theme-border rounded-sm" />
                        </div>
                        <div className="space-y-2">
                           <div className="h-1.5 w-full theme-bg-primary rounded-full" />
                           <div className="h-1.5 w-full theme-bg-primary rounded-full" />
                           <div className="h-1.5 w-3/4 theme-bg-primary rounded-full" />
                        </div>
                      </div>
                   </div>
                </div>
                <div className="absolute inset-0 bg-indigo-600/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                   <span className="theme-bg-secondary px-4 py-2 border theme-border text-[10px] font-bold uppercase tracking-widest shadow-[4px_4px_0px_currentColor] theme-text-primary">Atmospheric Preview Mode</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 md:py-32 theme-bg-secondary">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center space-y-4 mb-24">
            <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.3em]">Operational Capabilities</span>
            <h2 className="text-4xl md:text-5xl font-light tracking-tight theme-text-primary">Master your <span className="font-extrabold">Observations</span></h2>
            <p className="theme-text-secondary max-w-2xl mx-auto text-sm leading-relaxed">
              Whether you're a seasoned storm chaser or just starting your atmospheric journey, we provide the tools to build your deep-scale forecasting skills.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: MapIcon,
                title: "Ensemble Consensus",
                desc: "Every forecast tracks the bureau consensus. Identify the 'bust' before it happens and earn Contrarian King bonuses for successful model defiance.",
                color: "indigo"
              },
              {
                icon: Target,
                title: "Sensor-Level Truth",
                desc: "Verified by nearest-station terrestrial sensors. Your precision is measured against hard METAR/Mesonet telemetry, not regional averages.",
                color: "emerald"
              },
              {
                icon: Zap,
                title: "Acme Risk Profiles",
                desc: "Don't just guess a number. Use advanced probability distribution modeling to define 10th and 90th percentile outcome ranges.",
                color: "amber"
              },
              {
                icon: Shield,
                title: "Syndicate Protocol",
                desc: "Form elite squads of analysts. Share meteorological logic, upvote sound reasoning, and compete for dominant sector control badges across regional hubs.",
                color: "indigo"
              },
              {
                icon: Activity,
                title: "Flashpoint Intercept",
                desc: "Rapid-response tactical forecasting during active Tornado or Severe Thunderstorm warnings. High-severity events offer double PI multipliers.",
                color: "red"
              },
              {
                icon: Award,
                title: "Analyst Tiering",
                desc: "Climb from Novice Observer to Global Lead. Every verified forecast builds your permanent Precision Index (PI) status and Bureau clearances.",
                color: "indigo"
              },
              {
                icon: Database,
                title: "AI Forensic Review",
                desc: "Gemini AI analyzes every deviation, providing a technical debrief on why your predicted model succeeded or failed at a mesoscale level.",
                color: "amber"
              }
            ].map((feature, i) => (
              <div key={i} className="group p-8 border theme-border hover:border-slate-900 dark:hover:border-indigo-600 transition-all hover:shadow-[10px_10px_0px_var(--shadow-color)] flex flex-col h-full theme-bg-app">
                <div className={`w-12 h-12 theme-bg-secondary border theme-border flex items-center justify-center rounded-sm mb-6 group-hover:bg-${feature.color}-50 dark:group-hover:bg-${feature.color}-900/20 group-hover:border-${feature.color}-200 transition-colors`}>
                  <feature.icon size={20} className={
                    feature.color === 'indigo' ? 'text-indigo-600 dark:text-indigo-400' :
                    feature.color === 'emerald' ? 'text-emerald-600 dark:text-emerald-400' :
                    feature.color === 'amber' ? 'text-amber-500 dark:text-amber-400' :
                    'text-red-600 dark:text-red-400'
                  } />
                </div>
                <h3 className="text-lg font-bold uppercase tracking-tight mb-4 theme-text-primary">{feature.title}</h3>
                <p className="text-sm theme-text-secondary leading-relaxed flex-1">
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Scoring Logic Section */}
      <section id="scoring" className="py-24 theme-bg-app border-y theme-border">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.3em]">The Precision Index (PI)</span>
              <h2 className="text-4xl font-light tracking-tight">Scientifically <span className="font-extrabold theme-text-primary">Measuring Accuracy</span></h2>
              <p className="theme-text-secondary text-sm leading-relaxed">
                The Precision Index isn't just a number—it's a multi-dimensional analysis of your forecasting competence. We evaluate your data against three primary metrics to determine your global analyst tier.
              </p>
              
              <div className="space-y-6">
                {[
                  { label: "Ensemble Deviation", desc: "Bonus rewards for pinning outcomes when the crowd consensus was historically poor." },
                  { label: "Acme Range Fit", desc: "Evaluation of how ground truth falls within your predicted 10/90 distribution range." },
                  { label: "Sensor-Sync Precision", desc: "Direct comparison to nearest-station METAR/Mesonet telemetry data points." }
                ].map((stat, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="w-10 h-10 shrink-0 theme-bg-secondary border theme-border flex items-center justify-center font-mono text-[10px] font-bold theme-text-primary">{i+1}</div>
                    <div>
                      <h4 className="text-[11px] font-bold uppercase tracking-widest theme-text-primary">{stat.label}</h4>
                      <p className="text-[11px] theme-text-muted mt-1">{stat.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="theme-bg-secondary border theme-border p-8 theme-shadow">
               <div className="space-y-6">
                 <div className="flex justify-between items-end border-b theme-border pb-4">
                   <span className="text-[10px] font-bold uppercase tracking-widest theme-text-muted">Sample Algorithm Output</span>
                   <span className="text-[10px] font-mono text-indigo-600 dark:text-indigo-400">v4.2.0-STABLE</span>
                 </div>
                 <div className="space-y-4 font-mono text-[11px]">
                   <div className="flex justify-between py-2 border-b theme-border opacity-50">
                     <span className="theme-text-muted">Deviation Offset</span>
                     <span className="text-emerald-500">-1.2° (OPTIMAL)</span>
                   </div>
                   <div className="flex justify-between py-2 border-b theme-border opacity-50">
                     <span className="theme-text-muted">Condition Alignment</span>
                     <span className="text-indigo-600 dark:text-indigo-400">1.0 (MATCHED)</span>
                   </div>
                   <div className="flex justify-between py-2 border-b theme-border opacity-50">
                     <span className="theme-text-muted">Campaign Bonus</span>
                     <span className="text-amber-500">+15.0 PI</span>
                   </div>
                   <div className="pt-4 flex justify-between items-baseline">
                     <span className="theme-text-primary font-bold uppercase">Final Accuracy</span>
                     <span className="text-2xl font-light tracking-tighter theme-text-primary">97.8%</span>
                   </div>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section id="mission" className="py-24 theme-bg-secondary">
        <div className="max-w-4xl mx-auto px-6 text-center space-y-8">
           <span className="text-[10px] font-bold theme-text-muted uppercase tracking-[0.3em]">Institutional Vision</span>
              <h2 className="text-4xl font-light tracking-tight theme-text-primary">A Shared Goal for <span className="font-extrabold">Better Data</span></h2>
              <p className="theme-text-secondary text-sm leading-relaxed max-w-2xl mx-auto">
                MeteorAcademy was founded on a single principle: learning through accountability. We believe the path to better atmospheric understanding begins with individual prediction and objective verification. Join a community that values precision over clickbait.
              </p>
           <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-12">
             {[
               { val: "100%", lab: "Transparency" },
               { val: "24/7", lab: "Satellite Link" },
               { val: "1.5", lab: "Model Index" },
               { val: "Global", lab: "Network" }
             ].map((m, i) => (
               <div key={i} className="space-y-1">
                 <div className="text-2xl font-light tracking-tighter theme-text-primary">{m.val}</div>
                 <div className="text-[9px] font-bold uppercase tracking-widest theme-text-muted">{m.lab}</div>
               </div>
             ))}
           </div>
        </div>
      </section>

      <section id="auth-section" className="py-24 md:py-48 theme-bg-app relative overflow-hidden border-t theme-border">
        <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-indigo-600/5 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-amber-500/5 blur-[100px] rounded-full pointer-events-none" />

        <div className="max-w-xl mx-auto px-6 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="theme-bg-secondary border theme-border p-8 md:p-12 theme-shadow theme-text-primary"
          >
            <div className="flex flex-col mb-10 text-center items-center">
              <span className="text-[10px] font-bold tracking-[0.3em] uppercase text-indigo-600 dark:text-indigo-400 mb-3 underline decoration-indigo-200 dark:decoration-indigo-900 underline-offset-8">Analyst Interface 02</span>
              
              <div className="flex gap-1 theme-bg-app p-1 rounded-sm mt-4 w-full max-w-sm mb-4">
                <button 
                  onClick={() => setAuthMode('login')}
                  className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${authMode === 'login' || authMode === 'choice' ? 'theme-bg-secondary theme-text-primary shadow-sm border theme-border' : 'theme-text-muted hover:theme-text-secondary'}`}
                >
                  Log In
                </button>
                <button 
                  onClick={() => setAuthMode('signup')}
                  className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${authMode === 'signup' ? 'theme-bg-secondary theme-text-primary shadow-sm border theme-border' : 'theme-text-muted hover:theme-text-secondary'}`}
                >
                  Create Profile
                </button>
              </div>
            </div>

            {loginError && (
              <div className="mb-8 p-4 theme-bg-error border theme-border flex items-start gap-3">
                <Radio size={16} className="theme-text-error shrink-0 mt-0.5 animate-pulse" />
                <p className="text-[11px] font-bold theme-text-error uppercase tracking-widest leading-loose">
                   Signal Interference: {loginError}
                </p>
              </div>
            )}

            <div className="space-y-6">
              <div className="space-y-4">
                <button 
                  disabled={loginLoading}
                  onClick={handleLogin}
                  className={`w-full flex items-center justify-center gap-4 py-5 px-6 transition-all font-bold uppercase tracking-[0.2em] text-[11px] border theme-border ${
                    loginLoading ? 'opacity-50 cursor-not-allowed' : 'theme-bg-secondary theme-text-primary hover:theme-bg-primary shadow-[6px_6px_0px_#6366f1]'
                  }`}
                >
                    <div className="w-5 h-5 flex items-center justify-center">
                      <svg viewBox="0 0 24 24" className="w-full h-full"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
                    </div>
                    Continue with Google
                  </button>

                  {(isIframe || loginError?.includes('Popup')) && (
                    <a 
                      href={window.location.origin} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-full flex items-center justify-center gap-2 py-3 px-6 text-[9px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900 hover:theme-bg-primary transition-colors"
                    >
                      <Radio size={12} className="animate-pulse" />
                      Establish Direct Encrypted Link (Open in New Tab)
                    </a>
                  )}
                  
                  <div className="relative py-4 flex items-center">
                    <div className="flex-grow border-t theme-border opacity-50"></div>
                    <span className="flex-shrink mx-4 text-[9px] font-bold theme-text-muted uppercase tracking-widest leading-none">or use terminal access</span>
                    <div className="flex-grow border-t theme-border opacity-50"></div>
                  </div>
                </div>

              <form onSubmit={handleEmailAuth} className="space-y-5">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block px-1">Access Key (Email)</label>
                  <input 
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full theme-bg-primary border theme-border p-4 text-sm outline-none focus:border-indigo-600 transition-all font-mono theme-text-primary"
                    placeholder="analyst@meteorgrade.gov"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block px-1">Security Code (Password)</label>
                  <input 
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full theme-bg-primary border theme-border p-4 text-sm outline-none focus:border-indigo-600 transition-all theme-text-primary"
                    placeholder="••••••••"
                  />
                </div>

                <button 
                  disabled={loginLoading}
                  type="submit"
                  className={`w-full flex items-center justify-center gap-4 py-5 px-6 transition-all font-bold uppercase tracking-[0.2em] text-[11px] mt-4 ${
                    loginLoading ? 'opacity-50 cursor-not-allowed' : 'bg-slate-900 dark:bg-indigo-600 text-white hover:opacity-90 shadow-[10px_10px_0px_var(--border-color)]'
                  }`}
                >
                  {loginLoading ? 'Processing...' : (authMode === 'signup' ? 'Request Network Access' : 'Establish Session')}
                </button>
              </form>

              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest mt-6 px-1">
                <button type="button" onClick={() => setAuthMode('choice')} className="theme-text-muted hover:theme-text-secondary transition-colors uppercase flex items-center gap-1">
                  <Radio size={12} /> Options
                </button>
              </div>

              <button 
                onClick={() => setShowInstallGuide(true)}
                className="w-full flex items-center justify-center gap-2 py-4 theme-text-muted font-bold uppercase tracking-widest text-[9px] hover:text-indigo-600 transition-colors border-t theme-border mt-4"
              >
                <Smartphone size={14} /> PWA App Installation Guide
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="theme-bg-secondary border-t theme-border py-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
           <div className="flex flex-col items-center md:items-start gap-4">
              <div className="flex items-center gap-2">
                 <Shield size={16} className="theme-text-primary" />
                 <span className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-primary">Global Meteorology Bureau // HQ-001</span>
              </div>
              <p className="text-[10px] theme-text-muted font-mono tracking-wider">EST. 2026 // OPEN SOURCE ATMOSPHERIC ANALYTICS</p>
           </div>
           
           <div className="flex gap-8">
              <a href="#" className="text-[10px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors">Privacy</a>
              <a href="#" className="text-[10px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors">Analytical Logs</a>
              <a href="#" className="text-[10px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors">Forecaster Data</a>
           </div>
        </div>
      </footer>
    </div>
  );
}
