import { useState, useEffect } from 'react';
import { db } from '../lib/db';
import { collection, query, where, orderBy, onSnapshot, limit, Timestamp } from '../lib/db';
import { User } from '../lib/db';
import ForecastCard from './ForecastCard';
import { LayoutGrid, List as ListIcon, Database, Filter, Calendar, X, CheckSquare, RefreshCw } from 'lucide-react';

interface ForecastListProps {
  user: User;
  forecasts: any[];
  profile?: any;
}

export default function ForecastList({ user, forecasts: initialForecasts, profile }: ForecastListProps) {
  const [forecasts, setForecasts] = useState<any[]>(initialForecasts);
  const [loading, setLoading] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter States
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  useEffect(() => {
    let data = [...initialForecasts];

    // Apply Status Filter
    if (statusFilter !== 'all') {
      data = data.filter(f => f.status === statusFilter);
    }

    // Apply Date Filters
    if (startDate || endDate) {
      data = data.filter(f => {
        const createdAt = f.createdAt instanceof Timestamp ? f.createdAt.toDate() : new Date(f.createdAt);
        const start = startDate ? new Date(startDate) : null;
        const end = endDate ? new Date(endDate) : null;
        
        if (start) start.setHours(0, 0, 0, 0);
        if (end) end.setHours(23, 59, 59, 999);

        const isAfterStart = start ? createdAt >= start : true;
        const isBeforeEnd = end ? createdAt <= end : true;
        
        return isAfterStart && isBeforeEnd;
      });
    }

    setForecasts(data);
  }, [initialForecasts, statusFilter, startDate, endDate]);

  const resetFilters = () => {
    setStatusFilter('all');
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between border-b theme-border pb-4">
          <div className="flex items-center gap-3">
            <Database size={14} className="text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] theme-text-muted">Submission History</h3>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 text-[9px] font-bold uppercase tracking-widest px-3 py-1.5 transition-all border ${
                showFilters || statusFilter !== 'all' || startDate || endDate
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' 
                  : 'theme-bg-secondary theme-border theme-text-secondary hover:theme-text-primary hover:border-indigo-500'
              }`}
            >
              <Filter size={12} />
              {showFilters ? 'Hide Filters' : 'Filter Records'}
            </button>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => window.location.reload()}
                className="p-1.5 theme-bg-secondary theme-border border theme-text-muted hover:theme-text-primary transition-colors"
                title="Force Re-sync Satellite Link"
              >
                <RefreshCw size={14} />
              </button>
              <div className="text-[10px] font-bold theme-text-muted uppercase tracking-widest theme-bg-input px-3 py-1">
                {forecasts.length} Active Records
              </div>
            </div>
          </div>
        </div>

        {/* Filter Panel */}
        {showFilters && (
          <div className="theme-bg-secondary border theme-border theme-shadow p-6 grid grid-cols-1 md:grid-cols-3 gap-6 animate-in slide-in-from-top-2 duration-300">
            {/* Status Filter */}
            <div className="space-y-3">
              <label className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-muted flex items-center gap-2">
                <CheckSquare size={12} /> Verification Status
              </label>
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full border-b-2 theme-border focus:border-indigo-600 outline-none py-2 text-xs font-mono bg-transparent theme-text-primary"
              >
                <option value="all">ALL_STATUS</option>
                <option value="submitted">SUBMITTED</option>
                <option value="model_graded">MODEL_GRADED</option>
                <option value="completed">COMPLETED</option>
              </select>
            </div>

            {/* Date Start */}
            <div className="space-y-3">
              <label className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-muted flex items-center gap-2">
                <Calendar size={12} /> Range / From
              </label>
              <input 
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full border-b-2 theme-border focus:border-indigo-600 outline-none py-2 text-xs font-mono bg-transparent theme-text-primary"
              />
            </div>

            {/* Date End */}
            <div className="space-y-3">
              <label className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-muted flex items-center gap-2">
                <Calendar size={12} /> Range / To
              </label>
              <div className="flex items-center gap-2">
                <input 
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full border-b-2 theme-border focus:border-indigo-600 outline-none py-2 text-xs font-mono bg-transparent theme-text-primary"
                />
                {(statusFilter !== 'all' || startDate || endDate) && (
                  <button 
                    onClick={resetFilters}
                    className="p-2 text-red-500 hover:text-red-700 transition-colors"
                    title="Reset Filters"
                  >
                    <X size={16} />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {loading ? (
        <div className="flex flex-col items-center justify-center p-24 gap-4">
          <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-muted">Syncing Data Stream</span>
        </div>
      ) : forecasts.length === 0 ? (
        <div className="geometric-card p-24 text-center border-dashed theme-border">
          <Database size={40} className="mx-auto mb-6 theme-text-muted opacity-30" />
          <h3 className="text-xl font-light tracking-tight mb-2 theme-text-primary">ARCHIVE <span className="font-bold">CLEAN</span></h3>
          <p className="theme-text-secondary text-xs max-w-sm mx-auto leading-relaxed italic">
            No historical records detected in the filtered synchronization buffer. Refine your query parameters or initialize a new campaign.
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-8">
          {forecasts.map(f => (
            <ForecastCard key={f.id} forecast={f} profile={profile} />
          ))}
        </div>
      )}
    </div>
  );
}
