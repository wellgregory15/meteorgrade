import React, { useState, useEffect } from 'react';
import { db } from '../lib/db';
import { collection, query, where, orderBy, limit, getDocs, addDoc, serverTimestamp } from '../lib/db';
import { MessageSquare, Sparkles, TrendingUp, CheckCircle, AlertCircle, RefreshCw, Lock, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { getWeeklyDebrief } from '../services/geminiService';

interface WeeklyDebriefViewProps {
  user: any;
  profile?: any;
}

export default function WeeklyDebriefView({ user, profile }: WeeklyDebriefViewProps) {
  const [debrief, setDebrief] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const [completedCount, setCompletedCount] = useState<number | null>(null);

  useEffect(() => {
    const fetchLatestDebrief = async () => {
      try {
        // Fetch debrief
        const q = query(
          collection(db, 'weeklyDebriefs'), 
          where('userId', '==', user.uid), 
          orderBy('createdAt', 'desc'),
          limit(1)
        );
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          setDebrief(snapshot.docs[0].data());
        }

        // Fetch completed count
        const countQ = query(
          collection(db, 'forecasts'), 
          where('userId', '==', user.uid), 
          where('status', '==', 'completed')
        );
        const countSnap = await getDocs(countQ);
        setCompletedCount(countSnap.size);

      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchLatestDebrief();
  }, [user.uid]);

  const handleGenerate = async () => {
    if (completedCount !== null && completedCount < 3) return;
    
    setGenerating(true);
    try {
      // 1. Get recent forecasts for context
      const q = query(
        collection(db, 'forecasts'), 
        where('userId', '==', user.uid), 
        where('status', '==', 'completed'),
        orderBy('createdAt', 'desc'),
        limit(10)
      );
      const snapshot = await getDocs(q);
      const forecasts = snapshot.docs.map(d => d.data());

      // 2. Call Gemini
      const analysis = await getWeeklyDebrief(forecasts);
      
      // 3. Save to database
      const docData = {
        ...analysis,
        userId: user.uid,
        weekStartDate: new Date().toISOString().split('T')[0],
        createdAt: serverTimestamp()
      };
      await addDoc(collection(db, 'weeklyDebriefs'), docData);
      setDebrief(docData);
      setCompletedCount(prev => (prev || 0) + 1); // Refresh local count logic
    } catch (err) {
      console.error(err);
    } finally {
      setGenerating(false);
    }
  };

  if (loading) return <div className="p-20 text-center animate-pulse uppercase tracking-[0.2em] theme-text-muted">Synchronizing Insights...</div>;

  const hasRequirements = completedCount !== null && completedCount >= 3;
  const isPro = profile?.membership === 'pro';

  if (!isPro) {
    return (
      <div className="max-w-4xl mx-auto space-y-12">
        <div>
          <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Performance Analysis</span>
          <h2 className="text-2xl md:text-4xl font-light uppercase tracking-tighter mt-1 theme-text-primary">Weekly <span className="font-bold">Review</span></h2>
        </div>

        <div className="bg-slate-900 dark:bg-indigo-950 text-white p-12 md:p-20 relative overflow-hidden theme-shadow border theme-border flex flex-col items-center text-center space-y-8">
          <div className="absolute top-0 right-0 p-12 opacity-5 italic text-[150px] font-serif select-none hidden md:block">?</div>
          
          <div className="p-4 bg-indigo-600/20 rounded-full border border-indigo-500/30">
            <Lock size={32} className="text-indigo-400" />
          </div>

          <div className="space-y-4 max-w-lg relative z-10">
            <h3 className="text-2xl font-black uppercase tracking-tighter italic">Pro Membership Required</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Unlock the <span className="text-white font-bold italic">MeteorGrade Pro</span> intelligence suite to access weekly accuracy debriefs, automated trend detection, and personal growth diagnostics.
            </p>
          </div>

          <button 
            onClick={() => window.dispatchEvent(new CustomEvent('open-subscription'))}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-10 py-5 text-[11px] font-black uppercase tracking-[0.3em] transition-all flex items-center gap-3 group shadow-xl"
          >
            <Zap size={16} className="fill-white group-hover:scale-125 transition-transform" />
            Upgrade to Pro Intel
          </button>

          <div className="pt-8 grid grid-cols-3 gap-8 w-full max-w-md opacity-30 grayscale">
             <div className="flex flex-col items-center gap-2">
                <div className="h-1 w-full bg-slate-700" />
                <span className="text-[8px] font-bold uppercase tracking-widest">Trend Logic</span>
             </div>
             <div className="flex flex-col items-center gap-2">
                <div className="h-1 w-full bg-slate-700" />
                <span className="text-[8px] font-bold uppercase tracking-widest">Accuracy Delta</span>
             </div>
             <div className="flex flex-col items-center gap-2">
                <div className="h-1 w-full bg-slate-700" />
                <span className="text-[8px] font-bold uppercase tracking-widest">Growth Path</span>
             </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6">
        <div>
          <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Performance Analysis</span>
          <h2 className="text-2xl md:text-4xl font-light uppercase tracking-tighter mt-1 theme-text-primary">Weekly <span className="font-bold">Review</span></h2>
        </div>
        {!debrief && !generating && hasRequirements && (
          <button 
            onClick={handleGenerate}
            className="w-full sm:w-auto bg-slate-900 dark:bg-indigo-600 text-white p-4 hover:opacity-80 transition-all flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest theme-shadow"
          >
            <Sparkles size={16} /> Generate Review
          </button>
        )}
      </div>

      {generating ? (
        <div className="theme-bg-secondary border theme-border p-20 flex flex-col items-center justify-center space-y-8 theme-shadow">
          <div className="relative">
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
              className="w-16 h-16 border-2 border-indigo-600 border-dashed rounded-full"
            />
            <Sparkles size={24} className="absolute inset-0 m-auto text-indigo-600 animate-pulse" />
          </div>
          <div className="text-center space-y-2">
            <p className="text-sm font-bold uppercase tracking-[0.2em] theme-text-primary">Analyzing Weather Patterns</p>
            <p className="text-[10px] theme-text-muted uppercase tracking-widest">Gemini analyzing accuracy trends...</p>
          </div>
        </div>
      ) : debrief ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          {/* Main Insight */}
          <div className="bg-slate-900 dark:bg-indigo-950 text-white p-6 md:p-12 relative overflow-hidden theme-shadow border theme-border">
            <div className="absolute top-0 right-0 p-12 opacity-5 italic text-[120px] font-serif select-none hidden md:block">"</div>
            <div className="relative z-10 space-y-6">
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-sm ${debrief.precisionDelta > 0 ? 'bg-emerald-500' : 'bg-red-500'}`}>
                  <TrendingUp size={16} />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-300">
                  {debrief.precisionDelta > 0 ? '+' : ''}{debrief.precisionDelta}% Growth Delta
                </span>
              </div>
              <p className="text-lg md:text-2xl font-light leading-relaxed max-w-2xl">
                {debrief.insight}
              </p>
            </div>
          </div>

          {/* Pros and Cons */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="theme-bg-secondary border theme-border p-8 space-y-6 theme-shadow">
              <div className="flex items-center gap-3 theme-text-success">
                <CheckCircle size={20} />
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em]">Forecasting Strengths</h3>
              </div>
              <ul className="space-y-4">
                {debrief.pros?.map((pro: string, i: number) => (
                  <li key={i} className="flex gap-4 items-start">
                    <span className="text-[10px] font-mono theme-text-muted pt-1">0{i+1}</span>
                    <span className="text-sm theme-text-secondary">{pro}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="theme-bg-secondary border theme-border p-8 space-y-6 theme-shadow">
              <div className="flex items-center gap-3 theme-text-warning">
                <AlertCircle size={20} />
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em]">Improvement Areas</h3>
              </div>
              <ul className="space-y-4">
                {debrief.cons?.map((con: string, i: number) => (
                  <li key={i} className="flex gap-4 items-start">
                    <span className="text-[10px] font-mono theme-text-muted pt-1">0{i+1}</span>
                    <span className="text-sm theme-text-secondary">{con}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="flex justify-center pt-8">
            <button 
              onClick={handleGenerate}
              className="flex items-center gap-3 theme-text-muted hover:theme-text-primary transition-all text-[10px] font-bold uppercase tracking-widest"
            >
              <RefreshCw size={14} /> Recalculate Weekly Perspective
            </button>
          </div>
        </motion.div>
      ) : !hasRequirements ? (
        <div className="theme-bg-secondary border theme-border p-12 space-y-8 theme-shadow">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 theme-bg-primary flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0 border theme-border rounded-none">
              <AlertCircle size={24} />
            </div>
            <div className="space-y-2">
              <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] theme-text-primary">Insufficient Analysis Data</h3>
              <p className="text-xs theme-text-secondary leading-relaxed">
                The Gemini AI requires at least <span className="font-bold text-indigo-600 dark:text-indigo-400">3 completed forecasts</span> (verified against real-world observations) to generate a meaningful accuracy analysis.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-2">
            {[1, 2, 3].map(step => (
              <div key={step} className={`h-1.5 ${step <= (completedCount || 0) ? 'bg-indigo-600' : 'theme-bg-primary'}`} />
            ))}
          </div>

          <div className="flex justify-between items-center text-[9px] font-bold uppercase tracking-widest theme-text-muted pt-4 border-t theme-border">
            <span>Status / Restricted</span>
            <span>Progress / {completedCount || 0} of 3</span>
          </div>
        </div>
      ) : (
        <div className="p-20 border-2 border-dashed theme-border flex flex-col items-center justify-center text-center space-y-6 theme-bg-primary bg-indigo-500/5">
          <MessageSquare size={48} className="theme-text-muted opacity-20" />
          <p className="theme-text-secondary text-xs uppercase tracking-widest max-w-xs leading-loose">
            Generate your first review to see AI-driven insights on your prediction accuracy.
          </p>
        </div>
      )}
    </div>
  );
}
