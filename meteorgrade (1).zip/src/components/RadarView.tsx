import React, { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap, LayersControl, WMSTileLayer, LayerGroup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { usePreferences, convertValue, UnitPreference } from '../lib/preferences';
import { Calendar, Thermometer, Cloud, ChevronLeft, ChevronRight, Clock, Search, Target, Loader2, Zap, ShieldAlert, Navigation, Filter, X, Info, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RadarViewProps {
  forecasts: any[];
  flashpoints?: any[];
  onRefocus?: any;
  profile?: any;
}

function MapResizer() {
  const map = useMap();
  useEffect(() => {
    // Give the container a moment to expand in the flex layout before recalculating
    const timer = setTimeout(() => {
      if (map && (map as any)._container) {
        map.invalidateSize();
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [map]);
  return null;
}

export default function RadarView({ forecasts, flashpoints = [], onRefocus, profile }: RadarViewProps) {
  const { unitPreference, units } = usePreferences();
  const [filterDate, setFilterDate] = useState('');
  const [viewMode, setViewMode] = useState<'individual' | 'stacked'>('stacked');
  const [lastUpdate, setLastUpdate] = useState<string>(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
  const [mapInstance, setMapInstance] = useState<L.Map | null>(null);
  const [stormFilter, setStormFilter] = useState<'all' | 'extreme' | 'severe'>('all');
  const [selectedStorm, setSelectedStorm] = useState<any>(null);
  const [currentUserLocation, setCurrentUserLocation] = useState<[number, number] | null>(null);

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentUserLocation([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.error("Error getting user location:", error);
        }
      );
    }
  }, []);

  useEffect(() => {
    if (onRefocus && mapInstance && typeof onRefocus.lat === 'number' && typeof onRefocus.lon === 'number') {
      mapInstance.flyTo([onRefocus.lat, onRefocus.lon], 8);
      setSelectedStorm(onRefocus);
    }
  }, [onRefocus, mapInstance]);

  useEffect(() => {
    const timer = setInterval(() => {
      setLastUpdate(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 60000); // Update clock every minute
    return () => clearInterval(timer);
  }, []);

  const getRadarIcon = (status: string) => {
    const colorClass = status === 'completed' ? 'bg-emerald-500' : 'bg-indigo-500';
    return L.divIcon({
      className: 'custom-radar-icon',
      html: `<div class="relative flex h-6 w-6 items-center justify-center">
               <span class="animate-ping absolute inline-flex h-full w-full rounded-full opacity-50 ${colorClass}"></span>
               <span class="relative inline-flex rounded-full h-3 w-3 ${colorClass} shadow-[0_0_10px_currentColor]"></span>
             </div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
      popupAnchor: [0, -12]
    });
  };

  const getFlashpointIcon = (severity: string) => {
    const isExtreme = severity === 'Extreme' || severity === 'extreme';
    const colorClass = isExtreme ? 'bg-red-600' : 'bg-amber-500';
    return L.divIcon({
      className: 'custom-flashpoint-icon',
      html: `<div class="relative flex h-8 w-8 items-center justify-center bg-slate-900 rounded-full border-2 ${isExtreme ? 'border-red-600' : 'border-amber-500'} shadow-xl">
               <div class="text-white">
                 <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 L3 14 L12 14 L11 22 L21 10 L12 10 L13 2 Z"/></svg>
               </div>
               ${isExtreme ? `<span class="animate-ping absolute -inset-1 rounded-full border-2 border-red-600 opacity-75"></span>` : ''}
             </div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
      popupAnchor: [0, -16]
    });
  };

  const getUserLocationIcon = () => {
    return L.divIcon({
      className: 'user-location-icon',
      html: `<div class="relative flex h-6 w-6 items-center justify-center">
               <span class="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 bg-blue-500"></span>
               <div class="relative inline-flex rounded-full h-3 w-3 bg-blue-600 border-2 border-white shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>
             </div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
      popupAnchor: [0, -12]
    });
  };

  let displayForecasts = forecasts.filter(f => f.lat !== undefined && f.lon !== undefined);
  if (filterDate) {
    displayForecasts = displayForecasts.filter(f => f.targetDate === filterDate);
  }

  const filteredFlashpoints = useMemo(() => {
    return flashpoints.filter(fp => {
      if (stormFilter === 'extreme') return fp.severity === 'Extreme' || fp.severity === 'extreme';
      if (stormFilter === 'severe') return fp.severity === 'Severe' || fp.severity === 'severe';
      return true;
    });
  }, [flashpoints, stormFilter]);

  const extremes = useMemo(() => {
    if (displayForecasts.length === 0) return null;
    const hotNode = [...displayForecasts].sort((a, b) => b.highTemp - a.highTemp)[0];
    const coldNode = [...displayForecasts].sort((a, b) => a.lowTemp - b.lowTemp)[0];
    return { hotNode, coldNode };
  }, [displayForecasts]);

  // Pre-process for stacks if in stacked mode
  const renderList: any[][] = viewMode === 'stacked' 
    ? (Object.values(displayForecasts.reduce((acc, f) => {
        const plat = f.locationCoord?.lat || f.locationCoord?.latitude || f.lat;
        const plon = f.locationCoord?.lon || f.locationCoord?.longitude || f.lon;
        
        // Ensure coordinates are valid numbers before calling toFixed
        if (typeof plat !== 'number' || typeof plon !== 'number') return acc;
        
        const key = `${plat.toFixed(3)},${plon.toFixed(3)}`;
        if (!acc[key]) acc[key] = [];
        acc[key].push(f);
        return acc;
      }, {} as Record<string, any[]>)) as any[][])
    : displayForecasts.map(f => [f]);

  return (
    <div className="flex gap-6 h-[calc(100vh-8rem)] animate-in fade-in duration-700">
      <style>{`
        .leaflet-popup-content-wrapper { 
          border-radius: 0 !important; 
          box-shadow: 6px 6px 0px var(--shadow-color) !important; 
          border: 1px solid var(--border-color) !important; 
          padding: 0 !important;
          background: var(--bg-secondary) !important;
          color: var(--text-primary) !important;
        }
        .leaflet-popup-content { margin: 0 !important; }
        .leaflet-popup-tip-container { display: none !important; }
        .custom-radar-icon, .custom-flashpoint-icon { display: flex; align-items: center; justify-content: center; }
        .leaflet-container { background: var(--bg-primary) !important; }
      `}</style>

      {/* Side Navigation Panel */}
      <div className="w-80 shrink-0 flex flex-col gap-6 overflow-hidden hidden xl:flex">
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Global Telemetry</span>
          <h2 className="text-3xl font-light uppercase tracking-tighter mt-1 theme-text-primary">Command <span className="font-bold">Radar</span></h2>
        </div>

        <div className="bg-slate-900 dark:bg-indigo-950 border-2 border-slate-800 dark:border-indigo-900 text-white p-4 flex flex-col gap-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-400">Atmospheric Filters</h3>
            <Filter size={12} className="text-slate-500" />
          </div>
          
          <div className="space-y-4">
            <div className="flex flex-col">
              <label className="text-[8px] font-bold uppercase tracking-widest text-slate-500 mb-2">Observation Mode</label>
              <div className="flex theme-bg-input p-0.5 rounded-none border border-white/5">
                <button 
                  onClick={() => setViewMode('individual')}
                  className={`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-wider transition-all ${viewMode === 'individual' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  Raw
                </button>
                <button 
                  onClick={() => setViewMode('stacked')}
                  className={`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-wider transition-all ${viewMode === 'stacked' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  Stacked
                </button>
              </div>
            </div>

            <div className="flex flex-col">
              <label className="text-[8px] font-bold uppercase tracking-widest text-slate-500 mb-2">Intensity Filter</label>
              <div className="flex gap-2">
                {(['all', 'extreme', 'severe'] as const).map(type => (
                  <button 
                    key={type}
                    onClick={() => setStormFilter(type)}
                    className={`flex-1 py-1 text-[8px] font-bold uppercase tracking-widest border border-slate-700 transition-all ${stormFilter === type ? 'bg-white text-slate-900 border-white shadow-sm font-black' : 'hover:border-slate-500 text-slate-400'}`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col">
              <label className="text-[8px] font-bold uppercase tracking-widest text-slate-500 mb-2">Temporal Window</label>
              <input 
                type="date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
                className="bg-slate-800 dark:bg-slate-900 border border-slate-700 p-2 text-[10px] font-mono font-bold outline-none text-white focus:border-indigo-500 transition-colors shadow-inner"
              />
              {filterDate && (
                <button onClick={() => setFilterDate('')} className="mt-2 text-[8px] uppercase font-bold theme-text-error hover:opacity-80 transition-colors">Reset Timeline</button>
              )}
            </div>
          </div>
        </div>

        {/* Storm Event Navigator */}
        <div className="flex-1 flex flex-col min-h-0 theme-bg-secondary border theme-border overflow-hidden shadow-lg">
          <div className="p-4 border-b theme-border flex items-center justify-between theme-bg-primary">
            <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] theme-text-secondary flex items-center gap-2">
              <Zap size={14} className="text-amber-500" /> Active Storm Clusters
            </h3>
            <span className="bg-slate-900 text-white text-[9px] font-mono px-1.5 py-0.5">{filteredFlashpoints.length}</span>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-1">
            {filteredFlashpoints.length > 0 ? (
              <div className="space-y-1">
                {filteredFlashpoints.map((fp) => (
                  <div 
                    key={fp.id}
                    onClick={() => {
                      const lat = fp.locationCoord?.lat || fp.locationCoord?.latitude || fp.lat;
                      const lon = fp.locationCoord?.lon || fp.locationCoord?.longitude || fp.lon;
                      if (typeof lat === 'number' && typeof lon === 'number') {
                        mapInstance?.flyTo([lat, lon], 8);
                      }
                    }}
                    className="w-full text-left p-4 hover:theme-bg-primary transition-colors group border-b theme-border last:border-0 cursor-pointer"
                  >
                    <div className="flex justify-between items-start mb-1.5">
                      <span className={`text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 ${fp.severity === 'Extreme' ? 'bg-red-600 text-white' : 'bg-amber-100 text-amber-700'}`}>
                        {fp.severity}
                      </span>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedStorm(fp);
                        }}
                        className="p-1 hover:theme-bg-secondary transition-colors theme-text-muted"
                        title="View Full Intel"
                      >
                         <Info size={12} />
                      </button>
                    </div>
                    <h4 className="text-[10px] font-bold uppercase theme-text-primary mb-0.5 line-clamp-1">{fp.event}</h4>
                    <p className="text-[9px] theme-text-secondary leading-tight line-clamp-2">{fp.area || fp.location || 'Regional Cluster Delta'}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-slate-50/50 dark:bg-slate-900/50">
                <ShieldAlert size={32} className="theme-text-muted mb-3" />
                <p className="text-[10px] font-bold theme-text-muted uppercase tracking-widest leading-relaxed">No Critical Atmospheric Disruptions Detected</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col h-full min-w-0 main-content-container">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 shrink-0 mb-6 xl:hidden">
          <div className="flex flex-col gap-1">
            <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Global Telemetry</span>
            <h2 className="text-2xl md:text-3xl font-light uppercase tracking-tighter mt-1 theme-text-primary">Atmospheric <span className="font-bold">Radar</span></h2>
          </div>
          
          <div className="flex flex-wrap items-end gap-6 pb-1 border-b theme-border">
             <div className="flex flex-col">
                <label className="text-[9px] font-bold uppercase tracking-widest text-slate-400 mb-1">Mode</label>
                <div className="flex theme-bg-secondary p-0.5 rounded-sm border theme-border">
                  <button onClick={() => setViewMode('individual')} className={`px-3 py-1 text-[9px] font-bold uppercase rounded-sm ${viewMode === 'individual' ? 'bg-indigo-600 text-white shadow-sm' : 'theme-text-secondary'}`}>Raw</button>
                  <button onClick={() => setViewMode('stacked')} className={`px-3 py-1 text-[9px] font-bold uppercase rounded-sm ${viewMode === 'stacked' ? 'bg-indigo-600 text-white shadow-sm' : 'theme-text-secondary'}`}>Stacked</button>
                </div>
             </div>
             <div className="flex flex-col">
               <label className="text-[9px] font-bold uppercase tracking-widest text-slate-400 mb-1">Timeline</label>
               <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} className="py-1 text-xs font-bold font-mono outline-none bg-transparent theme-text-primary" />
             </div>
          </div>
        </div>

        <div className="flex-1 w-full relative border-2 border-slate-900 shadow-[12px_12px_0px_var(--shadow-color)] min-h-[400px] z-0 overflow-hidden group">
          <MapContainer 
            center={[39.8283, -98.5795]} 
            zoom={4} 
            style={{ height: '100%', width: '100%', background: 'var(--bg-primary)', position: 'absolute', inset: 0 }}
            ref={setMapInstance}
          >
            <MapResizer />
            
            <LayersControl position="topright">
              <LayersControl.BaseLayer checked name="Tactical View">
                <TileLayer
                  attribution='&copy; <a href="https://carto.com/">CartoDB</a>'
                  url={document.documentElement.classList.contains('dark') 
                    ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                    : "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"}
                />
              </LayersControl.BaseLayer>
              
              {profile?.membership === 'pro' ? (
                <>
                  <LayersControl.BaseLayer name="High-Res Satellite (Pro)">
                    <TileLayer
                      attribution='Tiles &copy; Esri &mdash; Source: Esri'
                      url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                    />
                  </LayersControl.BaseLayer>
                  <LayersControl.Overlay name="GOES IR Satellite (Pro)">
                    <WMSTileLayer
                      url="https://mesonet.agron.iastate.edu/cgi-bin/wms/goes/conus_ir.cgi?"
                      layers="goes_conus_ir"
                      format="image/png"
                      transparent={true}
                      attribution="NOAA / GOES"
                      opacity={0.65}
                    />
                  </LayersControl.Overlay>
                </>
              ) : (
                <LayersControl.Overlay name="Unlock High-Res / IR Layers (Pro)">
                  <LayerGroup />
                </LayersControl.Overlay>
              )}

              <LayersControl.Overlay checked name="Active Composite Radar">
                <WMSTileLayer
                  url="https://mesonet.agron.iastate.edu/cgi-bin/wms/nexrad/n0q.cgi?"
                  layers="nexrad-n0q-900913"
                  format="image/png"
                  transparent={true}
                  attribution="NWS / IEM"
                  opacity={0.8}
                  zIndex={120}
                />
              </LayersControl.Overlay>

              <LayersControl.Overlay name="NWS Watch/Warn Envelopes">
                <WMSTileLayer
                  url="https://mesonet.agron.iastate.edu/cgi-bin/wms/us/wwa.cgi?"
                  layers="warnings_c"
                  format="image/png"
                  transparent={true}
                  attribution="NOAA / NWS"
                  opacity={0.5}
                  version="1.3.0"
                />
              </LayersControl.Overlay>

              <LayersControl.Overlay checked name="Analyst Deployment Zones">
                <LayerGroup>
                   {renderList.map((stack, sIdx) => (
                    <ForecastMarker key={sIdx} stack={stack} units={units} unitPreference={unitPreference} getRadarIcon={getRadarIcon} />
                  ))}
                </LayerGroup>
              </LayersControl.Overlay>

              <LayersControl.Overlay checked name="Atmospheric Flashpoints">
                <LayerGroup>
                  {filteredFlashpoints.map((fp) => (
                    <FlashpointMarker key={fp.id} flashpoint={fp} getFlashpointIcon={getFlashpointIcon} onShowDetails={setSelectedStorm} />
                  ))}
                </LayerGroup>
              </LayersControl.Overlay>

              {currentUserLocation && (
                <LayersControl.Overlay checked name="Analyst Signal">
                  <Marker position={currentUserLocation} icon={getUserLocationIcon()}>
                    <Popup>
                      <div className="p-3 bg-white dark:bg-slate-900">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Telemetry Feed</span>
                        <h4 className="text-xs font-bold uppercase mt-1 theme-text-primary">Grid Position Confirmed</h4>
                      </div>
                    </Popup>
                  </Marker>
                </LayersControl.Overlay>
              )}
            </LayersControl>
          </MapContainer>

          {/* Storm Detail Modal */}
          <AnimatePresence>
            {selectedStorm && (
              <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 md:p-8 pointer-events-none">
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setSelectedStorm(null)}
                  className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm pointer-events-auto"
                />
                <motion.div 
                  initial={{ scale: 0.9, opacity: 0, y: 20 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  exit={{ scale: 0.9, opacity: 0, y: 20 }}
                  className="theme-bg-secondary w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl relative pointer-events-auto border theme-border"
                >
                  <div className={`p-6 text-white ${selectedStorm.severity === 'Extreme' ? 'bg-red-600' : 'bg-amber-600'}`}>
                    <div className="flex justify-between items-start mb-6">
                      <div className="flex items-center gap-4">
                        <div className="bg-white/20 p-2 rounded-sm backdrop-blur-md">
                          <ShieldAlert size={28} />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black uppercase tracking-[0.4em] opacity-80">Flashpoint Detected</span>
                          <h2 className="text-2xl md:text-3xl font-black uppercase tracking-tighter leading-none">{selectedStorm.event}</h2>
                        </div>
                      </div>
                      <button onClick={() => setSelectedStorm(null)} className="hover:rotate-90 transition-transform p-2">
                        <X size={28} />
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin size={14} className="opacity-80" />
                      <p className="text-xs font-black uppercase tracking-widest">{selectedStorm.area || selectedStorm.location || 'Coordinated Geographic Vector'}</p>
                    </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto custom-scrollbar p-6 md:p-10 space-y-10">
                    {selectedStorm.headline && (
                      <div className="bg-indigo-600/10 p-5 border-l-4 border-indigo-600 italic text-indigo-600 dark:text-indigo-400 text-xs font-bold uppercase tracking-tight">
                        "{selectedStorm.headline}"
                      </div>
                    )}

                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                      {[
                        { label: 'Effective', val: selectedStorm.effective ? new Date(selectedStorm.effective).toLocaleString() : 'Immediate' },
                        { label: 'Expires', val: new Date(selectedStorm.expires).toLocaleString() },
                        { label: 'Urgency', val: selectedStorm.urgency },
                        { label: 'Certainty', val: selectedStorm.certainty }
                      ].map((stat, i) => (
                        <div key={i} className="flex flex-col gap-2">
                          <span className="text-[9px] font-black theme-text-muted uppercase tracking-[0.2em]">{stat.label}</span>
                          <p className="text-xs font-mono font-bold theme-text-primary px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border theme-border">{stat.val || 'Unspecified'}</p>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center gap-3 border-b theme-border pb-3">
                        <div className="w-1.5 h-6 bg-indigo-600" />
                        <h3 className="text-[11px] font-black theme-text-primary uppercase tracking-[0.3em]">Technical Intelligence Report</h3>
                      </div>
                      <p className="text-sm theme-text-secondary leading-relaxed font-medium whitespace-pre-wrap selection:bg-indigo-600 selection:text-white">
                        {selectedStorm.description || 'Full technical overview pending download...'}
                      </p>
                    </div>

                    {selectedStorm.instruction && (
                      <div className="theme-bg-primary p-6 border-l-4 border-slate-900 dark:border-indigo-600">
                        <h3 className="text-[10px] font-black theme-text-primary uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                          <Target size={14} className="text-indigo-600" /> Protective Measures
                        </h3>
                        <p className="text-sm theme-text-secondary leading-relaxed italic whitespace-pre-wrap font-medium">
                          {selectedStorm.instruction}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="p-5 theme-bg-primary border-t theme-border flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                       <Zap size={16} className="text-amber-500 animate-pulse" />
                       <div className="flex flex-col">
                         <span className="text-[9px] font-black theme-text-muted uppercase tracking-widest">Digital Signal Source</span>
                         <span className="text-[10px] font-bold theme-text-primary uppercase tracking-widest">NOAA / NWS Terrestrial Cluster</span>
                       </div>
                    </div>
                    <button 
                      onClick={() => {
                        const lat = selectedStorm.locationCoord?.lat || selectedStorm.locationCoord?.latitude || selectedStorm.lat;
                        const lon = selectedStorm.locationCoord?.lon || selectedStorm.locationCoord?.longitude || selectedStorm.lon;
                        if (typeof lat === 'number' && typeof lon === 'number') {
                          mapInstance?.flyTo([lat, lon], 12);
                        }
                        setSelectedStorm(null);
                      }}
                      className="w-full sm:w-auto bg-slate-900 dark:bg-indigo-600 text-white px-8 py-3 text-[10px] font-black uppercase tracking-[0.3em] hover:bg-slate-800 dark:hover:bg-indigo-700 transition-all shadow-[8px_8px_0px_var(--shadow-color)] active:translate-y-1 active:shadow-none"
                    >
                      Refocus Satellite
                    </button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>


          <div className="absolute bottom-6 left-3 z-[1000] pointer-events-none flex flex-col gap-2">
            {currentUserLocation && (
              <button 
                onClick={() => {
                  mapInstance?.flyTo(currentUserLocation, 10);
                }}
                className="pointer-events-auto bg-slate-900/80 backdrop-blur-md p-2 border border-slate-700 shadow-xl text-white hover:bg-indigo-600 transition-colors group"
                title="Locate Me"
              >
                <Navigation size={14} className="group-hover:rotate-45 transition-transform" />
              </button>
            )}
            <div className="bg-slate-900/80 backdrop-blur-md px-3 py-1.5 border-l-2 border-emerald-500 shadow-2xl flex flex-col gap-0.5">
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Telemetry Live</span>
              </div>
              <div className="flex items-center gap-1 text-[9px] text-emerald-400 font-mono font-bold">
                <Clock size={8} />
                <span>SCAN: {lastUpdate}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FlashpointMarker({ flashpoint, getFlashpointIcon, onShowDetails }: { flashpoint: any, getFlashpointIcon: any, onShowDetails: (fp: any) => void }) {
  const lat = flashpoint.locationCoord?.lat || flashpoint.locationCoord?.latitude || flashpoint.lat;
  const lon = flashpoint.locationCoord?.lon || flashpoint.locationCoord?.longitude || flashpoint.lon;
  
  if (!lat || !lon) return null;
  
  return (
    <Marker 
      position={[lat, lon]} 
      icon={getFlashpointIcon(flashpoint.severity)}
    >
      <Popup className="custom-popup">
        <div className="w-64">
          <div className={`p-3 text-white ${flashpoint.severity === 'Extreme' ? 'bg-red-600' : 'bg-amber-500'}`}>
            <div className="flex items-center gap-2 mb-1">
              <Zap size={14} className="fill-current" />
              <span className="text-[10px] font-black uppercase tracking-widest">{flashpoint.severity} Emergency</span>
            </div>
            <h4 className="font-bold text-xs leading-tight uppercase">{flashpoint.event}</h4>
          </div>
          <div className="p-3 theme-bg-secondary space-y-2">
            <div>
              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-widest block mb-0.5">Affected Area</span>
              <p className="text-[10px] font-medium theme-text-primary leading-relaxed">{flashpoint.area || flashpoint.location || 'Specified Hazard Zone'}</p>
            </div>
            <div className="pt-2 border-t theme-border">
               <p className="text-[9px] theme-text-secondary leading-relaxed italic line-clamp-4">{flashpoint.description}</p>
            </div>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onShowDetails(flashpoint);
              }}
              className="w-full mt-2 py-2 bg-slate-900 dark:bg-indigo-600 text-white text-[9px] font-bold uppercase tracking-[0.2em] hover:opacity-90 transition-colors shadow-md"
            >
              Examine Full Intelligence
            </button>
            <div className="pt-2 flex justify-between items-center text-[8px] font-bold uppercase tracking-widest theme-text-muted">
              <span className="flex items-center gap-1"><Clock size={10} /> Expires: {new Date(flashpoint.expires).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
      </Popup>
    </Marker>
  );
}

function ForecastMarker({ stack, units, unitPreference, getRadarIcon }: { stack: any[], units: any, unitPreference: UnitPreference, getRadarIcon: any }) {
  const [index, setIndex] = useState(0);
  const f = stack[index];
  
  if (!f) return null;

  const lat = f.locationCoord?.lat || f.locationCoord?.latitude || f.lat;
  const lon = f.locationCoord?.lon || f.locationCoord?.longitude || f.lon;
  
  if (!lat || !lon) return null;

  const savedUnit = (f.unitSystem || 'imperial') as UnitPreference;
  const highTemp = convertValue(f.highTemp, savedUnit, unitPreference, 'temp');
  const lowTemp = convertValue(f.lowTemp, savedUnit, unitPreference, 'temp');
  
  let speedString = '';
  if (f.windSpeed !== undefined) {
     speedString = `${convertValue(f.windSpeed, savedUnit, unitPreference, 'speed')} ${units.speed}`;
  }

  return (
    <Marker 
      position={[lat, lon]} 
      icon={getRadarIcon(f.status)}
    >
      <Popup className="custom-popup">
        <div className="p-4 min-w-[220px] theme-bg-secondary">
          {stack.length > 1 && (
            <div className="flex items-center justify-between theme-bg-primary p-1 -mx-4 -mt-4 mb-3 border-b theme-border">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setIndex((index - 1 + stack.length) % stack.length);
                }}
                className="p-1 hover:theme-bg-secondary theme-text-muted transition-colors rounded"
              >
                <ChevronLeft size={12} />
              </button>
              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-[0.2em]">
                {index + 1} / {stack.length} Nodes
              </span>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setIndex((index + 1) % stack.length);
                }}
                className="p-1 hover:theme-bg-secondary theme-text-muted transition-colors rounded"
              >
                <ChevronRight size={12} />
              </button>
            </div>
          )}

          <div className="flex justify-between items-start pt-1 gap-4">
            <div className="min-w-0">
              <h4 className="font-bold text-xs uppercase tracking-tight theme-text-primary truncate">{f.location.split(',')[0]}</h4>
              <p className="text-[9px] theme-text-secondary uppercase tracking-widest flex items-center gap-1 mt-1">
                <Calendar size={10}/> {f.targetDate}
              </p>
            </div>
            {f.actualGrade ? (
               <div className="text-[10px] bg-emerald-500 text-white font-bold px-2 py-1 shadow-sm border border-emerald-600">{(f.actualGrade.score !== undefined && !isNaN(f.actualGrade.score)) ? f.actualGrade.score : 0}%</div>
            ) : f.modelGrade ? (
               <div className="text-[10px] theme-bg-primary theme-text-primary font-bold px-2 py-1 shadow-sm border theme-border">{(f.modelGrade.score !== undefined && !isNaN(f.modelGrade.score)) ? f.modelGrade.score : 0}%</div>
            ) : null}
          </div>
          
          <div className="grid grid-cols-2 gap-y-3 gap-x-2 border-t theme-border mt-3 pt-3">
            <div className="flex flex-col">
              <span className="text-[8px] theme-text-muted uppercase tracking-widest">High</span>
              <span className="text-xs font-bold text-red-500 flex items-center gap-1"><Thermometer size={10}/> {highTemp}{units.temp}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] theme-text-muted uppercase tracking-widest">Low</span>
              <span className="text-xs font-bold text-blue-500 flex items-center gap-1"><Thermometer size={10}/> {lowTemp}{units.temp}</span>
            </div>
            <div className="flex flex-col col-span-2">
              <span className="text-[8px] theme-text-muted uppercase tracking-widest">Condition</span>
              <span className="text-xs font-bold theme-text-primary flex items-center gap-1"><Cloud size={10}/> {f.predictedCondition}</span>
            </div>
          </div>
        </div>
      </Popup>
    </Marker>
  );
}

// Helper components are used within LayersControl

