import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Zap, ShieldAlert, Target, Send, ChevronRight } from 'lucide-react';
import { db } from '../lib/db';
import { collection, addDoc, serverTimestamp } from '../lib/db';
import { usePreferences, convertValue } from '../lib/preferences';

interface FlashForecastFormProps {
  alert: any;
  user: any;
  onClose: () => void;
}

export default function FlashForecastForm({ alert, user, onClose }: FlashForecastFormProps) {
  const { windUnit, units } = usePreferences();
  const [step, setStep] = useState(1);
  const [peakWind, setPeakWind] = useState(65);
  const [tornadoRisk, setTornadoRisk] = useState(0);
  const [maxHail, setMaxHail] = useState(0);
  const [upgradeProb, setUpgradeProb] = useState('likely');
  const [arrivalWindow, setArrivalWindow] = useState('Expected');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const payload: any = {
        userId: user.uid,
        location: alert.location || alert.area || 'Regional Flash Alert',
        targetDate: new Date().toISOString().split('T')[0],
        status: 'submitted',
        type: 'flash',
        flashData: {
          nwsAlertId: alert.nwsId,
          peakWind,
          tornadoRisk,
          maxHail,
          upgradeProb,
          arrivalWindow,
          event: alert.event,
          alertDescription: alert.description,
          alertInstruction: alert.instruction
        },
        // Populate standard fields so it doesn't break list views
        highTemp: 0,
        lowTemp: 0,
        predictedCondition: `Hazard Alert: ${alert.event}`,
        createdAt: serverTimestamp()
      };

      if (alert.locationCoord) {
        payload.locationCoord = alert.locationCoord;
      }

      await addDoc(collection(db, 'forecasts'), payload);
      onClose();
    } catch (err) {
      console.error("Flash Forecast Submission Failed", err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md theme-bg-secondary border border-red-600 shadow-[20px_20px_0px_#dc2626] overflow-hidden"
      >
        <div className="bg-red-600 p-4 flex justify-between items-center">
          <div className="flex items-center gap-2 text-white">
            <Zap size={16} />
            <span className="text-[11px] font-black uppercase tracking-widest">Urgent Requirement: Forecast</span>
          </div>
          <button onClick={onClose} className="text-white opacity-50 hover:opacity-100"><X size={20} /></button>
        </div>

        <div className="p-8 space-y-8">
           <div className="border-b theme-border pb-4">
              <span className="text-[9px] font-bold text-red-500 uppercase tracking-widest">High Priority Alert</span>
              <h3 className="text-xl font-bold uppercase tracking-tighter mt-1 theme-text-primary">{alert.event}</h3>
              <p className="text-[10px] theme-text-muted uppercase font-bold tracking-widest mt-1 italic">{alert.location}</p>
           </div>

           {step === 1 && (
             <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                <div className="space-y-4">
                   <label className="text-[10px] font-bold theme-text-muted uppercase tracking-widest flex justify-between">
                     Analysis Prediction: Peak Wind Gust
                     <span className="text-red-600 font-black">{convertValue(peakWind, 'imperial', windUnit, 'speed')} {units.speed}</span>
                   </label>
                   <input 
                     type="range" 
                     min="40" 
                     max="150" 
                     step="5"
                     value={peakWind}
                     onChange={(e) => setPeakWind(Number(e.target.value))}
                     className="w-full accent-red-600 h-1.5 theme-bg-input rounded-full cursor-pointer"
                   />
                   <div className="flex justify-between text-[8px] font-black text-slate-300 uppercase">
                      <span>Severe (40)</span>
                      <span>Hurricane (74)</span>
                      <span>Extreme (150+)</span>
                   </div>
                </div>

                <div className="space-y-4">
                   <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex justify-between">
                     Tornado Probability
                     <span className="text-indigo-600 font-black">{tornadoRisk}%</span>
                   </label>
                   <input 
                     type="range" 
                     min="0" 
                     max="100" 
                     step="5"
                     value={tornadoRisk}
                     onChange={(e) => setTornadoRisk(Number(e.target.value))}
                     className="w-full accent-indigo-600 h-1.5 bg-slate-100 rounded-full cursor-pointer"
                   />
                </div>

                <div className="space-y-4">
                    <label className="text-[10px] font-bold theme-text-muted uppercase tracking-widest flex justify-between">
                     Max Hail Size (Inches)
                     <span className="theme-text-primary font-black">{maxHail}''</span>
                   </label>
                   <input 
                     type="range" 
                     min="0" 
                     max="4.5" 
                     step="0.25"
                     value={maxHail}
                     onChange={(e) => setMaxHail(Number(e.target.value))}
                     className="w-full accent-slate-900 h-1.5 theme-bg-input rounded-full cursor-pointer"
                   />
                   <div className="flex justify-between text-[8px] font-black text-slate-300 uppercase">
                      <span>None</span>
                      <span>Quarter (1.0)</span>
                      <span>Baseball (2.75)</span>
                   </div>
                </div>

                <div className="space-y-3">
                   <label className="text-[10px] font-bold theme-text-muted uppercase tracking-widest">Threat Escalation Probability</label>
                   <div className="grid grid-cols-3 gap-2">
                      {['Unlikely', 'Likely', 'Observed'].map((p) => (
                        <button 
                          key={p}
                          onClick={() => setUpgradeProb(p.toLowerCase())}
                          className={`py-3 text-[10px] font-bold uppercase tracking-widest border transition-all ${upgradeProb === p.toLowerCase() ? 'theme-bg-primary theme-text-primary border-indigo-600 shadow-md' : 'theme-bg-secondary theme-text-muted theme-border hover:theme-bg-primary'}`}
                        >
                          {p}
                        </button>
                      ))}
                   </div>
                </div>

                <button 
                  onClick={() => setStep(2)}
                  className="w-full bg-slate-900 border theme-border dark:bg-indigo-600 text-white py-4 font-black uppercase tracking-[0.2em] text-[11px] flex justify-center items-center gap-2"
                >
                  Confirm Level 1 <ChevronRight size={14} />
                </button>
             </div>
           )}

           {step === 2 && (
             <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="space-y-3">
                   <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Forecast Window: Peak Impact</label>
                   <div className="grid grid-cols-2 gap-2">
                      {['Immediate', 'Standard Window'].map((w) => (
                        <button 
                          key={w}
                          onClick={() => setArrivalWindow(w)}
                          className={`py-4 px-2 text-[9px] font-bold uppercase tracking-[0.1em] border leading-tight text-center ${arrivalWindow === w ? 'bg-red-600 text-white border-red-600 shadow-lg' : 'bg-slate-50 text-slate-400 border-slate-100'}`}
                        >
                          {w}
                        </button>
                      ))}
                   </div>
                </div>

                <div className="bg-slate-50 p-4 border-l-4 border-red-600 space-y-2">
                   <p className="text-[9px] font-black text-slate-900 uppercase">Forecast Summary</p>
                   <p className="text-[10px] text-slate-500 leading-relaxed italic">
                     Submitting predictive analysis for {alert.event}. Failure to respond with 90%+ accuracy will result in negative PI feedback.
                   </p>
                </div>

                <div className="flex gap-2">
                  <button 
                    onClick={() => setStep(1)}
                    className="bg-slate-100 text-slate-500 px-6 py-4 font-black uppercase tracking-widest text-[10px]"
                  >
                    Back
                  </button>
                  <button 
                    onClick={handleSubmit}
                    disabled={submitting}
                    className="flex-1 bg-red-600 text-white py-4 font-black uppercase tracking-[0.2em] text-[11px] flex justify-center items-center gap-2 hover:bg-red-700 disabled:opacity-50"
                  >
                    {submitting ? 'Transmitting...' : 'Submit Review'} <Target size={14} />
                  </button>
                </div>
             </div>
           )}
        </div>
      </motion.div>
    </div>
  );
}
