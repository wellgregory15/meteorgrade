import React, { useState, useEffect } from 'react';
import { auth, db } from '../lib/db';
import { doc, getDoc, updateDoc } from '../lib/db';
import { 
  BarChart2, 
  Trophy, 
  Calendar, 
  MessageSquare, 
  History, 
  LogOut,
  LayoutDashboard,
  Smartphone,
  Globe,
  Edit2,
  Check,
  X,
  LifeBuoy,
  Shield,
  Settings,
  Zap,
  Book,
  Target
} from 'lucide-react';
import { motion } from 'motion/react';
import { usePreferences } from '../lib/preferences';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  onLogout: () => void;
  profile: any;
}

export default function Sidebar({ activeView, setActiveView, onLogout, profile }: SidebarProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const { unitPreference, setUnitPreference } = usePreferences();
  
  const handle = profile?.displayName ? profile.displayName.split(' ')[0].toLowerCase() : (auth.currentUser?.displayName ? auth.currentUser.displayName.split(' ')[0].toLowerCase() : 'agent');
  const avatarUrl = profile?.avatarUrl;

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setDeferredPrompt(null);
  };

  const menuItems = [
    { id: 'dashboard', label: 'Meteorological Monitor', icon: LayoutDashboard },
    { id: 'radar', label: 'Global Radar Feed', icon: Globe },
    { id: 'analytics', label: 'Precision Analysis', icon: BarChart2 },
    { id: 'leaderboard', label: 'Analyst Rankings', icon: Trophy },
    { id: 'syndicates', label: 'Syndicate Network', icon: Shield },
    { id: 'missions', label: 'Active Campaigns', icon: Calendar },
    { id: 'subscription', label: 'AI Intelligence Tier', icon: Zap },
    { id: 'debrief', label: 'Neural Debrief', icon: MessageSquare },
    { id: 'settings', label: 'Terminal Settings', icon: Settings },
    { id: 'support', label: 'Safety Support', icon: LifeBuoy },
    { id: 'credits', label: 'Bureau Protocol', icon: Book },
  ];

  const isAdmin = auth.currentUser?.email?.toLowerCase() === 'tylerleedixon@gmail.com';
  if (isAdmin) {
    menuItems.push({ id: 'admin', label: 'Admin Panel', icon: Shield });
  }

  return (
    <aside className="w-64 border-r theme-border flex flex-col h-full theme-bg-sidebar p-6 sticky top-0 overflow-y-auto z-50">
      <div className="flex flex-col mb-8">
        <span className="text-[9px] font-bold tracking-[0.25em] uppercase text-indigo-600 mb-1">Atmospheric Data</span>
        <h1 className="text-xl font-light tracking-tighter cursor-pointer theme-text-primary" onClick={() => setActiveView('dashboard')}>
          METEOR<span className="font-bold text-indigo-600 dark:text-blue-400">GRADE</span>
        </h1>
        
        <div className="mt-6 pt-6 border-t theme-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 theme-bg-app border theme-border flex items-center justify-center theme-text-primary text-xs font-bold overflow-hidden shadow-sm">
               {avatarUrl || auth.currentUser?.photoURL ? (
                 <img src={avatarUrl || auth.currentUser?.photoURL || ''} alt="Avatar" className="w-full h-full object-cover" />
               ) : (
                 handle[0]?.toUpperCase() || 'U'
               )}
            </div>
            <div className="flex flex-col flex-1 min-w-0">
               <span className="text-[9px] font-bold uppercase tracking-widest theme-text-muted">Analyst Alias</span>
               <span className="text-xs font-mono text-indigo-600 dark:text-indigo-400 font-bold truncate">@{handle}</span>
            </div>
            <button 
              onClick={() => {
                setActiveView('settings');
              }}
              className="p-1.5 theme-text-muted hover:text-indigo-600 dark:hover:text-indigo-400 hover:theme-bg-primary transition-all border border-transparent hover:theme-border rounded"
              title="Analyst Settings"
            >
              <Settings size={14} />
            </button>
          </div>
        </div>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              console.log(`[Sidebar] Navigation intent: ${item.id}`);
              setActiveView(item.id);
            }}
            className={`w-full flex items-center gap-4 px-4 py-3 text-[10px] font-bold uppercase tracking-[0.15em] transition-all group relative ${
              activeView === item.id ? 'text-indigo-600 dark:text-indigo-400' : 'theme-text-secondary hover:theme-text-primary'
            }`}
          >
            {activeView === item.id && (
              <motion.div 
                layoutId="nav-pill"
                className="absolute inset-0 theme-bg-secondary border-r-2 border-indigo-600"
              />
            )}
            <item.icon size={18} className="relative z-10" />
            <span className="relative z-10">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="pt-8 border-t theme-border mt-auto space-y-4">
        {profile?.membership !== 'pro' && (
          <button 
            onClick={() => setActiveView('subscription')}
            className="w-full bg-gradient-to-r from-indigo-600 to-indigo-800 p-4 shadow-[4px_4px_0px_#1e1b4b] hover:translate-y-[-2px] hover:translate-x-[-2px] hover:shadow-[6px_6px_0px_#1e1b4b] transition-all flex flex-col items-start gap-1 group"
          >
            <div className="flex items-center gap-2">
              <Zap size={14} className="text-white fill-white animate-pulse" />
              <span className="text-white text-[11px] font-black uppercase tracking-widest">Upgrade to Pro</span>
            </div>
            <span className="text-[9px] text-indigo-100 font-bold uppercase tracking-tighter opacity-80 group-hover:opacity-100">Unlock AI Synthesis</span>
          </button>
        )}
        {/* Settings Toggle */}
        <div className="px-4 py-3 flex items-center justify-between border theme-border theme-bg-secondary">
          <div className="flex items-center gap-3 theme-text-primary">
            <Globe size={14} className="text-indigo-600 dark:text-indigo-400" />
            <span className="text-[9px] font-bold uppercase tracking-widest theme-text-muted">Units</span>
          </div>
          <div className="flex theme-bg-app border theme-border">
            <button 
              onClick={() => setUnitPreference('imperial')}
              className={`px-2 py-1 text-[8px] font-bold uppercase tracking-widest transition-all ${unitPreference === 'imperial' ? 'bg-indigo-600 text-white shadow-md' : 'theme-text-muted hover:theme-text-secondary'}`}
            >
              Imperial
            </button>
            <button 
              onClick={() => setUnitPreference('metric')}
              className={`px-2 py-1 text-[8px] font-bold uppercase tracking-widest transition-all ${unitPreference === 'metric' ? 'bg-indigo-600 text-white shadow-md' : 'theme-text-muted hover:theme-text-secondary'}`}
            >
              Metric
            </button>
          </div>
        </div>

        {deferredPrompt && (
          <button 
            onClick={handleInstall}
            className="w-full flex items-center gap-4 px-4 py-3 text-[11px] font-bold uppercase tracking-[0.1em] text-indigo-600 dark:text-indigo-400 theme-bg-input border theme-border transition-all hover:bg-indigo-600 hover:text-white"
          >
            <Smartphone size={18} />
            <span>Install App</span>
          </button>
        )}
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-4 px-4 py-3 text-[11px] font-bold uppercase tracking-[0.1em] theme-text-muted hover:text-red-500 transition-all font-black"
        >
          <LogOut size={18} />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}