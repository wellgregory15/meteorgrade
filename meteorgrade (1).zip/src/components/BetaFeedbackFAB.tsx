import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bug, X, Send, MessageSquare, AlertCircle, CheckCircle } from 'lucide-react';
import { db } from '../lib/db';
import { collection, addDoc, serverTimestamp, User } from '../lib/db';

interface BetaFeedbackFABProps {
  user: User;
}

export default function BetaFeedbackFAB({ user }: BetaFeedbackFABProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [type, setType] = useState<'bug' | 'suggestion' | 'praise'>('bug');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    setIsSubmitting(true);
    setStatus('idle');

    try {
      await addDoc(collection(db, 'betaFeedback'), {
        userId: user.uid,
        userEmail: user.email,
        type,
        description: description.trim(),
        path: window.location.pathname + window.location.hash,
        userAgent: navigator.userAgent,
        timestamp: serverTimestamp(),
        status: 'new'
      });
      
      setStatus('success');
      setDescription('');
      setTimeout(() => {
        setIsOpen(false);
        setStatus('idle');
      }, 2000);
    } catch (error) {
      console.error('Beta feedback submission failed:', error);
      setStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      {/* FAB Button */}
      <div className="fixed bottom-6 right-6 z-[150]">
        {!isOpen && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsOpen(true)}
            className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-3 rounded-full shadow-lg hover:bg-indigo-700 transition-colors group"
          >
            <Bug size={18} className="group-hover:rotate-12 transition-transform" />
            <span className="text-[11px] font-bold uppercase tracking-widest hidden sm:inline">Beta Feedback</span>
          </motion.button>
        )}
      </div>

      {/* Modal / Popover */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[200] flex items-end sm:items-center justify-center p-4 sm:p-6 bg-slate-950/20 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-slate-900 w-full max-w-4xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800"
            >
              <div className="p-4 sm:p-6 bg-slate-900 flex items-center justify-between text-white">
                <div className="flex items-center gap-3">
                  <Bug size={20} className="text-indigo-400" />
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-[0.2em]">Beta Support</h3>
                    <p className="text-[9px] text-slate-400 font-mono">CHANNEL_ID: FEEDBACK_TERMINAL</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-full transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-6">
                {status === 'success' ? (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="py-12 flex flex-col items-center justify-center text-center space-y-4"
                  >
                    <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-500/10 rounded-full flex items-center justify-center text-emerald-500">
                      <CheckCircle size={32} />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold uppercase tracking-widest text-slate-900 dark:text-white">Transmission Received</h4>
                      <p className="text-xs text-slate-500 mt-1">Thank you for your contribution to the program.</p>
                    </div>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                      {(['bug', 'suggestion', 'praise'] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setType(t)}
                          className={`flex-1 py-2 text-[10px] font-bold uppercase tracking-widest transition-all ${
                            type === t 
                              ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm rounded-md' 
                              : 'text-slate-500 hover:text-slate-900'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Diagnostic Details</label>
                        <span className="text-[8px] font-mono text-slate-300">LEN: {description.length}/2000</span>
                      </div>
                      <textarea
                        autoFocus
                        value={description}
                        onChange={(e) => setDescription(e.target.value.slice(0, 2000))}
                        onInput={(e) => {
                          const target = e.target as HTMLTextAreaElement;
                          target.style.height = 'auto';
                          target.style.height = target.scrollHeight + 'px';
                        }}
                        placeholder={
                          type === 'bug' ? "What failed in the terminal?" :
                          type === 'suggestion' ? "What improvement do you propose?" :
                          "What worked exceptionally well?"
                        }
                        className="w-full min-h-[250px] h-auto bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 p-4 text-sm focus:border-indigo-500 dark:focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500 outline-none transition-all resize-none dark:text-slate-200 overflow-hidden"
                      />
                    </div>

                    {status === 'error' && (
                      <div className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-[10px] uppercase font-bold flex items-center gap-2 border border-red-100 dark:border-red-500/20">
                        <AlertCircle size={14} />
                        Transmission Error: Failed to relay data
                      </div>
                    )}

                    <div className="flex gap-3">
                      <button
                        type="button"
                        onClick={() => setIsOpen(false)}
                        className="flex-1 py-3 px-4 text-[10px] font-bold uppercase tracking-widest text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={!description.trim() || isSubmitting}
                        className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 font-bold uppercase tracking-widest text-[10px] transition-all ${
                          !description.trim() || isSubmitting 
                            ? 'bg-slate-100 text-slate-300 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed' 
                            : 'bg-slate-900 dark:bg-indigo-600 text-white hover:bg-indigo-600 dark:hover:bg-indigo-500'
                        }`}
                      >
                        {isSubmitting ? 'Relaying...' : 'Relay Data'}
                        {!isSubmitting && <Send size={14} />}
                      </button>
                    </div>
                  </form>
                )}
                
                <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex items-center justify-center gap-4 text-slate-400">
                  <div className="flex items-center gap-1.5 grayscale opacity-50">
                    <MessageSquare size={12} />
                    <span className="text-[9px] font-mono">BETA_V1.2</span>
                  </div>
                  <div className="w-1 h-1 bg-slate-200 dark:bg-slate-800 rounded-full" />
                  <span className="text-[9px] font-mono opacity-50">{user.email}</span>
                  <div className="w-1 h-1 bg-slate-200 dark:bg-slate-800 rounded-full" />
                  <span className="text-[8px] font-mono text-slate-300">LEN: {description.length}/2000</span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
