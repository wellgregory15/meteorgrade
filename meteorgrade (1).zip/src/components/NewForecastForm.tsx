import React, { useState, useEffect, useRef } from 'react';
import { db } from '../lib/db';
import { collection, addDoc, serverTimestamp, updateDoc, GeoPoint, query, where, getDocs } from '../lib/db';
import { User } from '../lib/db';
import { X, Search, MapPin, Calendar, Thermometer, Cloud, Send, Loader2, Droplets, Wind, Sun, Zap, Target } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getAIGrade } from '../services/geminiService';
import { usePreferences } from '../lib/preferences';
import { resolveSector } from '../lib/meteorologicalSectors';

interface NewForecastFormProps {
  onClose: () => void;
  user: User;
  profile?: any;
}

export default function NewForecastForm({ onClose, user, profile }: NewForecastFormProps) {
  const { unitPreference, windUnit, units } = usePreferences();
  
  const [location, setLocation] = useState('');
  const [lat, setLat] = useState<number | null>(null);
  const [lon, setLon] = useState<number | null>(null);
  const [date, setDate] = useState('');
  const [highTemp, setHighTemp] = useState('');
  const [lowTemp, setLowTemp] = useState('');
  const [condition, setCondition] = useState('Sunny');
  const [reasoning, setReasoning] = useState('');
  const [humidity, setHumidity] = useState('');
  const [windSpeed, setWindSpeed] = useState('');
  const [windGusts, setWindGusts] = useState('');
  const [uvIndex, setUvIndex] = useState('');
  const [precip, setPrecip] = useState('');
  const [pressure, setPressure] = useState('');
  const [cape, setCape] = useState('');
  const [shear, setShear] = useState('');
  
  // Mode Control
  const [forecastMode, setForecastMode] = useState<'standard' | 'tactical'>('standard');
  const [confidence, setConfidence] = useState(70); // 0-100%
  
  // Advanced Risk Profile (Acme Style)
  const [riskMin, setRiskMin] = useState('');
  const [riskMax, setRiskMax] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState<'idle' | 'grading'>('idle');
  const [errorStatus, setErrorStatus] = useState<string | null>(null);
  
  // Syndicate Missions
  const [syndicateMissions, setSyndicateMissions] = useState<any[]>([]);
  const [selectedMissionId, setSelectedMissionId] = useState<string>('');

  useEffect(() => {
    if (profile?.syndicateId) {
      const q = query(
        collection(db, 'missions'),
        where('syndicateId', '==', profile.syndicateId),
        where('status', '==', 'active')
      );
      getDocs(q).then(snap => {
        setSyndicateMissions(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      });
    }
  }, [profile?.syndicateId]);

  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchLocations = async () => {
      if (location.length < 3) {
        setSuggestions([]);
        return;
      }
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}&limit=5`);
        const data = await res.json();
        setSuggestions(data);
        setShowSuggestions(true);
      } catch (err) {
        console.error("Location search failed", err);
      }
    };

    const timer = setTimeout(fetchLocations, 500);
    return () => clearTimeout(timer);
  }, [location]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (inputRef.current && !inputRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!location || !date || !highTemp || !lowTemp) return;

    setErrorStatus(null);
    const now = new Date();
    const targetDateObj = new Date(date);
    // Assume 12:00 PM as the peak of the forecast day for lead-time calculation
    const peakTime = new Date(targetDateObj.getTime() + (12 * 60 * 60 * 1000));

    if (peakTime.getTime() < now.getTime() + (6 * 60 * 60 * 1000)) {
      setErrorStatus("TEMPORAL VIOLATION: Scientific Bureau protocol requires a minimum 6-hour lead time prior to the atmospheric peak. Analysis for this window is already locked.");
      return;
    }

    setIsSubmitting(true);
    setStatus('grading');

    // Normalize wind inputs to base unitSystem if user is using knots for display
    let finalWindSpeed = windSpeed ? Number(windSpeed) : undefined;
    let finalWindGusts = windGusts ? Number(windGusts) : undefined;

    if (windUnit === 'knots' && (finalWindSpeed !== undefined || finalWindGusts !== undefined)) {
      // User entered in knots, but we want to store in the base unitSystem (mph for imperial, kmh for metric)
      // Since conversion is linear: value_in_base = value_in_knots / conversion_factor
      const knotsToMph = 0.868976;
      if (unitPreference === 'imperial') {
        if (finalWindSpeed !== undefined) finalWindSpeed = Math.round(finalWindSpeed / knotsToMph);
        if (finalWindGusts !== undefined) finalWindGusts = Math.round(finalWindGusts / knotsToMph);
      } else {
        // knots to kmh: knots * 1.852
        if (finalWindSpeed !== undefined) finalWindSpeed = Math.round(finalWindSpeed * 1.852);
        if (finalWindGusts !== undefined) finalWindGusts = Math.round(finalWindGusts * 1.852);
      }
    }

    // Calculate Lock-In Bonus (2.5 points per day lead time, capped at 15)
    let lockInBonus = 0;
    if (date) {
      const targetDate = new Date(date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const diffTime = targetDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if (diffDays > 0) {
        lockInBonus = Math.min(15, diffDays * 2.5);
      }
    }

    const { resolveSector } = await import('../lib/meteorologicalSectors');
    const sector = resolveSector(lat, lon);

    // Calculate risk bounds automatically if in tactical mode and not manually overridden
    let finalRiskMin = riskMin;
    let finalRiskMax = riskMax;

    if (forecastMode === 'tactical' && !riskMin && !riskMax && highTemp) {
      // spread = 6 - (confidence/20) ... so 100% confidence = 1 degree, 0% confidence = 6 degrees
      const spread = Math.max(1, 6 - (confidence / 20));
      finalRiskMin = (Number(highTemp) - spread).toString();
      finalRiskMax = (Number(highTemp) + spread).toString();
    }

    // Construct base payload
    const payload: any = {
      user_id: user.uid,
      location,
      lat,
      lon,
      target_date: date,
      unit_system: unitPreference,
      high_temp: Number(highTemp),
      low_temp: Number(lowTemp),
      predicted_condition: condition,
      status: 'submitted',
      lock_in_bonus: lockInBonus,
      sector_id: sector.id,
      difficulty_multiplier: sector.multiplier,
      forecast_mode: forecastMode,
      logic_notes: reasoning,
      syndicate_id: profile?.syndicateId || null,
      mission_id: selectedMissionId || null,
      is_probabilistic: forecastMode === 'tactical',
      risk_profile: forecastMode === 'tactical' ? {
        min: Number(finalRiskMin),
        max: Number(finalRiskMax),
        expected: Number(highTemp),
        confidence
      } : null,
      created_at: serverTimestamp(),
    };

    if (lat !== null && lon !== null) {
      payload.location_coord = new GeoPoint(lat, lon);
    }

    // Only add optional fields if they have values to avoid database 'undefined' errors
    if (humidity) payload.humidity = Number(humidity);
    if (finalWindSpeed !== undefined) payload.wind_speed = finalWindSpeed;
    if (finalWindGusts !== undefined) payload.wind_gusts = finalWindGusts;
    if (uvIndex) payload.uv_index = Number(uvIndex);
    if (precip) payload.precip = Number(precip);
    if (pressure) payload.pressure = Number(pressure);
    if (cape) payload.cape = Number(cape);
    if (shear) payload.shear = Number(shear);

    const extraFields = {
      ...(humidity && { humidity: Number(humidity) }),
      ...(finalWindSpeed !== undefined && { windSpeed: finalWindSpeed }),
      ...(finalWindGusts !== undefined && { windGusts: finalWindGusts }),
      ...(uvIndex && { uvIndex: Number(uvIndex) }),
      ...(precip && { precip: Number(precip) }),
      ...(pressure && { pressure: Number(pressure) }),
      ...(cape && { cape: Number(cape) }),
      ...(shear && { shear: Number(shear) })
    };

    try {
      // 1. Save to Database FIRST (Status: Pending)
      const forecastRef = await addDoc(collection(db, 'forecasts'), {
        ...payload,
        status: 'pending'
      });
      
      // We have successfully saved the data. 
      // Now we attempt grading, but if it fails, we don't crash the save.
      try {
        const grade = await getAIGrade({
          location,
          date,
          highTemp: Number(highTemp),
          lowTemp: Number(lowTemp),
          condition,
          reasoning,
          extraFields
        });
        
        await updateDoc(forecastRef, {
          status: 'model_graded',
          modelGrade: {
            ...grade,
            gradedAt: new Date().toISOString()
          }
        });
      } catch (gradeError: any) {
        console.warn("AI Analysis skipped/failed during submission:", gradeError.message);
        // We could optionally show a toast here in the future: "Saved! Analysis Pending."
      }

      onClose();
    } catch (error: any) {
      console.error("Critical submission failure:", error);
      setErrorStatus(error?.message || "Failed to connect to database. Please check your connection.");
    } finally {
      setIsSubmitting(false);
      setStatus('idle');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="theme-bg-secondary border theme-border w-full max-w-2xl overflow-hidden shadow-2xl rounded-sm"
      >
        <div className="flex justify-between items-center p-4 md:p-6 theme-bg-primary border-b theme-border">
          <div className="flex flex-col">
            <span className="text-[9px] font-bold tracking-[0.2em] uppercase text-indigo-600">Entry Module</span>
            <h3 className="text-lg md:text-xl font-light tracking-tight text-slate-900 mt-1 uppercase">New Forecast</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-900 transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-6 md:space-y-8 max-h-[80vh] overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
            {/* Mode Selection */}
            <div className="md:col-span-2 space-y-6">
              <div className="flex gap-1 p-1 theme-bg-primary border theme-border rounded-sm">
                <button
                  type="button"
                  onClick={() => setForecastMode('standard')}
                  className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${forecastMode === 'standard' ? 'bg-indigo-600 text-white shadow-lg' : 'theme-text-muted hover:theme-text-primary'}`}
                >
                  Standard Mode
                </button>
                <button
                  type="button"
                  onClick={() => setForecastMode('tactical')}
                  className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${forecastMode === 'tactical' ? 'bg-indigo-600 text-white shadow-lg' : 'theme-text-muted hover:theme-text-primary'}`}
                >
                  Tactical Mode
                </button>
              </div>

              {syndicateMissions.length > 0 && (
                <div className="space-y-2 p-4 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-200 dark:border-indigo-800">
                  <div className="flex items-center gap-2 mb-1">
                    <Target size={14} className="text-indigo-600" />
                    <label className="text-[10px] uppercase font-black text-indigo-600 tracking-widest">Assign to Active Operation</label>
                  </div>
                  <select 
                    value={selectedMissionId}
                    onChange={(e) => setSelectedMissionId(e.target.value)}
                    className="w-full theme-bg-primary border-b-2 border-indigo-600 py-2 text-xs font-bold uppercase tracking-wider focus:outline-none"
                  >
                    <option value="">-- NO SPECIFIC DEPLOYMENT --</option>
                    {syndicateMissions.map(m => (
                      <option key={m.id} value={m.id}>{m.title}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Location with Suggestions */}
            <div className="space-y-1 relative" ref={inputRef}>
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Target Location</label>
              <div className="relative">
                <input 
                  required
                  type="text" 
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Street, City, or Region"
                  className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal pr-8"
                  autoComplete="off"
                />
                <Search size={14} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-300" />
              </div>
              <AnimatePresence>
                {showSuggestions && suggestions.length > 0 && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute z-10 w-full theme-bg-secondary border theme-border theme-shadow mt-1 overflow-hidden"
                  >
                    {suggestions.map((item, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          setLocation(item.display_name);
                          setLat(parseFloat(item.lat));
                          setLon(parseFloat(item.lon));
                          setShowSuggestions(false);
                        }}
                        className="w-full text-left p-3 text-[11px] theme-text-primary hover:theme-bg-primary border-b theme-border last:border-0 transition-colors flex items-start gap-2"
                      >
                        <MapPin size={12} className="mt-0.5 text-indigo-400 shrink-0" />
                        <span className="truncate">{item.display_name}</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Sector Preview */}
              {lat !== null && lon !== null && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-2 flex items-center gap-2"
                >
                  {(() => {
                    const sector = resolveSector(lat, lon);
                    return (
                      <>
                        <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 border ${sector.color} theme-bg-primary theme-border`}>
                          {sector.name}
                        </span>
                        {sector.multiplier > 1 && (
                          <span className="text-[8px] font-bold text-indigo-400 uppercase">
                            {sector.multiplier}x Multiplier Active
                          </span>
                        )}
                      </>
                    );
                  })()}
                </motion.div>
              )}
            </div>

            {/* Date */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex justify-between items-center">
                <span>Forecast Date</span>
                {date && (
                  <span className="text-emerald-500 font-mono tracking-normal normal-case animate-pulse">
                    +{Math.min(15, Math.ceil((new Date(date).getTime() - new Date().setHours(0,0,0,0)) / (1000 * 60 * 60 * 24)) * 2.5).toFixed(1)} Lock-In Bonus
                  </span>
                )}
              </label>
              <input 
                required
                type="date" 
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors"
                min={new Date().toISOString().split('T')[0]}
              />
            </div>

            {/* Temp High */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Thermometer size={10} className="text-red-400" /> High Temp Prediction ({units.temp})
              </label>
              <input 
                required
                type="number" 
                value={highTemp}
                onChange={(e) => setHighTemp(e.target.value)}
                placeholder={unitPreference === 'imperial' ? '85' : '29'}
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Temp Low */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Thermometer size={10} className="text-blue-400" /> Low Temp Prediction ({units.temp})
              </label>
              <input 
                required
                type="number" 
                value={lowTemp}
                onChange={(e) => setLowTemp(e.target.value)}
                placeholder={unitPreference === 'imperial' ? '65' : '18'}
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Condition */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Cloud size={10} /> Conditions
              </label>
              <select 
                value={condition}
                onChange={(e) => setCondition(e.target.value)}
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors appearance-none bg-transparent"
              >
                {['Sunny', 'Partly Cloudy', 'Cloudy', 'Rainy', 'Snowy', 'Thunderstorm', 'Severe Thunderstorm', 'Supercell', 'Tornado', 'Windy', 'Foggy'].map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Extra Fields Section Header */}
            <div className="md:col-span-2 pt-4">
              <div className="flex items-center gap-4">
                <span className="text-[9px] font-bold text-indigo-600 uppercase tracking-widest whitespace-nowrap">Accuracy Enhancers</span>
                <div className="h-[1px] w-full theme-bg-primary"></div>
              </div>
            </div>

            {/* Humidity */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Droplets size={10} /> Humidity (%)
              </label>
              <input 
                type="number" 
                value={humidity}
                onChange={(e) => setHumidity(e.target.value)}
                placeholder="0-100"
                min="0"
                max="100"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Wind Speed */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Wind size={10} /> Sustained Wind ({units.speed})
              </label>
              <input 
                type="number" 
                value={windSpeed}
                onChange={(e) => setWindSpeed(e.target.value)}
                placeholder="Optional"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Wind Gusts */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Wind size={10} className="text-amber-400" /> Wind Gusts ({units.speed})
              </label>
              <input 
                type="number" 
                value={windGusts}
                onChange={(e) => setWindGusts(e.target.value)}
                placeholder="Optional"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* UV Index */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Sun size={10} /> UV Index
              </label>
              <input 
                type="number" 
                value={uvIndex}
                onChange={(e) => setUvIndex(e.target.value)}
                placeholder="0-11+"
                min="0"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Precipitation */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Cloud size={10} className="text-blue-400" /> Precip Vol ({units.precip})
              </label>
              <input 
                type="number" 
                step="0.01"
                value={precip}
                onChange={(e) => setPrecip(e.target.value)}
                placeholder="Optional"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Pressure */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Cloud size={10} className="text-slate-400" /> Pressure ({units.pressure})
              </label>
              <input 
                type="number" 
                step="0.01"
                value={pressure}
                onChange={(e) => setPressure(e.target.value)}
                placeholder="1013"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* CAPE */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Zap size={10} className="text-orange-500" /> CAPE (J/kg)
              </label>
              <input 
                type="number" 
                value={cape}
                onChange={(e) => setCape(e.target.value)}
                placeholder="Convective Potential"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Wind Shear */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Wind size={10} className="text-red-500" /> Wind Shear (kt)
              </label>
              <input 
                type="number" 
                value={shear}
                onChange={(e) => setShear(e.target.value)}
                placeholder="Vertical Shear"
                className="w-full border-b border-slate-200 py-2 font-medium focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 placeholder:font-normal"
              />
            </div>

            {/* Reasoning */}
            <div className="md:col-span-2 space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Meteorological Logic (AI Analysis Context)</label>
              <textarea 
                value={reasoning}
                onChange={(e) => setReasoning(e.target.value)}
                placeholder="Explain the setup: 'High pressure ridge building from west...' or 'Frontal boundary interacting with moisture...'"
                rows={3}
                className="w-full border border-slate-100 p-3 text-xs focus:outline-none focus:border-indigo-600 transition-colors placeholder:text-slate-300 rounded-sm theme-bg-input theme-text-primary"
              />
            </div>

            {/* Advanced Risk Profile (Tactical Only) */}
            <AnimatePresence>
              {forecastMode === 'tactical' && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="md:col-span-2 overflow-hidden"
                >
                  <div className="p-6 border border-indigo-500/30 bg-indigo-500/5 space-y-8">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 flex items-center justify-center rounded-sm bg-indigo-600 text-white">
                          <Zap size={18} className="fill-current" />
                        </div>
                        <div>
                          <h4 className="text-[10px] font-bold uppercase tracking-widest theme-text-primary">Tactical Risk Assessment</h4>
                          <p className="text-[9px] theme-text-muted uppercase tracking-wider mt-0.5">Adjust confidence to define your probability curve.</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-mono font-black text-indigo-600">{confidence}%</span>
                        <p className="text-[8px] font-bold text-indigo-400 uppercase tracking-tighter">Confidence Index</p>
                      </div>
                    </div>

                    {/* Confidence Slider */}
                    <div className="space-y-4">
                      <input 
                        type="range"
                        min="0"
                        max="100"
                        value={confidence}
                        onChange={(e) => setConfidence(parseInt(e.target.value))}
                        className="w-full h-1 bg-indigo-200 dark:bg-indigo-900 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                      />
                      <div className="flex justify-between text-[8px] font-bold text-indigo-400 uppercase tracking-widest">
                        <span>High Uncertainty (±6°)</span>
                        <span>Absolute Certainty (±1°)</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-8 pt-6 border-t border-indigo-500/20">
                      <div className="space-y-1">
                        <label className="text-[9px] uppercase font-bold text-indigo-400 tracking-widest">Optional: 10th Percentile</label>
                        <input 
                          type="number"
                          value={riskMin}
                          onChange={(e) => setRiskMin(e.target.value)}
                          placeholder="Manual Overload"
                          className="w-full bg-transparent border-b border-indigo-500/30 py-2 text-xs font-bold focus:outline-none focus:border-indigo-500 text-indigo-600"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] uppercase font-bold text-red-400 tracking-widest">Optional: 90th Percentile</label>
                        <input 
                          type="number"
                          value={riskMax}
                          onChange={(e) => setRiskMax(e.target.value)}
                          placeholder="Manual Overload"
                          className="w-full bg-transparent border-b border-red-500/30 py-2 text-xs font-bold focus:outline-none focus:border-red-500 text-red-600"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>


          <button 
            disabled={isSubmitting}
            className="w-full theme-bg-secondary border theme-border theme-text-primary text-[11px] font-bold uppercase tracking-[0.2em] py-5 mt-6 hover:theme-bg-primary transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed theme-shadow shadow-lg hover:shadow-none"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="animate-spin" size={16} />
                {status === 'grading' ? 'GRADING IN PROGRESS...' : 'PROCESSING...'}
              </>
            ) : (
              'Submit Forecast'
            )}
          </button>

          {errorStatus && (
            <div className="mt-4 p-4 bg-red-50 border-l-4 border-red-500 text-[11px] text-red-700 font-medium animate-in fade-in slide-in-from-top-1">
              <p className="mb-2 uppercase font-black text-red-800">Operational Failure</p>
              {errorStatus}
              <div className="mt-3">
                <button 
                  type="button"
                  onClick={() => onClose()} 
                  className="text-red-900 underline font-black uppercase tracking-widest"
                >
                  Abort & Return to Command
                </button>
              </div>
            </div>
          )}
        </form>
      </motion.div>
    </div>
  );
}

function PlusIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}
