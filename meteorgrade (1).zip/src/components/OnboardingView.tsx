import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, CloudRain, Crosshair, TrendingUp, UserSquare2, ChevronRight, Check, Zap, RefreshCw, Shield } from 'lucide-react';
import { doc, updateDoc } from '../lib/db';
import { db } from '../lib/db';
import { User } from '../lib/db';

interface OnboardingProps {
  user: User;
  profile: any;
  onComplete: () => void;
}

export default function OnboardingView({ user, profile, onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [handleInput, setHandleInput] = useState(profile?.handle || user.displayName?.split(' ')[0].toLowerCase() + Math.floor(Math.random()*1000) || 'agent_' + Math.floor(Math.random()*10000));
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const steps = [
    {
      id: 'welcome',
      icon: <Terminal size={48} className="text-slate-900 mb-6" />,
      title: 'WELCOME TO THE BUREAU',
      description: "Welcome to MeteorGrade. You're joining an elite network dedicated to mastering atmospheric precision. Whether you're here to learn the basics or test your expert intuition, you've found the right terminal."
    },
    {
      id: 'objective',
      icon: <TrendingUp size={48} className="text-indigo-600 mb-6" />,
      title: 'PRECISION INDEX (PI)',
      description: "Submission accuracy is measured via the PI—a weighted index of Temperature Variance, Condition Precision, and Timing. Your score determines your standing in the Global Bureau tiers."
    },
    {
      id: 'consensus',
      icon: <RefreshCw size={48} className="text-blue-600 mb-6" />,
      title: 'ENSMEBLE CHALLENGE',
      description: "Don't just follow the crowd. The Ensemble challenge rewards analysts who successfully pivot away from consensus data. Beat the crowd mean by 3 degrees for a 'Contrarian King' bonus."
    },
    {
      id: 'acme',
      icon: <Zap size={48} className="text-amber-500 mb-6" />,
      title: 'ACME RISK PROFILES',
      description: "Senior Bureau analysts don't just guess numbers; they manage risk. Use Advanced Risk Profiles to define 10th and 90th percentile distributions for high-uncertainty events."
    },
    {
      id: 'verification',
      icon: <Check size={48} className="text-emerald-600 mb-6" />,
      title: 'SENSOR VERIFICATION',
      description: "We don't use regional estimates. Every grade is calculated using the closest verified terrestrial sensor (METAR/Mesonet) to your target coordinates, ensuring objective ground truth."
    },
    {
      id: 'syndicate',
      icon: <Shield size={48} className="text-indigo-600 mb-6" />,
      title: 'SYNDICATE PROTOCOL',
      description: "Don't forecast alone. Form elite squads to share meteorological logic, upvote sound reasoning, and dominate regional sectors to earn prestigious 'Sector Control' badges."
    },
    {
      id: 'identity',
      icon: <UserSquare2 size={48} className="text-slate-900 mb-6" />,
      title: 'CHOOSE YOUR ALIAS',
      description: "Finalize your analyst identity. This is how you'll be recognized in the leaderboards and community challenges. Welcome to the team."
    }
  ];

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    }
  };

  const handleSave = async () => {
    setError('');
    const clean = handleInput.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (clean.length < 3) {
      setError('Alias must be at least 3 characters.');
      return;
    }
    if (clean.length > 20) {
      setError('Alias must be 20 characters or less.');
      return;
    }

    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        displayName: clean,
        onboarded: true
      });
      onComplete(); // Triggers the parent to remove the onboarding view
    } catch (err: any) {
      console.error(err);
      setError('Failed to secure alias. Try again.');
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-50 z-[100] flex flex-col items-center justify-center p-6 font-sans">
      <div className="w-full max-w-lg">
        {/* Progress Bar */}
        <div className="flex gap-2 mb-12 px-8">
          {steps.map((_, i) => (
            <div key={i} className={`h-1 flex-1 transition-all duration-500 ${i <= step ? 'bg-slate-900' : 'bg-slate-200'}`} />
          ))}
        </div>

        <div className="theme-bg-secondary border theme-border p-8 md:p-12 theme-shadow relative min-h-[420px] flex flex-col">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="flex-1 flex flex-col"
            >
              {steps[step].icon}
              <h2 className="text-xl font-bold uppercase tracking-widest mb-4 theme-text-primary border-b-2 theme-border pb-2 inline-block self-start">
                {steps[step].title}
              </h2>
              <p className="theme-text-secondary leading-relaxed text-sm md:text-base font-medium">
                {steps[step].description}
              </p>

              {step === steps.length - 1 && (
                <div className="mt-8 space-y-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">Secure Analyst ID</label>
                    <div className="flex theme-bg-input border theme-border focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 transition-all">
                      <span className="pl-4 py-3 theme-text-muted font-mono flex items-center">@</span>
                      <input 
                        type="text" 
                        value={handleInput}
                        onChange={(e) => setHandleInput(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                        className="bg-transparent theme-text-primary w-full py-3 px-2 font-mono text-sm outline-none"
                        placeholder="agent_name"
                        maxLength={20}
                        autoFocus
                      />
                    </div>
                    {error && (
                      <p className="theme-text-error text-[10px] uppercase font-bold mt-2">{error}</p>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          <div className="mt-12 flex justify-end">
            {step < steps.length - 1 ? (
              <button 
                onClick={handleNext}
                className="theme-bg-primary theme-text-primary border theme-border hover:theme-bg-secondary py-4 px-10 flex items-center justify-center gap-2 font-black uppercase tracking-[0.3em] text-[10px] transition-all active:translate-y-0.5 shadow-[4px_4px_0px_var(--shadow-color)]"
              >
                Continue <ChevronRight size={14} />
              </button>
            ) : (
              <button 
                onClick={handleSave}
                disabled={isSaving}
                className={`py-4 px-10 flex items-center justify-center gap-2 font-black uppercase tracking-[0.3em] text-[10px] transition-all active:translate-y-0.5 ${
                  isSaving ? 'bg-slate-400 text-white cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {isSaving ? (
                  <RefreshCw size={14} className="animate-spin" />
                ) : (
                  <>Join the Bureau <Check size={14} /></>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
