import React, { useState, useEffect, useMemo } from "react";
import { auth, db } from "../lib/db";
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  doc,
  updateDoc,
  serverTimestamp,
  addDoc,
  where,
  getDocs,
  limit,
  deleteDoc,
  Timestamp,
  User,
} from "../lib/db";
import {
  Shield,
  Clock,
  CheckCircle,
  AlertCircle,
  MessageSquare,
  Save,
  Users,
  Activity,
  Radio,
  AlertTriangle,
  Search,
  Filter,
  MoreHorizontal,
  UserPlus,
  Trash2,
  Award,
  Thermometer,
  Wind,
  Droplets,
  Edit3,
  Send,
  Info,
  ExternalLink,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  Zap,
  Sun,
  Cloud,
  MapPin,
  Loader2,
  Bug,
  X,
  ChevronRight,
  ChevronLeft,
  SearchCode,
  Eye,
  Database
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { getActualGrade } from "../services/geminiService";

type AdminTab = "pulse" | "analysts" | "audit" | "news" | "support" | "feedback" | "moderation";

interface AdminPanelViewProps {
  syncStatus?: {
    lastSync: Date | null;
    isSyncing: boolean;
  };
  onTriggerSync?: () => Promise<void>;
  currentUser: User | null;
}

export default function AdminPanelView({
  syncStatus,
  onTriggerSync,
  currentUser,
}: AdminPanelViewProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>("pulse");
  const [loading, setLoading] = useState(true);

  // Moderation State
  const [reports, setReports] = useState<any[]>([]);
  const [selectedReport, setSelectedReport] = useState<any>(null);

  // Support State
  const [tickets, setTickets] = useState<any[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [replyText, setReplyText] = useState("");
  const [ticketStatus, setTicketStatus] = useState("open");

  const [supportFilter, setSupportFilter] = useState<
    "all" | "open" | "resolved"
  >("open");

  // Analysts State
  const [analysts, setAnalysts] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOp, setSelectedOp] = useState<any>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Audit State
  const [globalForecasts, setGlobalForecasts] = useState<any[]>([]);
  const [selectedForecast, setSelectedForecast] = useState<any>(null);
  const [manualGrade, setManualGrade] = useState({ score: 85, feedback: "" });

  // Intel State
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [feedback, setFeedback] = useState<any[]>([]);
  const [feedbackNotes, setFeedbackNotes] = useState<any[]>([]);
  const [selectedFeedback, setSelectedFeedback] = useState<any | null>(null);
  const [newAnnouncement, setNewAnnouncement] = useState({
    title: "",
    content: "",
    type: "info",
    expiresAt: "",
  });

  // Pulse State
  const [pulseMetrics, setPulseMetrics] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalForecasts: 0,
    activeMissions: 0,
    averageAccuracy: 0,
    ticketsOpen: 0,
  });

  const [isSaving, setIsSaving] = useState(false);
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [broadcastResult, setBroadcastResult] = useState<any>(null);

  const handleBroadcast = async (manualTitle?: string, manualBody?: string) => {
    setIsBroadcasting(true);
    setBroadcastResult(null);
    try {
      const usersSnap = await getDocs(query(collection(db, 'users'), where('notificationsEnabled', '==', true)));
      const allTokens: any[] = [];
      
      const docs = usersSnap.docs;
      docs.forEach(doc => {
        const subs = doc.data().pushSubscriptions;
        if (subs && Array.isArray(subs)) {
          subs.forEach(s => allTokens.push(s));
        }
      });

      if (allTokens.length === 0) {
        setBroadcastResult({ error: "No analysts have active satellite links (notifications enabled)." });
        return;
      }

      const res = await fetch('/api/notifications/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: manualTitle || "Bureau Synchronization",
          body: manualBody || "Daily atmospheric briefing required. Submit your forecast now.",
          tokens: allTokens
        })
      });
      const data = await res.json();
      setBroadcastResult(data);
    } catch (err: any) {
      console.error("Broadcast failed", err);
      setBroadcastResult({ error: err.message });
    } finally {
      setIsBroadcasting(false);
      setTimeout(() => setBroadcastResult(null), 5000);
    }
  };

  useEffect(() => {
    const isAdminUser =
      auth.currentUser?.email?.toLowerCase() === "tylerleedixon@gmail.com";
    if (!isAdminUser) {
      setLoading(false);
      return;
    }

    setLoading(true);

    // 0. Chat Reports
    const unsubReports = onSnapshot(
      query(collection(db, "chat_reports"), orderBy("createdAt", "desc")),
      (snap) => {
        setReports(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      },
      (err) => console.error("Admin Reports Listener Error:", err),
    );

    // 1. Support Tickets
    const unsubSupport = onSnapshot(
      query(collection(db, "supportTickets"), orderBy("createdAt", "desc")),
      (snap) => {
        setTickets(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      },
      (err) => console.error("Admin Support Listener Error:", err),
    );

    // 2. Analysts
    const unsubAnalysts = onSnapshot(
      query(collection(db, "users"), orderBy("precisionIndex", "desc")),
      (snap) => {
        setAnalysts(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      },
      (err) => console.error("Admin Analysts Listener Error:", err),
    );

    // 3. Global Forecasts (Last 50)
    const unsubForecasts = onSnapshot(
      query(
        collection(db, "forecasts"),
        orderBy("createdAt", "desc"),
        limit(50),
      ),
      (snap) => {
        setGlobalForecasts(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      },
      (err) => console.error("Admin Forecasts Listener Error:", err),
    );

    // 4. Announcements
    const unsubAnnouncements = onSnapshot(
      query(
        collection(db, "announcements"),
        orderBy("createdAt", "desc"),
        limit(50),
      ),
      (snap) => {
        setAnnouncements(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      },
      (err) => console.error("Admin Announcements Listener Error:", err),
    );

    // 5. Beta Feedback
    const unsubFeedback = onSnapshot(
      query(
        collection(db, "betaFeedback"),
        orderBy("timestamp", "desc"),
        limit(100),
      ),
      (snap) => {
        setFeedback(snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter(f => f.status !== 'archived'));
      },
      (err) => console.error("Admin Feedback Listener Error:", err),
    );

    const unsubFeedbackNotes = onSnapshot(
      collection(db, "betaFeedbackNotes"),
      (snap) => {
        setFeedbackNotes(snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter(n => n.status !== 'archived'));
      },
      (err) => console.error("Admin Feedback Notes Listener Error:", err),
    );

    // 6. Metrics Calculation (Pulse)
    const unsubMissions = onSnapshot(collection(db, "missions"), (snap) => {
      const missions = snap.docs.map(d => d.data());
      const active = missions.filter(m => m.status === 'active').length;
      setPulseMetrics(p => ({ ...p, activeMissions: active }));
    });

    const unsubPulse = onSnapshot(
      collection(db, "users"),
      (snap) => {
        const users = snap.docs.map((d) => d.data());
        const totalF = users.reduce(
          (acc, curr) => acc + (curr.totalForecasts || 0),
          0,
        );

        // Filter users who have at least one forecast to calculate average accuracy
        const activeUsers = users.filter((u) => (u.totalForecasts || 0) > 0);
        const rawAvg =
          activeUsers.length > 0
            ? activeUsers.reduce(
                (acc, curr) => acc + (curr.averageAccuracy || 0),
                0,
              ) / activeUsers.length
            : 0;

        const avgA = isNaN(rawAvg) ? 0 : rawAvg;

        setPulseMetrics((prev) => ({
          ...prev,
          totalUsers: users.length,
          activeUsers: activeUsers.length,
          totalForecasts: totalF,
          activeMissions: 0, // Calculated manually if needed, or fetched
          averageAccuracy: Math.round(avgA * 10) / 10,
        }));
      },
      (err) => console.error("Admin Pulse Listener Error:", err),
    );

    setLoading(false);
    return () => {
      unsubSupport();
      unsubAnalysts();
      unsubForecasts();
      unsubAnnouncements();
      unsubFeedback();
      unsubFeedbackNotes();
      unsubMissions();
      unsubPulse();
      unsubReports();
    };
  }, []);

  // Handlers
  const handleResolveReport = async (reportId: string, status: 'resolved' | 'dismissed', messageId?: string, deleteMessage: boolean = false) => {
    setIsSaving(true);
    try {
      if (deleteMessage && messageId) {
        await deleteDoc(doc(db, "syndicate_messages", messageId));
      }
      await updateDoc(doc(db, "chat_reports", reportId), {
        status,
        resolvedAt: serverTimestamp(),
        resolvedBy: currentUser?.uid
      });
      setSelectedReport(null);
    } catch (err) {
      console.error(err);
      alert("Resolution error: Permission denied or sync failure.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveTicket = async () => {
    if (!selectedTicket) return;
    const targetId = selectedTicket.id;
    const newStatus = ticketStatus;

    setIsSaving(true);

    // Optimistic Update: Reflect new status in list immediately
    setTickets((prev) =>
      prev.map((t) => (t.id === targetId ? { ...t, status: newStatus } : t)),
    );

    // If resolving, we also optimistically close the detail view
    if (newStatus === "resolved") {
      setSelectedTicket(null);
      setReplyText("");
    }

    try {
      await updateDoc(doc(db, "supportTickets", targetId), {
        adminReply: replyText.trim(),
        status: newStatus,
      });
      // Safety: close again if not already closed
      setSelectedTicket(null);
      setReplyText("");
    } catch (err) {
      console.error(err);
      alert(
        "System Sync Failure: Could not update ticket status. Verify connection.",
      );
      // Note: we don't rollback here because onSnapshot will eventually reconcile
    } finally {
      setIsSaving(false);
    }
  };

  const getAnalystEmail = (userId: string) => {
    const analyst = analysts.find((a) => a.id === userId);
    return analyst?.email || "Unknown Analyst";
  };

  const handleUpdateOp = async () => {
    if (!selectedOp) return;
    setIsSaving(true);
    try {
      await updateDoc(doc(db, "users", selectedOp.id), {
        tier: selectedOp.tier,
        role: selectedOp.role || "user",
        precisionIndex: Number(selectedOp.precisionIndex),
        avatarUrl: selectedOp.avatarUrl || null,
      });
      setSelectedOp(null);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAnalyst = async (analystId: string) => {
    if (!analystId) return;

    setIsSaving(true);
    try {
      // 1. Delete main user profile
      await deleteDoc(doc(db, "users", analystId));

      // 2. Note: Frontend onSnapshot will handle UI removal.

      setConfirmDeleteId(null);
      setSelectedOp(null);
    } catch (err: any) {
      console.error("Delete Analyst Error:", err);
      alert(
        `Access Denied or System Error: ${err.message || "Unknown error"}. Verify your Admin status.`,
      );
    } finally {
      setIsSaving(false);
    }
  };

  const handleManualGrade = async () => {
    if (!selectedForecast) return;
    setIsSaving(true);
    try {
      await updateDoc(doc(db, "forecasts", selectedForecast.id), {
        actualGrade: {
          ...selectedForecast.actualGrade,
          score: manualGrade.score,
          feedback: manualGrade.feedback,
          gradedAt: new Date().toISOString(),
        },
        status: "completed",
      });
      setSelectedForecast(null);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleAutoVerify = async () => {
    if (!selectedForecast) return;
    setIsSaving(true);
    try {
      console.log(`[Admin] Triggering AI Verification for ${selectedForecast.id}`);
      const result = await getActualGrade({ forecast: selectedForecast });
      
      if (!result.isHistoryAvailable) {
        alert("Atmospheric Archives Unavailable: No definitive ground-truth records found for this coordinate/timeframe yet. Verify manual data entrance.");
        return;
      }

      await updateDoc(doc(db, "forecasts", selectedForecast.id), {
        actualGrade: {
          ...selectedForecast.actualGrade,
          score: result.score,
          feedback: result.feedback,
          actualHigh: result.actualHigh,
          actualLow: result.actualLow,
          actualCondition: result.actualCondition,
          silverLining: result.silverLining || null,
          gradedAt: new Date().toISOString(),
          verificationMethod: 'ai_grounding'
        },
        status: "completed",
      });
      
      // Update local state for manual grade inputs to match new auto grade
      setManualGrade({
        score: result.score,
        feedback: result.feedback
      });
      
      alert(`Verification Successful: ${result.score}% Precision Assigned.`);
    } catch (err: any) {
      console.error(err);
      alert(`Verification Uplink Failed: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handlePostAnnouncement = async () => {
    if (!newAnnouncement.title || !newAnnouncement.content) return;
    setIsSaving(true);
    try {
      await addDoc(collection(db, "announcements"), {
        ...newAnnouncement,
        isActive: true,
        createdAt: serverTimestamp(),
        priority: newAnnouncement.type === "critical" ? 1 : 2,
        expiresAt: newAnnouncement.expiresAt
          ? new Date(newAnnouncement.expiresAt).toISOString()
          : null,
      });
      setNewAnnouncement({
        title: "",
        content: "",
        type: "info",
        expiresAt: "",
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const deleteAnnouncement = async (id: string) => {
    if (!confirm("Are you sure you want to delete this broadcast?")) return;

    const originalAnnouncements = [...announcements];
    // Optimistic Update
    setAnnouncements((prev) => prev.filter((a) => a.id !== id));

    try {
      console.log(`[Admin] Attempting to delete announcement: ${id}`);
      await deleteDoc(doc(db, "announcements", id));
      console.log(`[Admin] Successfully deleted announcement: ${id}`);
    } catch (err: any) {
      console.error("[Admin] Delete failed:", err);
      // Rollback
      setAnnouncements(originalAnnouncements);
      alert(
        `Delete Failed: ${err.message || "Unknown Error"}. Please check admin permissions.`,
      );
    }
  };

  // Filtered Lists
  const filteredAnalysts = useMemo(
    () =>
      analysts.filter(
        (op) =>
          op.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          op.email?.toLowerCase().includes(searchTerm.toLowerCase()),
      ),
    [analysts, searchTerm],
  );

  const filteredTickets = useMemo(() => {
    return tickets.filter((t) => {
      if (supportFilter === "all") return true;
      if (supportFilter === "open")
        return t.status === "open" || t.status === "in_progress";
      return t.status === "resolved";
    });
  }, [tickets, supportFilter]);

  return (
    <div className="flex-1 flex flex-col h-full theme-bg-app">
      <div className="p-4 md:p-6 lg:p-8 max-w-[1800px] mx-auto w-full flex-1 min-h-[1200px] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="mb-6 md:mb-8 shrink-0 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-red-600 dark:text-red-400 flex items-center gap-2">
                <Shield size={14} /> HQ Authorized
              </span>
              {syncStatus && (
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 px-2 py-0.5 theme-bg-primary border theme-border">
                    <Radio
                      size={10}
                      className={`${syncStatus.isSyncing ? "text-red-500 animate-pulse" : "theme-text-muted"}`}
                    />
                    <span className="text-[8px] font-bold uppercase tracking-widest theme-text-secondary line-clamp-1">
                      NWS Sync:{" "}
                      {syncStatus.isSyncing
                        ? "Active"
                        : syncStatus.lastSync
                          ? syncStatus.lastSync.toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })
                          : "Pending"}
                    </span>
                  </div>
                  {onTriggerSync && (
                    <button
                      onClick={() => onTriggerSync()}
                      disabled={syncStatus.isSyncing}
                      className="p-1 theme-text-muted hover:text-indigo-600 transition-colors disabled:opacity-50"
                    >
                      <RefreshCw
                        size={14}
                        className={syncStatus.isSyncing ? "animate-spin" : ""}
                      />
                    </button>
                  )}
                </div>
              )}
            </div>
            <h1 className="text-3xl md:text-4xl font-light tracking-tight theme-text-primary mt-2">
              Admin{" "}
              <span className="font-bold uppercase tracking-tighter text-indigo-600 dark:text-indigo-400">
                Center
              </span>
            </h1>
            <p className="hidden md:block theme-text-secondary mt-1 max-w-md">
              Global infrastructure oversight and network management.
            </p>
          </div>

          <div className="flex theme-bg-primary p-1 border theme-border overflow-x-auto no-scrollbar scroll-smooth">
            <div className="flex shrink-0">
              {[
                { id: "pulse", icon: Activity, label: "Pulse" },
                { id: "analysts", icon: Users, label: "Analysts" },
                { id: "audit", icon: CheckCircle, label: "Audit" },
                { id: "news", icon: Radio, label: "News" },
                { id: "moderation", icon: AlertTriangle, label: "Security", hasIndicator: reports.some(r => r.status === 'pending') },
                { id: "support", icon: MessageSquare, label: "Tickets" },
                { id: "feedback", icon: Bug, label: "Beta", hasIndicator: feedback.some(f => f.status === 'new') },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as AdminTab)}
                  className={`px-4 py-2 relative text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-all whitespace-nowrap ${
                    activeTab === tab.id
                      ? "bg-slate-900 border border-slate-700 dark:bg-indigo-600 text-white shadow-sm"
                      : "theme-text-secondary hover:theme-text-primary"
                  }`}
                >
                  <tab.icon size={12} /> {tab.label}
                  {tab.hasIndicator && (
                    <div className="absolute top-[2px] right-[2px] w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse border border-white" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-hidden min-h-[1000px]">
          <AnimatePresence mode="wait">
            {/* Tab 1: Pulse */}
            {activeTab === "pulse" && (
              <motion.div
                key="pulse"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
              >
                <div className="theme-bg-secondary border theme-border p-6 theme-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <Users className="text-indigo-600 dark:text-indigo-400" size={20} />
                    <span className="text-[10px] font-bold theme-text-muted uppercase tracking-widest">
                      Global Network
                    </span>
                  </div>
                  <div className="text-3xl font-bold theme-text-primary">
                    {pulseMetrics.activeUsers}
                  </div>
                  <div className="text-xs theme-text-secondary mt-1">
                    Active Analysts ({pulseMetrics.totalUsers} Total)
                  </div>
                </div>

                <div className="theme-bg-secondary border theme-border p-6 theme-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <CheckCircle className="theme-text-success" size={20} />
                    <span className="text-[10px] font-bold theme-text-muted uppercase tracking-widest">
                      Data Flow
                    </span>
                  </div>
                  <div className="text-3xl font-bold theme-text-primary">
                    {pulseMetrics.totalForecasts}
                  </div>
                  <div className="text-xs theme-text-secondary mt-1">
                    System-wide Forecasts
                  </div>
                </div>

                <div className="theme-bg-secondary border theme-border p-6 theme-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <Award className="theme-text-warning" size={20} />
                    <span className="text-[10px] font-bold theme-text-muted uppercase tracking-widest">
                      Accuracy Hub
                    </span>
                  </div>
                  <div className="text-3xl font-bold theme-text-primary">
                    {pulseMetrics.averageAccuracy}%
                  </div>
                  <div className="text-xs theme-text-secondary mt-1">
                    Network Avg Precision
                  </div>
                </div>

                <div className="theme-bg-secondary border theme-border p-6 theme-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <MessageSquare className="theme-text-error" size={20} />
                    <span className="text-[10px] font-bold theme-text-muted uppercase tracking-widest">
                      Support Load
                    </span>
                  </div>
                  <div className="text-3xl font-bold theme-text-primary">
                    {tickets.filter((t) => t.status === "open").length}
                  </div>
                  <div className="text-xs theme-text-secondary mt-1">
                    Unresolved Transmissions
                  </div>
                </div>

                <div className="lg:col-span-4 bg-slate-900 border border-slate-800 text-white p-8 overflow-hidden relative shadow-xl">
                  <Activity className="absolute -right-8 -bottom-8 w-64 h-64 theme-text-primary/50" />
                  <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8 text-center lg:text-left">
                    <div>
                      <h2 className="text-xl font-bold mb-2 flex items-center gap-2 justify-center lg:justify-start">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        Infrastructure Live
                      </h2>
                      <p className="theme-text-muted text-sm max-w-lg leading-relaxed">
                        The forecast ingestion pipeline is stable. Data
                        throughput is scaling with {pulseMetrics.totalForecasts}{" "}
                        recorded operations. Global synchronization is
                        maintaining {pulseMetrics.averageAccuracy}% network
                        precision across {pulseMetrics.totalUsers} active
                        analysts.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-center gap-4">
                      <div className="flex flex-col items-center p-4 theme-bg-primary/50 border border-white/10 w-28">
                        <span className="text-[10px] font-bold uppercase tracking-widest opacity-50 mb-1">
                          LOAD
                        </span>
                        <span className="text-lg font-mono text-indigo-400">
                          {Math.min(
                            100,
                            Math.round(pulseMetrics.totalForecasts / 10),
                          )}
                          %
                        </span>
                      </div>
                      <div className="flex flex-col items-center p-4 theme-bg-primary/50 border border-white/10 w-28">
                        <span className="text-[10px] font-bold uppercase tracking-widest opacity-50 mb-1">
                          SYNC
                        </span>
                        <span className="text-lg font-mono text-emerald-400">
                          {syncStatus?.isSyncing ? "ACTIVE" : "IDLE"}
                        </span>
                      </div>
                      <div className="flex flex-col items-center p-4 bg-indigo-500/20 border border-indigo-500/30 w-28 text-indigo-300">
                        <span className="text-[10px] font-bold uppercase tracking-widest opacity-50 mb-1">
                          LATENCY
                        </span>
                        <span className="text-lg font-mono">
                          {syncStatus?.isSyncing ? "142ms" : "24ms"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-4 theme-bg-secondary border theme-border p-8 theme-shadow space-y-6">
                  <div className="flex items-center justify-between border-b theme-border pb-4">
                    <div>
                      <h3 className="text-sm font-bold uppercase tracking-[0.2em] theme-text-primary">Satellite Broadcast Relay</h3>
                      <p className="text-[10px] font-mono theme-text-muted mt-1 italic">Network-wide signal distribution via Web Push / GCM</p>
                    </div>
                    <Radio size={20} className={isBroadcasting ? "text-indigo-600 animate-pulse" : "theme-text-muted"} />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <div className="p-4 theme-bg-primary border-l-4 border-indigo-500 space-y-2">
                        <h4 className="text-[11px] font-bold theme-text-primary uppercase tracking-wider">Protocol: Daily Briefing</h4>
                        <p className="text-[10px] theme-text-secondary leading-relaxed">
                          Triggers a "Submit Forecast" prompt to all analysts with persistent connections. Use this to maintain engagement during atmospheric transitions.
                        </p>
                        <button
                          onClick={() => handleBroadcast()}
                          disabled={isBroadcasting}
                          className="mt-2 w-full bg-slate-900 dark:bg-indigo-600 text-white py-2 text-[10px] font-bold uppercase tracking-widest hover:opacity-80 transition-all flex items-center justify-center gap-2"
                        >
                          {isBroadcasting ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
                          Transmit Daily Prompt
                        </button>
                      </div>

                      {broadcastResult && (
                         <div className={`p-4 text-[10px] font-mono border ${broadcastResult.error ? 'theme-bg-error theme-text-error border-red-200' : 'theme-bg-success theme-text-success border-emerald-200'}`}>
                           {broadcastResult.error ? (
                             broadcastResult.error
                           ) : (
                             `SYNC SUCCESS: ${broadcastResult.successCount} DELIVERED | ${broadcastResult.failureCount} DROPPED`
                           )}
                         </div>
                      )}
                    </div>

                    <div className="space-y-4 theme-bg-primary p-6 border theme-border">
                       <h4 className="text-[11px] font-bold theme-text-primary uppercase tracking-wider">Manual Signal Override</h4>
                       <div className="space-y-3">
                         <input 
                           id="broadcast-title"
                           type="text" 
                           placeholder="Signal Title (e.g. Critical Heat Warning)" 
                           className="w-full theme-bg-secondary border theme-border p-2 text-xs outline-none focus:border-indigo-500 font-mono theme-text-primary"
                         />
                         <textarea 
                           id="broadcast-body"
                           placeholder="Signal Content (Brief, high-impact message)" 
                           rows={3}
                           className="w-full theme-bg-secondary border theme-border p-2 text-xs outline-none focus:border-indigo-500 font-mono resize-none theme-text-primary"
                         />
                         <button
                          onClick={() => {
                            const t = (document.getElementById('broadcast-title') as HTMLInputElement).value;
                            const b = (document.getElementById('broadcast-body') as HTMLTextAreaElement).value;
                            handleBroadcast(t, b);
                          }}
                          disabled={isBroadcasting}
                          className="w-full border-2 border-indigo-600 text-indigo-600 py-2 text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center gap-2"
                        >
                          Launch Custom Signal
                        </button>
                       </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Tab: Moderation */}
            {activeTab === "moderation" && (
              <motion.div
                key="moderation"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-full"
              >
                <div className="lg:col-span-2 flex flex-col gap-4">
                  <div className="theme-bg-secondary border theme-border p-4 flex items-center justify-between">
                    <h3 className="text-xs font-black uppercase tracking-widest text-red-500 flex items-center gap-2">
                       <AlertTriangle size={14} /> Breach Reports Queue
                    </h3>
                    <span className="text-[10px] font-mono theme-text-muted">{reports.filter(r => r.status === 'pending').length} ACTIVE VIOLATIONS</span>
                  </div>

                  <div className="space-y-3 overflow-y-auto max-h-[800px] pr-2 custom-scrollbar">
                    {reports.length === 0 ? (
                      <div className="p-12 text-center opacity-30">
                        <Shield size={48} className="mx-auto mb-4" />
                        <p className="text-xs font-bold uppercase tracking-widest">Network Secure - No Reports</p>
                      </div>
                    ) : (
                      reports.map((report) => (
                        <div 
                          key={report.id}
                          className={`p-4 border theme-border cursor-pointer transition-all ${
                            selectedReport?.id === report.id ? 'theme-bg-primary border-red-500 shadow-lg' : 'theme-bg-secondary hover:border-red-400'
                          } ${report.status !== 'pending' ? 'opacity-40' : ''}`}
                          onClick={() => setSelectedReport(report)}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                               report.reason === 'harassment' ? 'bg-red-500 text-white' : 'bg-amber-500 text-white'
                            }`}>
                              {report.reason}
                            </span>
                            <span className="text-[9px] font-mono theme-text-muted">
                              {report.createdAt ? new Date(report.createdAt.toDate ? report.createdAt.toDate() : report.createdAt).toLocaleString() : '...'}
                            </span>
                          </div>
                          <div className="theme-text-primary text-xs font-bold truncate mb-1">
                             Reported by Analyst: {report.reporterId?.slice(0, 8)}...
                          </div>
                          {report.status !== 'pending' && (
                            <div className="text-[9px] text-emerald-500 font-bold uppercase flex items-center gap-1 mt-2">
                              <CheckCircle size={10} /> RESOLVED: {report.status}
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-6">
                   {selectedReport ? (
                     <div className="theme-bg-secondary border-2 border-red-500/30 p-6 theme-shadow space-y-6">
                        <div className="border-b theme-border pb-4">
                           <h4 className="text-[10px] font-black uppercase tracking-[0.2em] theme-text-primary mb-2">Breach Investigation</h4>
                           <p className="text-[9px] theme-text-muted uppercase tracking-widest">Report ID: {selectedReport.id}</p>
                        </div>

                        <div className="space-y-4">
                           <div className="p-4 theme-bg-primary border theme-border">
                              <span className="text-[8px] font-black text-red-500 uppercase block mb-2">System Reason</span>
                              <p className="text-xs font-bold uppercase">{selectedReport.reason}</p>
                           </div>

                           <div className="p-4 theme-bg-primary border theme-border">
                              <span className="text-[8px] font-black text-indigo-500 uppercase block mb-2">Reporter Trace</span>
                              <p className="text-xs font-mono">{selectedReport.reporterId}</p>
                           </div>

                           {selectedReport.status === 'pending' && (
                             <div className="pt-6 space-y-3">
                               <button 
                                 onClick={() => handleResolveReport(selectedReport.id, 'resolved', selectedReport.messageId, true)}
                                 className="w-full py-4 bg-red-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-slate-900 transition-all flex items-center justify-center gap-2"
                               >
                                 <Trash2 size={14} /> Purge Content & Resolve
                               </button>
                               <button 
                                 onClick={() => handleResolveReport(selectedReport.id, 'resolved', undefined, false)}
                                 className="w-full py-4 border-2 border-slate-900 dark:border-white theme-text-primary text-[10px] font-black uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all"
                               >
                                 Verify & Mark Resolved
                               </button>
                               <button 
                                 onClick={() => handleResolveReport(selectedReport.id, 'dismissed', undefined, false)}
                                 className="w-full py-4 text-[10px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-all"
                               >
                                 Dismiss Flag
                               </button>
                             </div>
                           )}
                        </div>
                     </div>
                   ) : (
                     <div className="h-full flex flex-col items-center justify-center opacity-20 border-2 border-dashed theme-border p-12 text-center">
                        <Search size={48} className="mb-4" />
                        <p className="text-xs font-black uppercase tracking-widest">Select report for investigation</p>
                     </div>
                   )}
                </div>
              </motion.div>
            )}

            {/* Tab 2: Analysts */}
            {activeTab === "analysts" && (
              <motion.div
                key="analysts"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="theme-bg-secondary border theme-border flex flex-col h-full overflow-hidden theme-shadow"
              >
                <div className="p-4 border-b theme-border flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="relative flex-1 max-w-sm">
                    <Search
                      className="absolute left-3 top-1/2 -translate-y-1/2 theme-text-muted"
                      size={16}
                    />
                    <input
                      type="text"
                      placeholder="Search Analysts..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full theme-bg-primary border theme-border py-2 pl-10 pr-4 text-sm outline-none focus:border-indigo-600 focus:theme-bg-secondary transition-all theme-text-primary"
                    />
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-bold theme-text-muted uppercase tracking-widest">
                    <Users size={14} /> {filteredAnalysts.length} Active Records
                  </div>
                </div>

                <div className="flex-1 overflow-auto">
                  {/* Desktop Table */}
                  <table className="w-full border-collapse hidden md:table">
                    <thead className="sticky top-0 theme-bg-primary border-b theme-border z-10">
                      <tr>
                        <th className="text-left py-4 px-6 text-[10px] font-bold uppercase tracking-widest theme-text-muted">
                          Analyst
                        </th>
                        <th className="text-left py-4 px-6 text-[10px] font-bold uppercase tracking-widest theme-text-muted">
                          Precision
                        </th>
                        <th className="text-left py-4 px-6 text-[10px] font-bold uppercase tracking-widest theme-text-muted">
                          Rank/Tier
                        </th>
                        <th className="text-left py-4 px-6 text-[10px] font-bold uppercase tracking-widest theme-text-muted">
                          Forecasts
                        </th>
                        <th className="text-right py-4 px-6 text-[10px] font-bold uppercase tracking-widest theme-text-muted">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y theme-border">
                      {filteredAnalysts.map((op) => (
                        <tr
                          key={op.id}
                          className="hover:theme-bg-primary transition-colors"
                        >
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full theme-bg-primary flex items-center justify-center text-[10px] font-bold theme-text-muted overflow-hidden border theme-border">
                                {op.avatarUrl ? (
                                  <img src={op.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                                ) : (
                                  op.displayName?.[0] || 'U'
                                )}
                              </div>
                              <div>
                                <div className="font-bold text-sm theme-text-primary">
                                  {op.displayName || "Unknown"}
                                </div>
                                <div className="text-[10px] theme-text-muted font-mono italic">
                                  {op.email}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-2">
                              <div className="w-16 h-1.5 theme-bg-primary rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-indigo-500"
                                  style={{
                                    width: `${(op.precisionIndex || 0) / 10}%`,
                                  }}
                                ></div>
                              </div>
                              <span className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                {op.precisionIndex || 0}
                              </span>
                            </div>
                          </td>
                          <td className="py-4 px-6">
                            <span className="px-2 py-0.5 border theme-border text-[10px] font-bold theme-text-secondary theme-bg-primary">
                              {op.tier || "Novice"}
                            </span>
                          </td>
                          <td className="py-4 px-6 text-xs theme-text-secondary font-mono">
                            {op.totalForecasts || 0}
                          </td>
                          <td className="py-4 px-6 text-right">
                            <button
                              onClick={() => setSelectedOp(op)}
                              className="text-indigo-600 hover:text-indigo-800 transition-colors"
                            >
                              <Edit3 size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Mobile Cards */}
                  <div className="md:hidden divide-y divide-slate-100 italic">
                    {filteredAnalysts.map((op) => (
                      <div key={op.id} className="p-4 space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-bold theme-text-primary">
                              {op.displayName || "Unknown"}
                            </div>
                            <div className="text-[10px] theme-text-muted font-mono">
                              {op.email}
                            </div>
                          </div>
                          <button
                            onClick={() => setSelectedOp(op)}
                            className="p-2 theme-bg-primary border theme-border theme-text-muted"
                          >
                            <Edit3 size={14} />
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-2 theme-bg-primary/50 border theme-border">
                            <span className="text-[8px] font-bold uppercase tracking-widest theme-text-muted block mb-1">
                              Precision
                            </span>
                            <span className="text-xs font-mono font-bold text-indigo-600">
                              {op.precisionIndex || 0}
                            </span>
                          </div>
                          <div className="p-2 theme-bg-primary/50 border theme-border">
                            <span className="text-[8px] font-bold uppercase tracking-widest theme-text-muted block mb-1">
                              Rank
                            </span>
                            <span className="text-xs font-bold theme-text-secondary">
                              {op.tier || "Novice"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Edit OP Modal */}
                <AnimatePresence>
                  {selectedOp && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-slate-900/40"
                    >
                      <motion.div
                        initial={{ scale: 0.9, y: 20 }}
                        animate={{ scale: 1, y: 0 }}
                        className="theme-bg-secondary border theme-border shadow-2xl w-full max-w-md overflow-hidden"
                      >
                        <div className="p-6 border-b theme-border theme-bg-primary">
                          <h2 className="text-lg font-bold theme-text-primary">
                            Modify Analyst Profile
                          </h2>
                          <p className="text-[10px] theme-text-muted uppercase tracking-widest font-bold mt-1">
                            Analyst: {selectedOp.displayName}
                          </p>
                        </div>
                        <div className="p-8 space-y-6">
                          <div>
                            <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                              Tier Assignment
                            </label>
                            <select
                              value={selectedOp.tier}
                              onChange={(e) =>
                                setSelectedOp({
                                  ...selectedOp,
                                  tier: e.target.value,
                                })
                              }
                              className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600 transition-all font-mono"
                            >
                              {[
                                "Novice",
                                "Observer",
                                "Specialist",
                                "Sage",
                                "Legend",
                              ].map((t) => (
                                <option key={t} value={t}>
                                  {t}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                              Access Level (Role)
                            </label>
                            <select
                              value={selectedOp.role || "user"}
                              onChange={(e) =>
                                setSelectedOp({
                                  ...selectedOp,
                                  role: e.target.value,
                                })
                              }
                              className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600 transition-all font-mono"
                            >
                              <option value="user">User</option>
                              <option value="admin">Admin</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                              Avatar URL
                            </label>
                            <input
                              type="text"
                              value={selectedOp.avatarUrl || ""}
                              onChange={(e) =>
                                setSelectedOp({
                                  ...selectedOp,
                                  avatarUrl: e.target.value,
                                })
                              }
                              className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600 transition-all font-mono"
                              placeholder="https://example.com/photo.jpg"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                              Precision Index Adjust
                            </label>
                            <input
                              type="number"
                              value={selectedOp.precisionIndex}
                              onChange={(e) =>
                                setSelectedOp({
                                  ...selectedOp,
                                  precisionIndex: e.target.value,
                                })
                              }
                              className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600 transition-all font-mono"
                            />
                          </div>
                          <div className="flex gap-4">
                            <button
                              onClick={() => setSelectedOp(null)}
                              className="flex-1 py-3 text-[10px] font-bold uppercase tracking-widest border theme-border hover:theme-bg-primary transition-all font-mono"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={handleUpdateOp}
                              disabled={isSaving}
                              className="flex-1 py-3 text-[10px] font-bold uppercase tracking-widest bg-slate-900 text-white hover:bg-slate-800 transition-all font-mono"
                            >
                              {isSaving ? "Processing..." : "Save Profile"}
                            </button>
                          </div>

                          <div className="pt-6 border-t theme-border flex flex-col gap-3">
                            <div className="text-[10px] font-bold text-red-600 uppercase tracking-widest px-1">
                              Restricted Zone
                            </div>

                            {confirmDeleteId === selectedOp.id ? (
                              <div className="bg-red-50 p-4 border border-red-200 space-y-4">
                                <p className="text-[10px] text-red-600 font-bold leading-relaxed uppercase tracking-tight">
                                  Final Confirmation Required: Purging this
                                  record is irreversible.
                                </p>
                                <div className="flex gap-2">
                                  <button
                                    onClick={() => setConfirmDeleteId(null)}
                                    className="flex-1 py-2 text-[10px] font-bold uppercase tracking-widest theme-bg-secondary border border-red-200 theme-text-muted hover:theme-bg-primary transition-all font-mono"
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    onClick={() =>
                                      handleDeleteAnalyst(selectedOp.id)
                                    }
                                    disabled={isSaving}
                                    className="flex-1 py-2 text-[10px] font-bold uppercase tracking-widest bg-red-600 text-white hover:bg-red-700 transition-all font-mono shadow-sm"
                                  >
                                    {isSaving ? "PURGING..." : "CONFIRM PURGE"}
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <button
                                onClick={() =>
                                  setConfirmDeleteId(selectedOp.id)
                                }
                                disabled={isSaving}
                                className="w-full py-4 text-[10px] font-bold uppercase tracking-widest border-2 border-red-100 text-red-500 hover:bg-red-50 hover:border-red-500 transition-all flex items-center justify-center gap-2 group font-mono"
                              >
                                <Trash2
                                  size={14}
                                  className="group-hover:animate-pulse"
                                />{" "}
                                Force Purge Record
                              </button>
                            )}

                            <p className="text-[9px] theme-text-muted italic px-1">
                              Purging a record will disconnect the user from the
                              Bureau database permanently.
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {/* Tab 3: Audit */}
            {activeTab === "audit" && (
              <motion.div
                key="audit"
                className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full min-h-0"
              >
                <div className="flex flex-col theme-bg-secondary border theme-border h-full overflow-hidden shadow-sm">
                  <div className="p-4 border-b theme-border theme-bg-primary flex justify-between items-center">
                    <h2 className="text-xs font-bold uppercase tracking-widest theme-text-primary flex items-center gap-2 text-wrap">
                      Global Forecast Stream
                    </h2>
                    <span className="text-[10px] font-mono theme-text-muted hidden sm:inline">
                      Last 50 Transmissions
                    </span>
                  </div>
                  <div
                    className={`flex-1 overflow-auto p-2 space-y-2 ${selectedForecast ? "hidden lg:block" : "block"}`}
                  >
                    {globalForecasts.map((f) => (
                      <button
                        key={f.id}
                        onClick={() => setSelectedForecast(f)}
                        className={`w-full text-left p-4 border transition-all ${
                          selectedForecast?.id === f.id
                            ? "bg-indigo-50 border-indigo-300"
                            : "theme-bg-secondary theme-border hover:theme-bg-primary"
                        }`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <span className="font-bold text-sm theme-text-primary">
                            {f.location}
                          </span>
                          {f.status === "completed" ? (
                            <CheckCircle
                              size={14}
                              className="text-emerald-500"
                            />
                          ) : (
                            <Clock size={14} className="text-amber-500" />
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-[10px] theme-text-muted font-mono uppercase tracking-widest">
                          <span>Analyst ID: {f.userId.slice(0, 8)}...</span>
                          <span>Target: {f.targetDate}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div
                  className={`theme-bg-secondary border theme-border shadow-sm flex flex-col items-center justify-center p-6 lg:p-12 text-center overflow-auto ${!selectedForecast ? "hidden lg:flex" : "flex"}`}
                >
                  {selectedForecast ? (
                    <div className="w-full text-left">
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-bold theme-text-primary flex items-center gap-2">
                          <Filter size={18} className="text-indigo-600" />{" "}
                          Auditor Overrides
                        </h3>
                        <button
                          onClick={() => setSelectedForecast(null)}
                          className="lg:hidden p-2 text-xs font-bold uppercase tracking-widest border theme-border theme-bg-primary"
                        >
                          Back
                        </button>
                      </div>

                      {/* Enhanced Context View */}
                      <div className="mb-8 space-y-6">
                        <div className="p-4 theme-bg-primary border theme-border rounded-sm">
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h4 className="text-sm font-bold theme-text-primary text-indigo-600 uppercase tracking-tight">
                                {selectedForecast.location}
                              </h4>
                              <p className="text-[10px] theme-text-muted uppercase tracking-[0.2em] font-mono mt-0.5">
                                {selectedForecast.targetDate}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="text-xs font-bold theme-text-primary">
                                {selectedForecast.predictedCondition ||
                                  "Sky Normal"}
                              </div>
                              <div className="text-[9px] theme-text-muted font-mono mt-1 opacity-60">
                                REF: {selectedForecast.id.slice(0, 10)}
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-3 mb-4">
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Wind size={10} className="theme-text-muted mb-1" />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                Wind Speed
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.windSpeed || 0}
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Wind size={10} className="text-amber-400 mb-1" />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                Wind Gusts
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.windGusts || 0}
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Droplets
                                size={10}
                                className="theme-text-muted mb-1"
                              />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                Humidity
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.humidity || 0}%
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Activity
                                size={10}
                                className="theme-text-muted mb-1"
                              />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                UV Index
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.uvIndex || 0}
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Cloud size={10} className="text-blue-400 mb-1" />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                Precip Vol
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.precip || 0}
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Cloud
                                size={10}
                                className="theme-text-muted mb-1"
                              />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                Pressure
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.pressure || 0}
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Zap size={10} className="text-orange-500 mb-1" />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                CAPE
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.cape || 0}
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <Wind size={10} className="text-red-500 mb-1" />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                Shear
                              </span>
                              <span className="text-xs font-mono font-bold">
                                {selectedForecast.shear || 0}
                              </span>
                            </div>
                            <div className="p-2 theme-bg-secondary border theme-border flex flex-col items-center">
                              <MapPin
                                size={10}
                                className="text-indigo-400 mb-1"
                              />
                              <span className="text-[8px] font-bold theme-text-muted uppercase tracking-tighter text-center">
                                Coords
                              </span>
                              <span className="text-[9px] font-mono font-bold truncate w-full text-center">
                                {typeof selectedForecast.lat === 'number' && typeof selectedForecast.lon === 'number'
                                  ? `${selectedForecast.lat.toFixed(2)},${selectedForecast.lon.toFixed(2)}`
                                  : "N/A"}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 mb-4">
                            <div className="p-3 theme-bg-secondary border theme-border">
                              <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest block mb-1">
                                Analyst Performance
                              </span>
                              <div className="text-lg font-bold text-indigo-600 flex items-center gap-2">
                                <Thermometer size={14} />{" "}
                                {selectedForecast.highTemp}° /{" "}
                                {selectedForecast.lowTemp}°
                              </div>
                            </div>
                            <div className="p-3 theme-bg-secondary border theme-border">
                              <span className="text-[9px] font-bold theme-text-muted uppercase tracking-widest block mb-1">
                                Model Accuracy
                              </span>
                              <div className="text-lg font-bold theme-text-primary">
                                {selectedForecast.modelGrade?.score || "N/A"}%
                              </div>
                            </div>
                          </div>

                          {selectedForecast.modelGrade?.feedback && (
                            <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-sm">
                              <div className="text-[8px] font-bold text-indigo-400 uppercase tracking-widest mb-1 flex items-center gap-1">
                                <Activity size={10} /> Automated Analysis
                              </div>
                              <p className="text-[10px] text-indigo-800 leading-relaxed italic line-clamp-3">
                                "{selectedForecast.modelGrade.feedback}"
                              </p>
                            </div>
                          )}
                        </div>

                        <div className="space-y-4 pt-4 border-t theme-border">
                          <div className="p-4 theme-bg-primary border-2 border-dashed border-indigo-200 dark:border-indigo-900/50 space-y-4">
                            <div className="flex items-center justify-between">
                              <h4 className="text-[10px] font-bold uppercase tracking-widest text-indigo-600">Atmospheric AI Verification</h4>
                              <span className="text-[9px] font-mono theme-text-muted italic">Neural Ground Truth Search</span>
                            </div>
                            <p className="text-[10px] theme-text-secondary leading-relaxed">
                              Trigger an automated tactical search for real-world telemetry (Ground Truth) to provide high-precision grading for this analyst report.
                            </p>
                            <button
                              onClick={handleAutoVerify}
                              disabled={isSaving}
                              className="w-full py-3 theme-bg-secondary border border-indigo-500 text-indigo-600 font-bold text-[10px] uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center gap-2"
                            >
                              {isSaving ? <Loader2 size={12} className="animate-spin" /> : <SearchCode size={12} />}
                              Automated Verify via Grounding
                            </button>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                                Final Precision Allocation (0-100)
                              </label>
                              <input
                                type="number"
                                value={manualGrade.score}
                                onChange={(e) =>
                                  setManualGrade({
                                    ...manualGrade,
                                    score: Number(e.target.value),
                                  })
                                }
                                className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600"
                              />
                            </div>
                            <div>
                               <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                                Status Override
                               </label>
                               <div className="flex items-center h-[46px] px-2 theme-bg-primary border theme-border text-[10px] font-bold uppercase tracking-widest theme-text-secondary">
                                 {selectedForecast.status}
                               </div>
                            </div>
                          </div>
                          <div>
                            <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                              Internal Audit Log / Feedback
                            </label>
                            <textarea
                              placeholder="Specify reasoning for manual override..."
                              value={manualGrade.feedback}
                              onChange={(e) =>
                                setManualGrade({
                                  ...manualGrade,
                                  feedback: e.target.value,
                                })
                              }
                              className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600 min-h-[100px]"
                            />
                          </div>
                          <button
                            onClick={handleManualGrade}
                            disabled={isSaving}
                            className="w-full py-4 bg-slate-900 text-white font-bold text-[10px] uppercase tracking-[0.2em] shadow-[4px_4px_0px_#cbd5e1] hover:-translate-y-0.5 active:translate-y-0.5 transition-all flex items-center justify-center gap-2"
                          >
                            {isSaving
                              ? "Processing Overrides..."
                              : "Authorize Manual Grade"}
                            <Database size={12} className="ml-2" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="theme-text-muted">
                      <CheckCircle
                        size={48}
                        className="mx-auto mb-4 opacity-20"
                      />
                      <p className="text-sm">
                        Select a transmission from the stream to audit.
                      </p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Tab 4: News (Announcements) */}
            {activeTab === "news" && (
              <motion.div
                key="news"
                className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full"
              >
                <div className="theme-bg-secondary border theme-border p-8 shadow-sm">
                  <h2 className="text-lg font-bold theme-text-primary mb-6 flex items-center gap-2">
                    <Radio size={18} className="text-indigo-600" />{" "}
                    Administrative Announcements
                  </h2>
                  <div className="space-y-6">
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                        Subject Header
                      </label>
                      <input
                        type="text"
                        value={newAnnouncement.title}
                        onChange={(e) =>
                          setNewAnnouncement({
                            ...newAnnouncement,
                            title: e.target.value,
                          })
                        }
                        className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600"
                        placeholder="e.g. CAMPAIGN ACCURACY VARIANCE"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                        Announcement Content
                      </label>
                      <textarea
                        value={newAnnouncement.content}
                        onChange={(e) =>
                          setNewAnnouncement({
                            ...newAnnouncement,
                            content: e.target.value,
                          })
                        }
                        className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600 min-h-[150px]"
                        placeholder="Specific updates for the Analyst team..."
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">
                        Expiration Date (Optional)
                      </label>
                      <input
                        type="datetime-local"
                        value={newAnnouncement.expiresAt}
                        onChange={(e) =>
                          setNewAnnouncement({
                            ...newAnnouncement,
                            expiresAt: e.target.value,
                          })
                        }
                        className="w-full theme-bg-primary border theme-border p-3 text-sm outline-none focus:border-indigo-600 font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {["info", "warning", "critical"].map((t) => (
                        <button
                          key={t}
                          onClick={() =>
                            setNewAnnouncement({ ...newAnnouncement, type: t })
                          }
                          className={`py-2 text-[10px] font-bold uppercase tracking-widest border transition-all ${
                            newAnnouncement.type === t
                              ? "bg-slate-900 text-white border-slate-900"
                              : "theme-bg-secondary theme-text-muted theme-border hover:theme-bg-primary"
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={handlePostAnnouncement}
                      disabled={isSaving}
                      className="w-full py-4 bg-red-600 text-white font-bold text-[10px] uppercase tracking-[0.2em] shadow-[4px_4px_0px_#991b1b] hover:bg-red-700 transition-all"
                    >
                      {isSaving ? "Broadcasting..." : "Broadcast Transmission"}
                    </button>
                  </div>
                </div>

                <div className="theme-bg-secondary border theme-border p-8 shadow-sm flex flex-col overflow-hidden">
                  <h2 className="text-[10px] font-bold uppercase tracking-widest theme-text-muted mb-6">
                    Current active Broadcasts
                  </h2>
                  <div className="flex-1 overflow-auto space-y-4 pr-2">
                    {announcements.map((ann) => (
                      <div
                        key={ann.id}
                        className="p-4 border theme-border theme-bg-primary relative group"
                      >
                        <button
                          onClick={() => deleteAnnouncement(ann.id)}
                          className="absolute top-4 right-4 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                        >
                          <Trash2 size={14} />
                        </button>
                        <div className="flex items-center gap-2 mb-2">
                          <div
                            className={`w-2 h-2 rounded-full ${
                              ann.type === "critical"
                                ? "bg-red-500 animate-pulse"
                                : ann.type === "warning"
                                  ? "bg-amber-500"
                                  : "bg-indigo-500"
                            }`}
                          />
                          <span className="text-[10px] font-bold uppercase tracking-widest theme-text-muted font-mono">
                            {ann.type} //{" "}
                            {ann.createdAt
                              ? new Date(
                                  ann.createdAt?.toDate
                                    ? ann.createdAt.toDate()
                                    : ann.createdAt,
                                ).toLocaleDateString()
                              : "LIVE"}
                            {ann.expiresAt &&
                              ` // EXPIRES: ${new Date(ann.expiresAt?.toDate ? ann.expiresAt.toDate() : ann.expiresAt).toLocaleString()}`}
                          </span>
                        </div>
                        <h3 className="font-bold theme-text-primary mb-1">
                          {ann.title}
                        </h3>
                        <p className="text-xs theme-text-secondary line-clamp-2">
                          {ann.content}
                        </p>
                      </div>
                    ))}
                    {announcements.length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center text-slate-300">
                        <Radio size={48} className="mb-4 opacity-10" />
                        <p className="text-xs">
                          No active broadcasts currently transmitting.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Tab 5: Support (Previously implemented tickets) */}
            {activeTab === "support" && (
              <motion.div
                key="support"
                className="flex flex-col lg:flex-row gap-8 flex-1 min-h-0"
              >
                {/* Ticket Queue */}
                <div
                  className={`w-full lg:w-1/3 flex flex-col theme-bg-secondary border theme-border overflow-hidden shadow-sm ${selectedTicket ? "hidden lg:flex" : "flex"}`}
                >
                  <div className="p-4 border-b theme-border theme-bg-primary flex justify-between items-center shrink-0">
                    <h2 className="text-xs font-bold uppercase tracking-widest theme-text-primary flex items-center gap-2 whitespace-nowrap">
                      <MessageSquare size={14} className="text-indigo-600" />{" "}
                      Support Queue
                    </h2>
                    <div className="flex theme-bg-secondary border theme-border p-0.5 rounded">
                      {(["all", "open", "resolved"] as const).map((f) => (
                        <button
                          key={f}
                          onClick={() => setSupportFilter(f)}
                          className={`px-2 py-0.5 text-[8px] font-bold uppercase tracking-tighter transition-all ${
                            supportFilter === f
                              ? "bg-slate-900 text-white"
                              : "theme-text-muted hover:theme-text-secondary"
                          }`}
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto overflow-x-hidden p-2 space-y-2">
                    {filteredTickets.length === 0 ? (
                      <div className="text-center py-8 text-xs theme-text-muted italic opacity-50">
                        No tickets match criteria.
                      </div>
                    ) : (
                      filteredTickets.map((ticket) => (
                        <button
                          key={ticket.id}
                          onClick={() => {
                            setSelectedTicket(ticket);
                            setReplyText(ticket.adminReply || "");
                            setTicketStatus(ticket.status || "open");
                          }}
                          className={`w-full text-left p-4 border transition-all flex flex-col gap-2 ${
                            selectedTicket?.id === ticket.id
                              ? "bg-indigo-50 border-indigo-300 shadow-sm"
                              : "theme-bg-secondary theme-border hover:theme-bg-primary"
                          }`}
                        >
                          <div className="flex justify-between items-start gap-2">
                            <span className="font-bold text-sm theme-text-primary truncate">
                              {ticket.subject}
                            </span>
                            <span
                              className={`w-2 h-2 rounded-full shrink-0 mt-1 ${
                                ticket.status === "open"
                                  ? "bg-amber-500"
                                  : ticket.status === "in_progress"
                                    ? "bg-blue-500"
                                    : "bg-emerald-500"
                              }`}
                            />
                          </div>
                          <div className="text-[10px] theme-text-muted truncate">
                            {getAnalystEmail(ticket.userId)}
                          </div>
                          <div className="text-[10px] theme-text-muted font-mono">
                            {ticket.createdAt
                              ? new Date(
                                  ticket.createdAt?.toDate
                                    ? ticket.createdAt.toDate()
                                    : ticket.createdAt,
                                ).toLocaleDateString()
                              : ""}
                          </div>
                        </button>
                      ))
                    )}
                  </div>
                </div>

                {/* Ticket Detail */}
                <div
                  className={`flex-1 theme-bg-secondary border theme-border shadow-sm overflow-y-auto relative flex flex-col ${!selectedTicket ? "hidden lg:flex" : "flex"}`}
                >
                  {selectedTicket ? (
                    <div className="flex flex-col h-full">
                      {/* Header */}
                      <div className="p-6 border-b theme-border shrink-0">
                        <div className="flex justify-between items-start gap-4 mb-4">
                          <div>
                            <h2 className="text-xl font-bold theme-text-primary">
                              {selectedTicket.subject}
                            </h2>
                            <div className="text-xs theme-text-muted font-mono mt-2">
                              Ticket ID: {selectedTicket.id}
                            </div>
                          </div>
                          <button
                            onClick={() => setSelectedTicket(null)}
                            className="lg:hidden p-2 text-xs font-bold uppercase tracking-widest border theme-border theme-bg-primary"
                          >
                            Back
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-4 text-xs">
                          <div className="theme-text-secondary">
                            <span className="font-bold uppercase tracking-wider text-[10px] theme-text-muted block mb-1">
                              Analyst
                            </span>{" "}
                            {getAnalystEmail(selectedTicket.userId)}
                          </div>
                          <div className="theme-text-secondary">
                            <span className="font-bold uppercase tracking-wider text-[10px] theme-text-muted block mb-1">
                              Submitted
                            </span>{" "}
                            {selectedTicket.createdAt
                              ? new Date(
                                  selectedTicket.createdAt?.toDate
                                    ? selectedTicket.createdAt.toDate()
                                    : selectedTicket.createdAt,
                                ).toLocaleString()
                              : "N/A"}
                          </div>
                        </div>
                      </div>

                      {/* Original Message */}
                      <div className="p-6 border-b theme-border theme-bg-primary shrink-0">
                        <span className="font-bold uppercase tracking-wider text-[10px] theme-text-muted block mb-2">
                          Original Transmission
                        </span>
                        <p className="text-sm theme-text-primary whitespace-pre-wrap">
                          {selectedTicket.description}
                        </p>
                      </div>

                      {/* Admin Actions */}
                      <div className="p-6 flex-1 flex flex-col gap-6">
                        <div>
                          <label className="font-bold uppercase tracking-wider text-[10px] theme-text-muted block mb-2">
                            Status
                          </label>
                          <select
                            value={ticketStatus}
                            onChange={(e) => setTicketStatus(e.target.value)}
                            className="theme-bg-secondary border theme-border text-sm px-3 py-2 outline-none focus:border-indigo-600"
                          >
                            <option value="open">Open</option>
                            <option value="in_progress">In Progress</option>
                            <option value="resolved">Resolved</option>
                          </select>
                        </div>

                        <div className="flex-1 flex flex-col">
                          <label className="font-bold uppercase tracking-wider text-[10px] text-indigo-600 block mb-2">
                            Response Content
                          </label>
                          <textarea
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            className="flex-1 w-full border border-indigo-200 bg-indigo-50/30 p-4 text-sm resize-none outline-none focus:border-indigo-600"
                            placeholder="Draft a response to the analyst..."
                          />
                        </div>

                        <div className="shrink-0 flex justify-end gap-3">
                          {ticketStatus !== "resolved" && (
                            <button
                              onClick={async () => {
                                const targetId = selectedTicket.id;
                                setIsSaving(true);

                                // Optimistic
                                if (supportFilter === "open") {
                                  setTickets((prev) =>
                                    prev.filter((t) => t.id !== targetId),
                                  );
                                }

                                try {
                                  await updateDoc(
                                    doc(db, "supportTickets", targetId),
                                    {
                                      adminReply: replyText.trim(),
                                      status: "resolved",
                                    },
                                  );
                                  setReplyText("");
                                  setSelectedTicket(null);
                                } catch (err) {
                                  console.error(err);
                                  alert("Resolution update failed.");
                                } finally {
                                  setIsSaving(false);
                                }
                              }}
                              disabled={isSaving}
                              className="px-6 py-3 text-[11px] font-bold uppercase tracking-widest border border-emerald-200 text-emerald-600 hover:bg-emerald-50 transition-all font-mono disabled:opacity-50"
                            >
                              Quick Resolve
                            </button>
                          )}
                          <button
                            onClick={handleSaveTicket}
                            disabled={isSaving}
                            className={`flex items-center gap-2 px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-all shadow-[4px_4px_0px_#cbd5e1] ${
                              isSaving
                                ? "bg-slate-300 theme-text-muted cursor-not-allowed"
                                : "bg-slate-900 text-white hover:bg-slate-800"
                            }`}
                          >
                            {isSaving ? "Processing..." : "Submit Response"}
                            {!isSaving && <Save size={14} />}
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex items-center justify-center theme-text-muted">
                      <div className="text-center">
                        <Shield size={48} className="mx-auto mb-4 opacity-20" />
                        <p className="text-sm">
                          Select a support ticket to interact.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Tab 6: Feedback */}
            {activeTab === "feedback" && (
              <motion.div
                key="feedback"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="theme-bg-secondary border theme-border flex flex-col h-full min-h-[900px] overflow-hidden shadow-sm relative"
              >
                <div className="p-4 border-b theme-border theme-bg-primary flex justify-between items-center shrink-0">
                  <h2 className="text-xs font-bold uppercase tracking-widest theme-text-primary flex items-center gap-2">
                    <Bug size={14} className="text-indigo-600" />{" "}
                    Beta Feedback Terminal
                  </h2>
                  <div className="flex items-center gap-4">
                    <span className="text-[10px] font-mono theme-text-muted">
                      {feedback.length} TRANSMISSIONS RECORDED
                    </span>
                    <button 
                      onClick={async () => {
                        const feedbackRef = query(collection(db, "betaFeedback"), orderBy("timestamp", "desc"), limit(100));
                        const snap = await getDocs(feedbackRef);
                        setFeedback(snap.docs.map((d: any) => ({ id: d.id, ...d.data() })).filter((f: any) => f.status !== 'archived'));
                      }}
                      className="p-1.5 hover:bg-slate-200 rounded transition-colors theme-text-muted hover:text-indigo-600"
                      title="Force Refresh"
                    >
                      <RefreshCw size={12} />
                    </button>
                  </div>
                </div>
                
                <div className="flex-1 overflow-auto p-4">
                  <div className="max-w-5xl mx-auto">
                    <div className="grid grid-cols-1 gap-1">
                      {feedback.length === 0 ? (
                        <div className="py-20 flex flex-col items-center text-slate-300">
                          <Bug size={48} className="opacity-10 mb-4" />
                          <p className="text-sm">No feedback telemetry received yet.</p>
                        </div>
                      ) : (
                        <div className="theme-bg-secondary border theme-border divide-y divide-slate-100">
                          <div className="grid grid-cols-12 gap-4 p-4 theme-bg-primary text-[10px] font-bold uppercase tracking-widest theme-text-muted">
                            <div className="col-span-2">Type</div>
                            <div className="col-span-4">Description</div>
                            <div className="col-span-2">Contributor</div>
                            <div className="col-span-2">Timestamp</div>
                            <div className="col-span-2">Status</div>
                          </div>
                          {feedback.map((f) => (
                            <div
                              key={f.id}
                              className="relative w-full grid grid-cols-12 gap-4 p-4 hover:theme-bg-primary transition-colors text-left group items-center"
                            >
                              <button
                                className="absolute inset-0 z-0 w-full"
                                onClick={() => setSelectedFeedback(f)}
                                aria-label="View Transmission"
                              />
                              <div className="col-span-2 flex items-center pointer-events-none z-10 min-w-0">
                                <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest border ${
                                  f.type === 'bug' ? 'bg-red-50 text-red-600 border-red-100' :
                                  f.type === 'suggestion' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                                  'bg-emerald-50 text-emerald-600 border-emerald-100'
                                }`}>
                                  {f.type}
                                </span>
                              </div>
                              <div className="col-span-4 flex items-center pointer-events-none z-10 min-w-0">
                                <p className="text-[11px] theme-text-primary truncate font-mono">{f.description}</p>
                              </div>
                              <div className="col-span-2 flex items-center pointer-events-none z-10 min-w-0">
                                <span className="text-[10px] theme-text-muted truncate" title={f.userEmail}>{f.userEmail?.split('@')[0]}</span>
                              </div>
                              <div className="col-span-2 flex items-center pointer-events-none z-10 min-w-0">
                                <span className="text-[10px] font-mono theme-text-muted truncate">
                                  {f.timestamp ? (
                                    new Date(f.timestamp?.toDate ? f.timestamp.toDate() : f.timestamp).toLocaleDateString()
                                  ) : 'T_UNKNOWN'}
                                </span>
                              </div>
                              <div className="col-span-2 flex items-center justify-between pointer-events-none z-10 min-w-0">
                                <span className={`text-[9px] font-bold uppercase tracking-widest truncate mr-2 ${
                                  f.status === 'resolved' ? 'text-emerald-500' : 
                                  f.status === 'new' ? 'text-indigo-600' : 'theme-text-muted'
                                }`}>
                                  {f.status}
                                </span>
                                <ChevronRight size={14} className="text-slate-300 group-hover:translate-x-1 shrink-0 transition-transform" />
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Feedback Detail Overlay */}
                <AnimatePresence>
                  {selectedFeedback && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 z-50 theme-bg-secondary flex flex-col"
                    >
                      <div className="p-4 border-b theme-border bg-slate-900 text-white flex justify-between items-center shrink-0">
                        <div className="flex items-center gap-4">
                          <button 
                            onClick={() => setSelectedFeedback(null)}
                            className="p-1 hover:theme-bg-primary rounded-full transition-colors"
                          >
                            <ChevronLeft size={20} />
                          </button>
                          <div>
                            <h3 className="text-xs font-bold uppercase tracking-widest">Feedback Detail</h3>
                            <p className="text-[9px] font-mono theme-text-muted">REF: {selectedFeedback.id}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest border ${
                            selectedFeedback.type === 'bug' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                            selectedFeedback.type === 'suggestion' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                            'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          }`}>
                            {selectedFeedback.type}
                          </span>
                          <button
                            onClick={async (e) => {
                              if(!confirm("EXTREME_ACTION: Purge this entire transmission record and all associated diagnostic notes? This cannot be undone.")) return;
                              
                              const btn = e.currentTarget;
                              const originalInner = btn.innerHTML;
                              btn.disabled = true;
                              btn.innerHTML = '<span class="animate-spin inline-block">⏳</span>';
                              console.log(`[BETA_FEEDBACK] Triggering delete for feedback ID: ${selectedFeedback.id}`);
                              
                              try {
                                // 1. Purge associated notes first (clean up dependencies)
                                console.log(`[BETA_FEEDBACK] Deleting/Archiving associated notes...`);
                                const notesQuery = query(collection(db, "betaFeedbackNotes"), where("feedbackId", "==", selectedFeedback.id));
                                const notesSnap = await getDocs(notesQuery);
                                for (const noteDoc of notesSnap.docs) {
                                  try {
                                    await deleteDoc(doc(db, "betaFeedbackNotes", noteDoc.id));
                                  } catch (e) {
                                    await updateDoc(doc(db, "betaFeedbackNotes", noteDoc.id), { status: 'archived' });
                                  }
                                }
                                
                                // 2. Purge the main record
                                console.log(`[BETA_FEEDBACK] Deleting main feedback record...`);
                                try {
                                  await deleteDoc(doc(db, "betaFeedback", selectedFeedback.id));
                                } catch (e) {
                                  await updateDoc(doc(db, "betaFeedback", selectedFeedback.id), { status: 'archived' });
                                }
                                
                                // 3. Immediate local state cleanup for instant UI response
                                console.log(`[BETA_FEEDBACK] Delete complete. Updating UI.`);
                                setFeedback(prev => prev.filter(f => f.id !== selectedFeedback.id));
                                setSelectedFeedback(null);
                              } catch (err: any) { 
                                console.error("Purge Error:", err);
                                alert("PURGE_FAILURE: " + (err.message || "Unknown data integrity fault during transmission deletion. Check logs."));
                                btn.disabled = false;
                                btn.innerHTML = originalInner;
                              }
                            }}
                            className="p-2 hover:bg-red-500/20 text-red-400 rounded-full transition-colors"
                            title="Delete"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>

                      <div className="flex-1 overflow-auto theme-bg-primary">
                        <div className="max-w-[1400px] mx-auto p-6 lg:p-12 grid grid-cols-1 lg:grid-cols-12 gap-10">
                          {/* Main Content */}
                          <div className="lg:col-span-9 space-y-10">
                            <div className="theme-bg-secondary border theme-border p-8 shadow-sm">
                              <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-6">Initial Transmission</label>
                              <p className="text-base theme-text-primary leading-relaxed font-mono whitespace-pre-wrap">
                                {selectedFeedback.description}
                              </p>
                            </div>

                            <div className="space-y-6">
                              <label className="text-xs font-bold uppercase tracking-widest theme-text-muted block pb-2 border-b theme-border">Activity Log & Remediation History</label>
                              
                              <div className="space-y-4">
                                {feedbackNotes
                                  .filter(n => n.feedbackId === selectedFeedback.id)
                                  .sort((a, b) => {
                                    const tA = a.timestamp?.toDate ? a.timestamp.toDate().getTime() : new Date(a.timestamp).getTime();
                                    const tB = b.timestamp?.toDate ? b.timestamp.toDate().getTime() : new Date(b.timestamp).getTime();
                                    return tA - tB;
                                  })
                                  .map((note) => (
                                    <motion.div 
                                      key={note.id}
                                      initial={{ opacity: 0, y: 10 }}
                                      animate={{ opacity: 1, y: 0 }}
                                      className="p-6 theme-bg-secondary border theme-border shadow-sm group relative"
                                    >
                                      <div className="flex justify-between items-center mb-4 pb-3 border-b theme-border">
                                        <div className="flex items-center gap-3">
                                          <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                                          <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">
                                            {note.adminEmail === currentUser?.email ? "YOU (SUPER_USER)" : note.adminEmail?.split('@')[0].toUpperCase()}
                                          </span>
                                        </div>
                                        <span className="text-[10px] font-mono theme-text-muted">
                                          {note.timestamp ? (
                                            new Date(note.timestamp?.toDate ? note.timestamp.toDate() : note.timestamp).toLocaleString()
                                          ) : 'T_SHALE'}
                                        </span>
                                      </div>
                                      <p className="text-sm theme-text-primary font-mono leading-relaxed whitespace-pre-wrap">
                                        {note.content}
                                      </p>
                                      <button 
                                        onClick={async () => {
                                          if(!confirm("Remove this entry?")) return;
                                          try {
                                            await deleteDoc(doc(db, "betaFeedbackNotes", note.id));
                                          } catch (err) { console.error(err); }
                                        }}
                                        className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 text-slate-300 hover:text-red-500 transition-opacity p-2"
                                      >
                                        <X size={16} />
                                      </button>
                                    </motion.div>
                                  ))}
                              </div>

                              <div className="theme-bg-secondary p-8 border-2 border-dashed theme-border rounded-xl">
                                <textarea
                                  id={`new-note-overlay-${selectedFeedback.id}`}
                                  placeholder="Append diagnostic report, attach remediation status, or log resolution metrics..."
                                  onInput={(e) => {
                                    const target = e.target as HTMLTextAreaElement;
                                    target.style.height = 'auto';
                                    target.style.height = target.scrollHeight + 'px';
                                  }}
                                  className="w-full p-6 theme-bg-primary border theme-border text-sm font-mono focus:ring-1 focus:ring-indigo-500 outline-none resize-none min-h-[150px] mb-6 shadow-inner overflow-hidden"
                                />
                                <div className="flex justify-end">
                                  <button
                                    onClick={async (e) => {
                                      const textarea = document.getElementById(`new-note-overlay-${selectedFeedback.id}`) as HTMLTextAreaElement;
                                      if (!textarea || !textarea.value.trim()) return;
                                      const btn = e.currentTarget;
                                      const originalText = "Commit Transmission Block";
                                      
                                      try {
                                        btn.disabled = true;
                                        btn.innerHTML = 'COMMITTING... <span class="animate-spin inline-block">⏳</span>';
                                        
                                        await addDoc(collection(db, "betaFeedbackNotes"), {
                                          feedbackId: selectedFeedback.id,
                                          adminId: currentUser?.uid,
                                          adminEmail: currentUser?.email,
                                          content: textarea.value.trim(),
                                          timestamp: serverTimestamp()
                                        });
                                        
                                        textarea.value = "";
                                        textarea.style.height = 'auto';
                                        btn.innerHTML = '✓ SUCCESS: DATA_PERSISTED <span class="ml-2">📂</span>';
                                        setTimeout(() => { 
                                          btn.disabled = false;
                                          btn.innerHTML = `Commit Transmission Block <Save size={16} />`; 
                                        }, 2000);
                                      } catch (err: any) { 
                                        console.error("Transmission Error:", err);
                                        alert("PERSISTENCE_FAULT: " + (err.message || "Unknown database rejection."));
                                        btn.disabled = false;
                                        btn.innerHTML = `Commit Transmission Block <Save size={16} />`;
                                      }
                                    }}
                                    className="py-4 px-8 bg-slate-900 text-white text-[11px] font-bold uppercase tracking-widest hover:bg-indigo-600 hover:shadow-lg transition-all flex items-center gap-3"
                                  >
                                    Commit Transmission Block <Save size={16} />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Sidebar Info */}
                          <div className="lg:col-span-3 space-y-8">
                            <div className="theme-bg-secondary border theme-border p-6 space-y-6 shadow-sm">
                              <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block border-b theme-border pb-3">Status Control</label>
                              
                              <div className="space-y-2">
                                <span className="text-[9px] font-bold theme-text-muted uppercase tracking-tighter">Current Lifecycle State</span>
                                <select 
                                  value={selectedFeedback.status}
                                  onChange={async (e) => {
                                    const newStatus = e.target.value;
                                    try {
                                      await updateDoc(doc(db, "betaFeedback", selectedFeedback.id), { 
                                        status: newStatus,
                                        updatedAt: serverTimestamp()
                                      });
                                      setSelectedFeedback(prev => prev ? ({ ...prev, status: newStatus }) : null);
                                      // Immediate reflection in the list
                                      setFeedback(prev => prev.map(f => f.id === selectedFeedback.id ? { ...f, status: newStatus } : f));
                                    } catch (err) { console.error("Status Update Error:", err); }
                                  }}
                                  className="w-full theme-bg-primary border theme-border text-xs font-bold uppercase p-4 outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500"
                                >
                                  <option value="new">New / Unread</option>
                                  <option value="investigating">Investigating</option>
                                  <option value="scheduled">Scheduled</option>
                                  <option value="resolved">Resolved</option>
                                  <option value="dismissed">Dismissed</option>
                                </select>
                              </div>

                              <div className="space-y-2">
                                <span className="text-[9px] font-bold theme-text-muted uppercase tracking-tighter">Contributor Identifier</span>
                                <div className="text-xs theme-text-primary font-mono theme-bg-primary p-4 border theme-border truncate shadow-sm">
                                  {selectedFeedback.userEmail}
                                </div>
                              </div>
                            </div>

                            <div className="theme-bg-secondary border theme-border p-6 space-y-6 shadow-sm">
                              <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block border-b theme-border pb-3">Environment Diagnostics</label>
                              
                              <div className="space-y-2">
                                <span className="text-[9px] font-bold theme-text-muted uppercase tracking-tighter">Target Resource Path</span>
                                <div className="text-[10px] theme-text-primary font-mono theme-bg-primary p-3 border theme-border break-all leading-relaxed">
                                  {selectedFeedback.path}
                                </div>
                              </div>

                              <div className="space-y-2">
                                <span className="text-[9px] font-bold theme-text-muted uppercase tracking-tighter">Agent Hardware Header</span>
                                <div className="text-[10px] theme-text-muted font-mono theme-bg-primary p-3 border theme-border italic leading-relaxed">
                                  {selectedFeedback.userAgent}
                                </div>
                              </div>

                              <div className="space-y-2 pt-2 border-t theme-border">
                                <span className="text-[9px] font-bold theme-text-muted uppercase tracking-tighter">Relay Timestamp</span>
                                <div className="text-xs theme-text-primary font-mono">
                                  {selectedFeedback.timestamp ? (
                                    new Date(selectedFeedback.timestamp?.toDate ? selectedFeedback.timestamp.toDate() : selectedFeedback.timestamp).toLocaleString()
                                  ) : 'T_UNKNOWN'}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
