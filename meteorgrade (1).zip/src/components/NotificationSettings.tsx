import { useState, useEffect } from 'react';
import { Radio, Bell, Loader2, CheckCircle2, ShieldAlert } from 'lucide-react';
import { requestNotificationPermission, registerPushSubscription, unregisterPushSubscription } from '../services/notificationService';
import { doc, onSnapshot, setDoc, db } from '../lib/db';

interface NotificationSettingsProps {
  user: any;
}

export function NotificationSettings({ user }: NotificationSettingsProps) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [isEnabled, setIsEnabled] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    if (!user) return;
    
    // Listen for server-side status updates
    const unsub = onSnapshot(doc(db, 'users', user.uid), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setIsEnabled(data?.notificationsEnabled || false);
      }
    });

    if ('Notification' in window) {
      setPermission(Notification.permission);
    }

    return () => unsub();
  }, [user]);

  const handleToggle = async () => {
    setStatus('loading');
    
    if (isEnabled) {
      const success = await unregisterPushSubscription(user.uid);
      if (success) {
        setIsEnabled(false);
        setStatus('idle');
      } else {
        setStatus('error');
      }
      return;
    }
    
    const granted = await requestNotificationPermission();
    if (!granted) {
      setStatus('error');
      setPermission('denied');
      return;
    }

    const success = await registerPushSubscription(user.uid);
    if (success) {
      try {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const userRef = doc(db, 'users', user.uid);
        await setDoc(userRef, { timezone }, { merge: true });
      } catch (err) {
        console.warn('[Push] Could not sync local timezone (column might be missing):', err);
      }

      setStatus('success');
      setIsEnabled(true);
      setTimeout(() => setStatus('idle'), 3000);
    } else {
      setStatus('error');
    }
  };

  return (
    <div className="theme-bg-secondary border theme-border p-8 shadow-[12px_12px_0px_#f8fafc] space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest bg-indigo-50 px-2 py-0.5">Communication Priority</span>
            {isEnabled && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 animate-pulse">
                <Radio className="w-3 h-3" /> Satellite Online
              </span>
            )}
          </div>
          <h3 className="text-xl font-light tracking-tighter uppercase">Analyst <span className="font-bold">Notification Hub</span></h3>
          <p className="theme-text-muted text-xs leading-relaxed max-w-sm">
            Enable high-priority push signals for daily briefing reminders and localized severe weather alerts.
          </p>
        </div>
        <div className={`p-4 rounded-full ${isEnabled ? 'theme-bg-secondary theme-text-primary border theme-border' : 'theme-bg-primary theme-text-muted'}`}>
          <Bell size={24} />
        </div>
      </div>

      <div className="space-y-4 pt-4 border-t border-slate-50">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <p className="text-[11px] font-bold theme-text-primary uppercase tracking-wider">Background Synchronization</p>
            <p className="text-[10px] theme-text-muted">Receive alerts even when the terminal is offline.</p>
          </div>
          <button 
            onClick={handleToggle}
            disabled={status === 'loading' || (permission === 'denied' && !isEnabled)}
            className={`
              relative inline-flex h-6 w-12 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
              ${isEnabled ? 'bg-indigo-600' : 'theme-bg-input'}
              ${(status === 'loading' || permission === 'denied') ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
            `}
          >
            <span 
              className={`
                inline-block h-4 w-4 transform rounded-full bg-white transition-transform shadow-sm
                ${isEnabled ? 'translate-x-7' : 'translate-x-1'}
              `} 
            />
          </button>
        </div>

        {status === 'loading' && (
          <div className="flex items-center gap-2 text-[10px] text-indigo-600 font-bold animate-pulse">
            <Loader2 className="w-3 h-3 animate-spin" /> Synchronizing with Satellite Constellation...
          </div>
        )}

        {status === 'success' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[10px] text-emerald-600 font-bold">
              <CheckCircle2 className="w-3 h-3" /> Connection Established. Priority Alerts Active.
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={async () => {
                  try {
                    const r = await navigator.serviceWorker.ready;
                    const sub = await r.pushManager.getSubscription();
                    if (!sub) {
                      alert('No active signal found. Please toggle notifications off and then back on.');
                      return;
                    }
                    const res = await fetch('/api/notifications/broadcast', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        title: 'DAILY BRIEFING',
                        body: 'Submit your daily forecast.',
                        tokens: [JSON.stringify(sub)]
                      })
                    });
                    const data = await res.json();
                    if (data.failureCount > 0) {
                      const errMsg = data.recentErrors[0];
                      alert(`Signal integrity compromised. Error: ${errMsg}\n\nThis usually means you need to purge the stale signal.`);
                    } else {
                      alert('Transmission successful. Check your device.');
                    }
                  } catch (e: any) {
                    alert('Diagnostic Error: ' + e.message);
                  }
                }}
                className="text-[9px] font-bold text-indigo-600 uppercase border border-indigo-200 px-3 py-1 hover:bg-indigo-50 transition-colors"
              >
                Test Signal Integrity
              </button>
              <button
                onClick={() => {
                  if (confirm('This will purge all local notification data and force a fresh handshake. Proceed?')) {
                    localStorage.removeItem('mg_vapid_key');
                    window.location.reload();
                  }
                }}
                className="text-[9px] font-bold text-rose-600 uppercase border border-rose-200 px-3 py-1 hover:bg-rose-50 transition-colors"
              >
                Purge Stale Signal
              </button>
            </div>
          </div>
        )}

        {permission === 'denied' && (
          <div className="flex items-start gap-3 p-4 theme-bg-secondary border border-red-500/50">
            <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-red-900 uppercase">Signal Blocked</p>
              <p className="text-[9px] text-red-600 leading-relaxed">
                Browser notifications are disabled. To receive alerts, you must reset permissions in your browser settings and refresh the terminal.
              </p>
            </div>
          </div>
        )}

        {status === 'error' && permission !== 'denied' && (
          <div className="text-[10px] text-red-600 font-bold">
            Satellite Link Error: Could not synchronize token. Please retry.
          </div>
        )}
      </div>

      <div className="theme-bg-primary p-4 border-l-2 theme-border">
        <p className="text-[9px] theme-text-muted uppercase font-black tracking-widest leading-loose">
           Alert Policy: Severe weather notifications are triggered once per event cycle to prevent signal fatigue. Daily briefing prompts occur at 08:00 local time.
        </p>
      </div>
    </div>
  );
}
