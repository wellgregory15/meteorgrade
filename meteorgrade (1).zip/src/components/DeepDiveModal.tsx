import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Zap, Cpu, Activity, TrendingUp, ShieldCheck, FileText, Sparkles, AlertCircle } from 'lucide-react';
import { getDeepDiveAnalysis } from '../services/geminiService';
import { doc, updateDoc, db } from '../lib/db';

interface DeepDiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  forecast: any;
}

export default function DeepDiveModal({ isOpen, onClose, forecast }: DeepDiveModalProps) {
  const [analysis, setAnalysis] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen || !forecast) {
      setAnalysis(null);
      setError(null);
      return;
    }
    
    // Only generate if we don't have analysis OR the analysis is for a different forecast
    if (!analysis || analysis.forecastId !== forecast.id) {
      generateAnalysis();
    }
  }, [isOpen, forecast?.id]);

  const generateAnalysis = async () => {
    setLoading(true);
    setError(null);
    setAnalysis(null);
    try {
      if (forecast.deepDiveAnalysis) {
        setAnalysis({ ...forecast.deepDiveAnalysis, forecastId: forecast.id });
        setLoading(false);
        return;
      }

      const result = await getDeepDiveAnalysis(forecast);
      const newAnalysis = { ...result, forecastId: forecast.id };
      
      try {
        const updateData: any = {
          deepDiveAnalysis: result
        };
        
        if (forecast.type === 'flash' && result.overallScore !== undefined) {
           updateData.actualGrade = {
             ...(forecast.actualGrade || {}),
             score: result.overallScore,
             feedback: result.summary,
             gradedAt: new Date().toISOString()
           };
           updateData.status = 'completed';
        }
        
        await updateDoc(doc(db, 'forecasts', forecast.id), updateData);
      } catch (err) {
        console.warn("Failed to persist deep dive analysis", err);
      }
      
      setAnalysis(newAnalysis);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Deep Dive synthesis failed. The neural uplink is currently unstable.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/90 backdrop-blur-md"
          />
          
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-4xl theme-bg-secondary border-b-4 theme-border theme-shadow overflow-hidden flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="theme-bg-app p-6 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-4">
                <div className="p-2 theme-bg-primary rounded-sm">
                  <Zap size={20} className="theme-text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-black italic tracking-tighter theme-text-primary uppercase">AI Deep Dive Synthesis</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest">Protocol / Strategic-Analysis-v4</span>
                    <span className="text-[9px] font-mono theme-text-muted underline decoration-indigo-500/30 font-bold uppercase">Target: {forecast?.location}</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="theme-text-muted hover:theme-text-primary transition-colors p-2 hover:theme-bg-primary rounded-full"
              >
                <X size={24} />
              </button>
            </div>

            {/* Content Swath */}
            <div className="flex-1 overflow-y-auto p-8 md:p-12 space-y-12">
              {loading ? (
                <div className="py-32 flex flex-col items-center justify-center space-y-8">
                  <div className="relative">
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                      className="w-20 h-20 border-2 border-indigo-600 border-dashed rounded-full"
                    />
                    <Cpu size={32} className="absolute inset-0 m-auto text-indigo-600 animate-pulse" />
                  </div>
                  <div className="text-center space-y-2">
                    <p className="text-sm font-bold uppercase tracking-[0.3em] theme-text-primary">Synchronizing Telemetry Archives</p>
                    <p className="text-[10px] theme-text-muted uppercase tracking-widest font-mono">Reconstructing atmospheric anomalies...</p>
                    
                    <div className="w-64 h-1 theme-bg-primary mt-8 relative overflow-hidden">
                      <motion.div 
                        initial={{ x: '-100%' }}
                        animate={{ x: '100%' }}
                        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                        className="absolute inset-0 bg-indigo-600 w-1/2"
                      />
                    </div>
                  </div>
                </div>
              ) : error ? (
                <div className="py-20 text-center space-y-6">
                  <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4 border border-red-100">
                    <AlertCircle size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 uppercase tracking-tight italic">Intelligence Extraction Failed</h3>
                  <p className="text-slate-500 text-sm max-w-sm mx-auto leading-relaxed">{error}</p>
                  <button 
                    onClick={generateAnalysis}
                    className="px-8 py-3 bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-600 transition-all"
                  >
                    Retry Uplink
                  </button>
                </div>
              ) : analysis ? (
                <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
                  {/* Executive Summary */}
                  <section className="space-y-4">
                    <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 uppercase tracking-[0.2em] mb-4">
                      <FileText size={14} /> Executive Summary
                    </div>
                    <p className="text-2xl font-light leading-relaxed text-slate-900 border-l-4 border-indigo-600 pl-8 py-2">
                      {analysis.summary}
                    </p>
                  </section>

                  {/* Diagnostic Matrix */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <section className="bg-slate-50 p-8 border border-slate-200">
                      <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-900 mb-6 flex items-center gap-2 pb-4 border-b border-slate-200 uppercase">
                        <TrendingUp size={14} className="text-indigo-600" /> Accuracy Breakdown
                      </h3>
                      <div className="space-y-6">
                        {analysis.breakdown?.map((item: any, i: number) => (
                          <div key={i} className="space-y-2">
                            <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                              <span className="text-slate-500">{item.label}</span>
                              <span className={item.delta > 0 ? 'text-emerald-600' : 'text-red-500'}>
                                {item.delta > 0 ? '+' : ''}{item.delta}% Var.
                              </span>
                            </div>
                            <div className="h-1 bg-slate-200 relative overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${item.score}%` }}
                                transition={{ duration: 1, delay: i * 0.1 }}
                                className={`absolute inset-0 ${item.score > 80 ? 'bg-indigo-600' : 'bg-slate-400'}`}
                              />
                            </div>
                            <p className="text-[9px] text-slate-400 font-mono italic leading-relaxed">
                              {item.diagnostic}
                            </p>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="bg-slate-900 text-white p-8 border border-slate-800 shadow-xl">
                      <h3 className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 mb-6 flex items-center gap-2 pb-4 border-b border-indigo-500/20 uppercase">
                        <Sparkles size={14} className="text-indigo-400" /> Satellite Telemetry Overlays
                      </h3>
                      <div className="space-y-6">
                         {analysis.telemetry?.map((note: string, i: number) => (
                           <div key={i} className="flex gap-4 items-start group">
                             <div className="w-6 h-6 bg-indigo-500/10 border border-indigo-500/20 text-indigo-500 flex items-center justify-center text-[10px] font-mono shrink-0 group-hover:bg-indigo-500 group-hover:text-white transition-colors duration-300">
                               0{i+1}
                             </div>
                             <p className="text-xs text-slate-300 leading-relaxed font-mono italic opacity-80 group-hover:opacity-100 transition-opacity">
                               {note}
                             </p>
                           </div>
                         ))}
                      </div>
                    </section>
                  </div>

                  {/* Final Verdict */}
                  <div className="bg-indigo-50 border-2 border-indigo-600 p-8 flex flex-col md:flex-row items-center gap-8">
                     <div className="w-24 h-24 bg-white border-4 border-indigo-600 rounded-full flex items-center justify-center text-4xl font-black italic tracking-tighter text-indigo-600 shrink-0 shadow-lg">
                        {analysis.rank || 'A'}
                     </div>
                     <div className="space-y-2">
                        <h4 className="text-sm font-black uppercase tracking-widest text-slate-900 italic">Analyst Recommendation / Protocol {analysis.protocolCode || '72-X'}</h4>
                        <p className="text-xs text-slate-600 leading-relaxed font-mono">
                           {analysis.recommendation}
                        </p>
                     </div>
                  </div>
                </div>
              ) : null}
            </div>

            {/* Footer */}
            <div className="bg-slate-50 border-t border-slate-200 p-4 flex justify-between items-center shrink-0">
               <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={14} className="text-emerald-600" />
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Endorsed by G.M.B.</span>
                  </div>
               </div>
               <span className="text-[9px] font-mono text-slate-300 font-bold uppercase tracking-widest">
                  Process Time: {analysis?.processTime || '0.84ms'} // Latency: Min
               </span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
