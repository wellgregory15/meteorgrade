import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Moon, Sun, Lock } from 'lucide-react';
import { auth, db, doc, updateDoc } from '../lib/db';
import { usePreferences } from '../lib/preferences';

interface ProfileSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: any;
  setProfile: (profile: any) => void;
  theme: 'light' | 'dark' | 'amber' | 'cyberpunk';
  setTheme: (theme: 'light' | 'dark' | 'amber' | 'cyberpunk') => void;
}

export default function ProfileSettingsModal({ isOpen, onClose, profile, setProfile, theme, setTheme }: ProfileSettingsModalProps) {
  const { unitPreference, setUnitPreference, windUnit, setWindUnit } = usePreferences();
  const [editName, setEditName] = useState(profile?.displayName || '');
  const [editNotifications, setEditNotifications] = useState(profile?.notificationsEnabled || false);
  const [isSaving, setIsSaving] = useState(false);

  const isPro = profile?.membership === 'pro';

  useEffect(() => {
    if (profile) {
      setEditName(profile.displayName || '');
      setEditNotifications(profile.notificationsEnabled || false);
    }
  }, [profile]);

  const handleSave = async () => {
    if (!auth.currentUser) return;
    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'users', auth.currentUser.uid), {
        displayName: editName,
        notificationsEnabled: editNotifications
      });
      setProfile({
        ...profile,
        displayName: editName,
        notificationsEnabled: editNotifications
      });
      onClose();
    } catch (err) {
      console.error(err);
      alert("Failed to update profile.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative w-full max-w-md theme-bg-secondary border-2 border-slate-900 dark:border-indigo-600 shadow-[20px_20px_0px_var(--shadow-color)] p-8"
          >
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-xl font-bold uppercase tracking-tight theme-text-primary">Analyst Profile Settings</h2>
                <div className="h-1 w-12 bg-indigo-600 mt-1"></div>
              </div>
              <button onClick={onClose} className="theme-text-muted hover:theme-text-primary transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest theme-text-muted block mb-2">Display Name (Analyst Handle)</label>
                <input 
                  type="text"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full theme-bg-input border theme-border p-4 text-sm outline-none focus:border-indigo-600 transition-all font-mono theme-text-primary"
                  placeholder="CyberAnalyst_01"
                />
              </div>

              <div className="flex items-center justify-between p-4 theme-bg-primary border theme-border">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-primary block">General Units</label>
                  <p className="text-[10px] theme-text-muted font-mono">Temperature and Precipitation</p>
                </div>
                <div className="flex gap-1 theme-bg-input p-1 rounded-sm shadow-inner">
                  <button 
                    onClick={() => setUnitPreference('imperial')}
                    className={`px-3 py-1 text-[9px] font-bold uppercase tracking-widest transition-all ${unitPreference === 'imperial' ? 'theme-bg-secondary theme-text-primary border theme-border hover:theme-bg-primary shadow-sm' : 'theme-text-muted hover:theme-text-secondary'}`}
                  >
                    Imperial
                  </button>
                  <button 
                    onClick={() => setUnitPreference('metric')}
                    className={`px-3 py-1 text-[9px] font-bold uppercase tracking-widest transition-all ${unitPreference === 'metric' ? 'theme-bg-secondary theme-text-primary border theme-border hover:theme-bg-primary shadow-sm' : 'theme-text-muted hover:theme-text-secondary'}`}
                  >
                    Metric
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 theme-bg-primary border theme-border">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-primary block">Wind Velocity Unit</label>
                  <p className="text-[10px] theme-text-muted font-mono">Specialized knots option available</p>
                </div>
                <div className="flex gap-1 theme-bg-input p-1 rounded-sm shadow-inner">
                  {(['mph', 'kmh', 'knots'] as const).map((unit) => (
                    <button 
                      key={unit}
                      onClick={() => setWindUnit(unit)}
                      className={`px-2 py-1 text-[9px] font-bold uppercase tracking-widest transition-all ${windUnit === unit ? 'theme-bg-secondary theme-text-primary border theme-border hover:theme-bg-primary shadow-sm' : 'theme-text-muted hover:theme-text-secondary'}`}
                    >
                      {unit}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between p-4 theme-bg-primary border theme-border">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-primary block flex items-center gap-2">
                    Terminal UI Theme 
                    {!isPro && <span className="bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full text-[7px] font-black">PRO</span>}
                  </label>
                  <p className="text-[10px] theme-text-muted font-mono">Customize tactical display interface</p>
                </div>
                <div className="flex flex-col gap-1 theme-bg-input p-1 rounded-sm shadow-inner relative">
                  {!isPro && (
                    <div 
                      onClick={(e) => {
                        e.stopPropagation();
                        window.dispatchEvent(new CustomEvent('open-subscription'));
                        onClose();
                      }}
                      className="absolute inset-0 z-10 bg-slate-200/50 dark:bg-slate-800/50 backdrop-blur-[1px] flex items-center justify-center cursor-pointer group"
                      title="Pro Membership Required"
                    >
                       <Lock size={12} className="text-slate-400 dark:text-slate-500 group-hover:text-amber-600 transition-colors" />
                    </div>
                  )}
                  <div className="flex gap-1">
                    <button 
                      onClick={() => isPro && setTheme('light')}
                      className={`flex-1 px-3 py-2 flex items-center justify-center gap-2 text-[9px] font-bold uppercase tracking-widest transition-all ${theme === 'light' ? 'theme-bg-secondary theme-text-primary border theme-border hover:theme-bg-primary shadow-sm' : 'theme-text-muted hover:theme-text-secondary'}`}
                    >
                      <Sun size={10} /> Light
                    </button>
                    <button 
                      onClick={() => isPro && setTheme('dark')}
                      className={`flex-1 px-3 py-2 flex items-center justify-center gap-2 text-[9px] font-bold uppercase tracking-widest transition-all ${theme === 'dark' ? 'theme-bg-secondary theme-text-primary border theme-border hover:theme-bg-primary shadow-sm' : 'theme-text-muted hover:theme-text-secondary'}`}
                    >
                      <Moon size={10} /> Dark
                    </button>
                  </div>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => isPro && setTheme('amber')}
                      className={`flex-1 px-3 py-2 flex items-center justify-center gap-2 text-[9px] font-bold uppercase tracking-widest transition-all ${theme === 'amber' ? 'bg-amber-900 text-amber-100 shadow-sm' : 'theme-text-muted hover:theme-text-secondary'}`}
                    >
                      Amber
                    </button>
                    <button 
                      onClick={() => isPro && setTheme('cyberpunk')}
                      className={`flex-1 px-3 py-2 flex items-center justify-center gap-2 text-[9px] font-bold uppercase tracking-widest transition-all ${theme === 'cyberpunk' ? 'bg-purple-900 text-teal-300 shadow-sm' : 'theme-text-muted hover:theme-text-secondary'}`}
                    >
                      Cyber
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 theme-bg-primary border theme-border">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest theme-text-primary block">Pulse Notifications</label>
                  <p className="text-[10px] theme-text-muted font-mono">Local UI preference for alerting</p>
                </div>
                <button 
                  onClick={() => setEditNotifications(!editNotifications)}
                  className={`w-12 h-6 flex items-center transition-colors px-1 ${editNotifications ? 'bg-indigo-600' : 'theme-bg-input'}`}
                >
                  <motion.div 
                    animate={{ x: editNotifications ? 24 : 0 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    className="w-4 h-4 bg-white shadow-sm"
                  />
                </button>
              </div>

              <div className="pt-4 flex gap-4">
                <button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex-1 theme-bg-secondary theme-text-primary border theme-border hover:theme-bg-primary hover:opacity-90 font-bold py-4 text-xs uppercase tracking-widest transition-all disabled:opacity-50 theme-shadow shadow-md active:translate-y-1 active:shadow-none"
                >
                  {isSaving ? 'Synchronizing...' : 'Save Configuration'}
                </button>
                <button 
                  onClick={onClose}
                  className="flex-1 border-2 theme-border theme-text-muted font-bold py-4 text-xs uppercase tracking-widest hover:theme-border theme-text-primary transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
