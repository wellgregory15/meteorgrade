import { useState } from 'react';
import { db, auth } from '../lib/db';
import { doc, updateDoc, query, collection, where, getDocs, addDoc } from '../lib/db';
import { 
  Cloud, 
  MapPin, 
  Calendar, 
  Thermometer, 
  CheckCircle2, 
  AlertCircle, 
  Activity, 
  Award,
  Zap,
  ChevronRight,
  RefreshCw,
  Droplets,
  Wind,
  Sun,
  Tornado,
  Lock,
  Shield,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getActualGrade, getModelGrade } from '../services/geminiService';
import { usePreferences, convertValue } from '../lib/preferences';
import { calculateFlashScientificScore, parseNWSDescriptionForStats } from '../services/scientificGradingService';
import { METEOROLOGICAL_SECTORS } from '../lib/meteorologicalSectors';

interface ForecastCardProps {
  forecast: any;
  profile?: any;
}

export default function ForecastCard({ forecast, profile }: ForecastCardProps) {
  const { unitPreference, windUnit, units } = usePreferences();
  const sector = METEOROLOGICAL_SECTORS.find(s => s.id === (forecast.sectorId || 'baseline')) || METEOROLOGICAL_SECTORS[5];
  const [isVerifying, setIsVerifying] = useState(false);
  
  // Safely grab the saved unit or assume imperial for old data
  const savedUnit = forecast.unitSystem || 'imperial';
  
  const highTemp = convertValue(forecast.highTemp, savedUnit, unitPreference, 'temp');
  const lowTemp = convertValue(forecast.lowTemp, savedUnit, unitPreference, 'temp');
  
  const isPast = (() => {
    const targetDateObj = new Date(forecast.targetDate);
    // Add one day to ensure the target date has fully concluded
    targetDateObj.setUTCDate(targetDateObj.getUTCDate() + 1);
    return Date.now() >= targetDateObj.getTime();
  })();

  const canVerify = isPast && forecast.status !== 'completed';
  const [temporalError, setTemporalError] = useState<string | null>(null);
  const [gradingError, setGradingError] = useState<string | null>(null);

  const getConditionIcon = (condition: string) => {
    const c = (condition || '').toLowerCase();
    if (c.includes('sunny')) return <Sun size={14} className="text-amber-400" />;
    if (c.includes('storm') || c.includes('thunder')) return <Zap size={14} className="text-amber-500" />;
    if (c.includes('tornado')) return <Tornado size={14} className="text-red-600" />;
    if (c.includes('supercell')) return <Tornado size={14} className="text-orange-500" />;
    if (c.includes('rain')) return <Cloud size={14} className="text-blue-400" />;
    if (c.includes('snow')) return <Cloud size={14} className="text-indigo-200" />;
    if (c.includes('wind')) return <Wind size={14} className="text-slate-400" />;
    return <Cloud size={14} className="text-slate-300" />;
  };

  const isSameSyndicate = profile?.syndicateId && forecast.syndicate_id === profile.syndicateId;
  const isOwner = auth.currentUser?.uid === forecast.userId;
  const showLogic = isOwner || isSameSyndicate;

  const [upvotes, setUpvotes] = useState(forecast.upvotes || 0);
  const [hasUpvoted, setHasUpvoted] = useState(false);

  const handleUpvote = async () => {
    if (!profile?.syndicateId || hasUpvoted || isOwner) return;
    try {
      // 1. Record upvote
      await addDoc(collection(db, 'logic_upvotes'), {
        syndicate_id: profile.syndicateId,
        forecast_id: forecast.id,
        voter_id: auth.currentUser?.uid,
        created_at: new Date().toISOString()
      });

      // 2. Increment forecast upvotes
      const newUpvotes = upvotes + 1;
      setUpvotes(newUpvotes);
      setHasUpvoted(true);
      await updateDoc(doc(db, 'forecasts', forecast.id), {
        upvotes: newUpvotes
      });
    } catch (e) {
      console.error("Upvote failed", e);
    }
  };

  const handleVerify = async () => {
    setIsVerifying(true);
    setTemporalError(null);
    try {
      let result: any;
      
      if (forecast.type === 'flash') {
        const alertDescription = forecast.flashData?.alertDescription || '';
        const actualStats = parseNWSDescriptionForStats(alertDescription);
        const scientificGrade = calculateFlashScientificScore(forecast.flashData, actualStats);
        result = scientificGrade;
      } else {
        const extraFields: any = {
          unitSystem: savedUnit,
          lat: forecast.lat,
          lon: forecast.lon,
          targetDate: forecast.targetDate,
          humidity: forecast.humidity,
          windSpeed: forecast.windSpeed,
          windGusts: forecast.windGusts,
          uvIndex: forecast.uvIndex,
          precip: forecast.precip,
          pressure: forecast.pressure,
          isFlash: forecast.type === 'flash',
          flashData: forecast.flashData
        };

        result = await getActualGrade({
          forecast,
          location: forecast.location,
          targetDate: forecast.targetDate,
          highTemp: forecast.highTemp,
          lowTemp: forecast.lowTemp,
          predictedCondition: forecast.predictedCondition,
          extraFields
        });
      }

      // Consensus Calculation (The "Ensemble Consensus" Challenge)
      let contrarianBonus = 0;
      let crowdMeanTemp = 0;
      let peersCount = 0;
      try {
        const consensusQuery = query(
          collection(db, 'forecasts'),
          where('location', '==', forecast.location),
          where('targetDate', '==', forecast.targetDate)
        );
        const consensusSnap = await getDocs(consensusQuery);
        const peers = consensusSnap.docs
          .map(d => d.data() as any)
          .filter(f => f.id !== forecast.id && (f.highTemp !== undefined));
        
        peersCount = peers.length;
        if (peersCount >= 3) { // Threshold for "The Crowd"
          const totalHigh = peers.reduce((acc, p) => acc + (p.highTemp || 0), 0);
          crowdMeanTemp = totalHigh / peersCount;
          const delta = Math.abs(forecast.highTemp - crowdMeanTemp);
          
          // If user deviates >= 4 degrees and turns out to be right (>85 accuracy)
          if (delta >= 4 && (result.score || 0) > 85) {
            contrarianBonus = Math.min(20, Math.floor(delta * 2.5)); 
          }
        }
      } catch (e) {
        console.error("Consensus calculation failed", e);
      }

      // 1. Apply Lock-In Bonus, Difficulty Multiplier, and Contrarian Bonus
      let baseScore = result.score || 0;

      // ACME STYLE: Probabilistic Scoring Adjustments
      if ((forecast.forecastMode === 'tactical' || forecast.isProbabilistic) && forecast.riskProfile && result.actualHigh !== undefined) {
        const { min, max, expected } = forecast.riskProfile;
        const actual = result.actualHigh;
        
        // Precision Operative Bonus: Narrow spread (< 3 deg) and correct
        const spread = Math.abs(max - min);
        const isWithinRange = actual >= min && actual <= max;
        
        if (spread < 3 && isWithinRange) {
          baseScore += 15;
          // Note: result.feedback will already mention the bonus from the AI side, 
          // but we ensure the number reflects it here too if the AI didn't catch it.
        }

        const distFromExpected = Math.abs(actual - expected);
        
        if (isWithinRange) {
          // Reward staying in range even if slightly off expected
          baseScore = Math.max(baseScore, 90 - (distFromExpected * 2));
        } else {
          // Penalize if actual falls outside reasonable worst-case
          baseScore = Math.min(baseScore, 70 - (distFromExpected * 4));
        }
      }

      const bonus = forecast.lockInBonus || 0;
      const multiplier = forecast.difficultyMultiplier || 1.0;
      
      // Raw accuracy is capped at 100 for the "verification grade" before multipliers
      const rawAccuracy = Math.min(100, baseScore + bonus);
      // Final precision impact accounts for difficulty and the pivot bonus
      const weightedPrecision = (rawAccuracy * multiplier) + contrarianBonus;
      
      // 2. Process Achievements and Streaks
      if (profile && profile.id) {
        const userRef = doc(db, 'users', profile.id);
        const updates: any = {};
        
        // Temperature accuracy streak
        let isHighAccurate = false;
        if (forecast.type !== 'flash' && result.actualHigh !== undefined) {
          const highDiff = Math.abs(forecast.highTemp - result.actualHigh);
          const lowDiff = Math.abs(forecast.lowTemp - result.actualLow);
          if (highDiff <= 2 && lowDiff <= 2) {
            isHighAccurate = true;
          }
        }

        const currentStreak = profile.streak || 0;
        if (isHighAccurate) {
          updates.streak = currentStreak + 1;
        } else {
          if (forecast.type !== 'flash') updates.streak = 0;
        }

        // Achievement: Bust-Proofer
        const achievements = profile.achievements || [];
        const hasBustProofer = achievements.some((a: any) => a.id === 'bust-proofer');
        
        if (!hasBustProofer && forecast.modelGrade && forecast.modelGrade.score < 60 && rawAccuracy > 90) {
          achievements.push({
            id: 'bust-proofer',
            title: 'Bust-Proofer',
            description: 'Successfully predicted a low-impact event when global models anticipated a major storm.',
            awardedAt: new Date().toISOString()
          });
          updates.achievements = achievements;
        }

        // Achievement: Contrarian King
        const hasContrarian = achievements.some((a: any) => a.id === 'contrarian-king');
        if (!hasContrarian && contrarianBonus >= 10) {
          achievements.push({
            id: 'contrarian-king',
            title: 'Contrarian King',
            description: 'Accurately pivoted away from the crowd consensus during a high-uncertainty event.',
            awardedAt: new Date().toISOString()
          });
          updates.achievements = achievements;
        }

        // Achievement: Streak-based badges
        const hasSevenDay = achievements.some((a: any) => a.id === 'seven-day-streak');
        if (!hasSevenDay && (updates.streak || currentStreak) >= 7) {
          achievements.push({
            id: 'seven-day-streak',
            title: 'Precision Streak (7D)',
            description: 'Maintained less than 2° temperature variance for 7 consecutive forecasts.',
            awardedAt: new Date().toISOString()
          });
          updates.achievements = achievements;
        }

        // Update Precision Index (Aggregate)
        const totalForecasts = (profile.totalForecasts || 0) + 1;
        const oldPI = profile.precisionIndex || 0;
        updates.precisionIndex = ((oldPI * (totalForecasts - 1)) + weightedPrecision) / totalForecasts;
        updates.totalForecasts = totalForecasts;
        
        // Update user profile in background
        updateDoc(userRef, updates).catch(e => console.error("Profile update failed:", e));
      }

      await updateDoc(doc(db, 'forecasts', forecast.id), {
        status: 'completed',
        consensus_delta: crowdMeanTemp ? (forecast.highTemp - crowdMeanTemp) : 0,
        actualGrade: {
          ...result,
          score: rawAccuracy,
          weightedScore: weightedPrecision,
          bonusApplied: bonus,
          contrarianBonus,
          crowdMean: crowdMeanTemp,
          difficultyMultiplier: multiplier,
          gradedAt: new Date().toISOString()
        }
      });
    } catch (error: any) {
      console.error("Verification failed", error);
      if (error?.message?.includes('TEMPORAL_LOCK')) {
        setTemporalError("Cannot verify Ground Truth until the target forecast date has completely concluded (midnight).");
      } else if (error?.message?.includes('QUOTA_EXHAUSTED')) {
        setTemporalError("Intelligence Quota Reached. The grading systems are currently at capacity. Please try again later or tomorrow.");
      } else {
        setTemporalError(`Verification failed: ${error?.message || 'Data error. Please retry the verification process.'}`);
      }
    } finally {
      setIsVerifying(false);
    }
  };

  const handleModelGrade = async () => {
    console.log("[ForecastCard] handleModelGrade triggered for forecast:", forecast.id);
    setIsVerifying(true);
    setGradingError(null);
    try {
      if (forecast.type === 'flash') {
        console.log("[ForecastCard] Processing flash grade...");
        const alertDescription = forecast.flashData?.alertDescription || '';
        const actualStats = parseNWSDescriptionForStats(alertDescription);
        const scientificGrade = calculateFlashScientificScore(forecast.flashData, actualStats);
        
        console.log("[ForecastCard] Flash grade calculated:", scientificGrade);
        await updateDoc(doc(db, 'forecasts', forecast.id), {
          status: 'model_graded',
          modelGrade: {
            ...scientificGrade,
            gradedAt: new Date().toISOString()
          }
        });
        console.log("[ForecastCard] Flash grade updated in DB");
        return;
      }

      const extraFields: any = {
        isFlash: forecast.type === 'flash',
        flashData: forecast.flashData,
        unitSystem: savedUnit
      };
      
      console.log("[ForecastCard] Processing standard grade. SavedUnit:", savedUnit);
      if (forecast.humidity !== undefined) extraFields.humidity = forecast.humidity;
      if (forecast.windSpeed !== undefined) extraFields.windSpeed = forecast.windSpeed;
      if (forecast.uvIndex !== undefined) extraFields.uvIndex = forecast.uvIndex;
      if (forecast.windGusts !== undefined) extraFields.windGusts = forecast.windGusts;

      console.log("[ForecastCard] Calling getModelGrade with:", {
        location: forecast.location,
        date: forecast.targetDate,
        high: forecast.highTemp,
        low: forecast.lowTemp,
        cond: forecast.predictedCondition,
        extra: extraFields
      });

      const grade = await getModelGrade({
        location: forecast.location, 
        date: forecast.targetDate, 
        highTemp: forecast.highTemp,
        lowTemp: forecast.lowTemp,
        condition: forecast.predictedCondition,
        extraFields
      });
      
      console.log("[ForecastCard] getModelGrade SUCCESS:", grade);
      
      await updateDoc(doc(db, 'forecasts', forecast.id), {
        status: 'model_graded',
        modelGrade: {
          ...grade,
          gradedAt: new Date().toISOString()
        }
      });
      console.log("[ForecastCard] Standard grade updated in DB");
    } catch (error: any) {
      console.error("[ForecastCard] handleModelGrade CRITICAL FAILURE", error);
      setGradingError(error.message || "Failed to recalculate grade. Please try again.");
    } finally {
      setIsVerifying(false);
      console.log("[ForecastCard] handleModelGrade sequence finished");
    }
  };

  return (
    <div className="geometric-card transition-all hover:translate-y-[-2px] theme-shadow">
      <div className="flex flex-col lg:flex-row">
        {/* Basic Info */}
        <div className="p-5 lg:w-1/3 lg:border-r theme-border transition-colors">
          <div className="accent-line !mb-5"></div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase mb-5 tracking-[0.2em]">
            <Activity size={10} /> Forecasting Data
          </div>
          <h3 className="text-xl md:text-2xl font-light tracking-tight mb-2 theme-text-primary break-words">
            {forecast.location.split(',')[0]} <span className="font-bold">{forecast.location.split(',').slice(1).join(',')}</span>
          </h3>
          <div className="flex items-center gap-2 mb-4">
            <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 border ${sector.color} theme-bg-primary theme-border`}>
              {sector.name}
            </span>
            <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 border ${forecast.forecastMode === 'tactical' ? 'border-orange-500/50 text-orange-500' : 'border-indigo-500/50 text-indigo-500'} theme-bg-primary theme-border`}>
              {forecast.forecastMode === 'tactical' ? 'Tactical Bureau' : 'Junior League'}
            </span>
            {forecast.difficultyMultiplier > 1 && (
              <span className="text-[8px] font-bold text-indigo-400 uppercase tracking-widest">
                {forecast.difficultyMultiplier}x Mult
              </span>
            )}
          </div>
          <div className="mt-4 md:mt-6 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-muted uppercase tracking-wider">
              <Calendar size={14} className="opacity-60" />
              <span>{forecast.targetDate}</span>
            </div>
            
            <div className="grid grid-cols-2 gap-y-3 gap-x-4 mt-2">
              {forecast.type === 'flash' ? (
                <>
                  <div className="col-span-2 p-3 theme-bg-error border-l-4 border-l-red-600 mb-2">
                    <span className="text-[10px] font-black theme-text-error uppercase tracking-widest block mb-1">Severe Impact Target</span>
                    <span className="text-[11px] font-bold theme-text-primary">{forecast.flashData?.event}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] font-semibold">
                    <Wind size={14} className="text-red-500 dark:text-red-400" />
                    <span className="theme-text-primary">{convertValue(forecast.flashData?.peakWind || 0, savedUnit, windUnit, 'speed')} {units.speed} <span className="text-[8px] uppercase theme-text-muted font-bold tracking-widest ml-1">Gusts</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] font-semibold">
                    <Tornado size={14} className="text-indigo-600 dark:text-indigo-400" />
                    <span className="theme-text-primary">{(forecast.flashData?.tornadoRisk !== undefined && !isNaN(forecast.flashData.tornadoRisk)) ? forecast.flashData.tornadoRisk : 0}% <span className="text-[8px] uppercase theme-text-muted font-bold tracking-widest ml-1">Tor. Risk</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] font-semibold">
                    <Sun size={14} className="opacity-80" />
                    <span className="theme-text-primary">{(forecast.flashData?.maxHail !== undefined && !isNaN(forecast.flashData.maxHail)) ? forecast.flashData.maxHail : 0}'' <span className="text-[8px] uppercase theme-text-muted font-bold tracking-widest ml-1">Hail Size</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] font-semibold">
                    <Activity size={14} className="opacity-60" />
                    <span className="theme-text-primary capitalize italic">{forecast.flashData?.upgradeProb} <span className="text-[8px] uppercase theme-text-muted font-bold tracking-widest ml-1">Escalation</span></span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2 text-[11px] font-semibold">
                    <Thermometer size={14} className="text-red-500 dark:text-red-400" />
                    <span className="theme-text-primary">{highTemp}{units.temp} <span className="text-[8px] uppercase theme-text-muted">High</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] font-semibold">
                    <Thermometer size={14} className="text-blue-500 dark:text-blue-400" />
                    <span className="theme-text-primary">{lowTemp}{units.temp} <span className="text-[8px] uppercase theme-text-muted">Low</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] font-semibold">
                    {getConditionIcon(forecast.predictedCondition)}
                    <span className="theme-text-primary">{forecast.predictedCondition}</span>
                  </div>
                </>
              )}
              {forecast.humidity !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Droplets size={14} className="opacity-60" />
                  <span>{forecast.humidity}% Hum.</span>
                </div>
              )}
              {forecast.windSpeed !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Wind size={14} className="opacity-60" />
                  <span>{convertValue(forecast.windSpeed, savedUnit, windUnit, 'speed')} {units.speed} Wind</span>
                </div>
              )}
              {forecast.windGusts !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Wind size={14} className="text-amber-500 dark:text-amber-400 opacity-80" />
                  <span>{convertValue(forecast.windGusts, savedUnit, windUnit, 'speed')} {units.speed} Gusts</span>
                </div>
              )}
              {forecast.uvIndex !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Sun size={14} className="opacity-60" />
                  <span>UV {forecast.uvIndex}</span>
                </div>
              )}
              {forecast.precip !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Cloud size={14} className="text-blue-500 dark:text-blue-400 opacity-60" />
                  <span>{convertValue(forecast.precip, savedUnit, unitPreference, 'precip')} {units.precip}</span>
                </div>
              )}
              {forecast.pressure !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Cloud size={14} className="opacity-60" />
                  <span>{convertValue(forecast.pressure, savedUnit, unitPreference, 'pressure')} {units.pressure}</span>
                </div>
              )}
              {forecast.cape !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Zap size={14} className="text-orange-500 dark:text-orange-400 opacity-80" />
                  <span>{forecast.cape} J/kg CAPE</span>
                </div>
              )}
              {forecast.shear !== undefined && (
                <div className="flex items-center gap-2 text-[11px] font-semibold theme-text-secondary">
                  <Wind size={14} className="text-red-500 dark:text-red-400 opacity-80" />
                  <span>{forecast.shear} kt Shear</span>
                </div>
              )}
            </div>
          </div>

          {showLogic && forecast.logicNotes && (
            <div className="mt-8 pt-8 border-t theme-border">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Shield size={14} className="text-indigo-600 dark:text-indigo-400" />
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] theme-text-primary">Syndicate Briefing</span>
                </div>
                {!isOwner && profile?.syndicateId && (
                  <button 
                    onClick={handleUpvote}
                    disabled={hasUpvoted}
                    className={`flex items-center gap-1.5 px-3 py-1.5 border text-[9px] font-bold uppercase tracking-widest transition-all ${
                      hasUpvoted 
                        ? 'bg-indigo-600 text-white border-indigo-600' 
                        : 'theme-bg-secondary theme-text-muted hover:theme-text-primary border-slate-700/30'
                    }`}
                  >
                    <Check size={12} className={hasUpvoted ? "opacity-100" : "opacity-40"} />
                    Sound Logic {upvotes > 0 && `(${upvotes})`}
                  </button>
                )}
                {isOwner && upvotes > 0 && (
                  <div className="flex items-center gap-1 text-[9px] font-black text-indigo-600 uppercase tracking-widest">
                    <Zap size={10} className="fill-indigo-600" />
                    {upvotes} Syndicate Endorsements
                  </div>
                )}
              </div>
              <div className="p-4 theme-bg-secondary border-l-2 border-indigo-500 italic">
                <p className="text-xs leading-relaxed theme-text-secondary whitespace-pre-wrap">
                  "{forecast.logicNotes}"
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Middle Column: Only show for standard forecasts */}
        {forecast.type !== 'flash' && (
          <div className="p-8 lg:w-1/3 border-t lg:border-t-0 lg:border-r theme-border theme-bg-primary/30">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-[10px] font-bold uppercase tracking-widest theme-text-muted">Model Comparison</h3>
              {forecast.modelGrade ? (
                <div className="flex items-center justify-center w-10 h-10 border-2 border-indigo-600 text-indigo-600 font-bold text-sm bg-indigo-50 dark:bg-indigo-900/30">
                  {(forecast.modelGrade.score !== undefined && !isNaN(forecast.modelGrade.score)) ? (
                    forecast.modelGrade.score >= 90 ? 'A+' : forecast.modelGrade.score >= 80 ? 'A' : forecast.modelGrade.score >= 70 ? 'B' : 'C'
                  ) : 'C'}
                </div>
              ) : (
                <div className="flex items-center justify-center w-10 h-10 border-2 theme-border theme-text-muted font-bold text-xs italic">
                  Pnd.
                </div>
              )}
            </div>
            
            <div className="space-y-4">
              {gradingError && (
                <div className="p-3 theme-bg-error border theme-border theme-text-error text-[10px] font-bold uppercase tracking-widest leading-relaxed">
                  <AlertCircle size={10} className="inline mr-2" />
                  {gradingError}
                </div>
              )}
              {forecast.modelGrade ? (
                <>
                  <p className="text-xs theme-text-secondary leading-relaxed">
                    {forecast.modelGrade.feedback}
                  </p>
                  <div className="mt-6 grid grid-cols-3 gap-2">
                    <div className={`h-1 ${forecast.modelGrade.score > 33 ? 'bg-indigo-600' : 'theme-bg-primary'}`}></div>
                    <div className={`h-1 ${forecast.modelGrade.score > 66 ? 'bg-indigo-600' : 'theme-bg-primary'}`}></div>
                    <div className={`h-1 ${forecast.modelGrade.score > 90 ? 'bg-indigo-600' : 'theme-bg-primary'}`}></div>
                  </div>
                  <span className="text-[9px] uppercase font-bold theme-text-muted mt-2 block">Model Alignment Index: {isNaN(forecast.modelGrade.score) ? 0 : forecast.modelGrade.score}%</span>
                  <button 
                    onClick={handleModelGrade}
                    disabled={isVerifying}
                    className="mt-4 text-[9px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-2 hover:opacity-80 transition-opacity disabled:opacity-50"
                  >
                    <RefreshCw size={10} className={isVerifying ? "animate-spin" : ""} />
                    Recalculate Grade
                  </button>
                </>
              ) : (
                <div className="flex flex-col gap-4">
                  <p className="text-[11px] theme-text-muted italic">Review process initiated. Analyzing Gemini meteorological benchmarks...</p>
                  <button 
                    onClick={handleModelGrade}
                    disabled={isVerifying}
                    className="text-[9px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-2 hover:opacity-80 transition-opacity disabled:opacity-50"
                  >
                    <RefreshCw size={10} className={isVerifying ? "animate-spin" : ""} />
                    Recalculate Grade
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Right Column: Ground Truth / Scientific Grading */}
        <div className={`p-8 ${forecast.type === 'flash' ? 'lg:w-2/3' : 'lg:w-1/3'} border-t lg:border-t-0 relative ${forecast.status === 'completed' ? 'theme-bg-app theme-text-primary' : ''}`}>
          <div className="flex justify-between items-start mb-6">
            <h3 className={`text-[10px] font-bold uppercase tracking-widest theme-text-muted`}>
              {forecast.type === 'flash' ? 'Scientific Telemetry Verification' : 'Ground Truth'}
            </h3>
            {forecast.actualGrade ? (
              <div className="flex items-center justify-center w-10 h-10 border-2 border-indigo-500/50 text-indigo-600 dark:text-indigo-400 font-extrabold text-sm shadow-sm">
                {(forecast.actualGrade.score !== undefined && !isNaN(forecast.actualGrade.score)) ? forecast.actualGrade.score : 0}%
              </div>
            ) : (
              <div className="flex items-center justify-center w-10 h-10 border-2 theme-border theme-text-muted font-bold text-xs italic">
                Pnd.
              </div>
            )}
          </div>

          <div className="space-y-4">
            {/* Advanced Risk Distribution Plot (Acme Style) - Show even for pending tactical forecasts */}
            {(forecast.forecastMode === 'tactical' || (forecast.isProbabilistic && forecast.riskProfile)) && (
              <div className="mb-6 p-4 theme-bg-primary border theme-border rounded-sm">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[8px] font-black uppercase tracking-widest text-indigo-400">Risk Distribution {forecast.status !== 'completed' && '(Live Projection)'}</span>
                  <span className="text-[8px] font-bold theme-text-muted uppercase">Confidence: {forecast.riskProfile?.confidence || 0}%</span>
                </div>
                
                <div className="relative h-12 flex items-center">
                  {/* Scale Line */}
                  <div className="absolute w-full h-[1px] bg-slate-700/30"></div>
                  
                  {(() => {
                    const { min, max, expected } = forecast.riskProfile;
                    const actual = forecast.actualGrade?.actualHigh;
                    
                    // Calculate relative positions (0-100%)
                    const padding = 10;
                    const scaleMin = Math.min(min, actual ?? min) - padding;
                    const scaleMax = Math.max(max, actual ?? max) + padding;
                    const getPos = (val: number) => ((val - scaleMin) / (scaleMax - scaleMin)) * 100;
                    
                    return (
                      <>
                        {/* Confidence Interval Bar */}
                        <div 
                          className="absolute h-2 bg-indigo-500/20 border-x border-indigo-500/40"
                          style={{ left: `${getPos(min)}%`, width: `${getPos(max) - getPos(min)}%` }}
                        ></div>
                        
                        {/* Expected Value Marker */}
                        <div 
                          className="absolute w-0.5 h-6 bg-indigo-500 z-10"
                          style={{ left: `${getPos(expected)}%` }}
                        >
                          <div className="absolute -top-4 left-1/2 -translate-x-1/2 text-[7px] font-black uppercase text-indigo-400">Exp</div>
                        </div>
                        
                        {/* Actual Value (Ground Truth) Marker */}
                        {actual !== undefined && (
                          <motion.div 
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute w-3 h-3 bg-red-600 rounded-full border-2 border-white dark:border-slate-900 z-20 shadow-lg"
                            style={{ left: `${getPos(actual)}%`, marginLeft: '-6px' }}
                          >
                            <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[7px] font-black uppercase text-red-500 whitespace-nowrap">Truth: {actual}°</div>
                          </motion.div>
                        )}

                        {/* Range Labels */}
                        <div className="absolute -bottom-2 text-[6px] font-bold theme-text-muted" style={{ left: `${getPos(min)}%` }}>{min}°</div>
                        <div className="absolute -bottom-2 text-[6px] font-bold theme-text-muted" style={{ left: `${getPos(max)}%` }}>{max}°</div>
                      </>
                    );
                  })()}
                </div>
              </div>
            )}

            {forecast.status === 'completed' ? (
              <div className="animate-in slide-in-from-right-4 duration-500">
                {forecast.type !== 'flash' && (
                  <div className="flex justify-between items-end mb-2">
                    <div className="text-xl font-light tracking-tight theme-text-primary">
                      <span className="font-bold text-red-500">{convertValue(forecast.actualGrade.actualHigh, savedUnit, unitPreference, 'temp')}{units.temp}</span> / <span className="font-bold text-blue-500">{convertValue(forecast.actualGrade.actualLow, savedUnit, unitPreference, 'temp')}{units.temp}</span>
                    </div>
                    <span className="text-[10px] theme-text-muted uppercase font-bold tracking-widest leading-none">Observed</span>
                  </div>
                )}
                
                <div className="flex flex-wrap gap-x-4 gap-y-1 mb-4">
                  {forecast.type === 'flash' ? (
                    <span className="text-[10px] font-bold theme-text-success uppercase tracking-widest theme-bg-success px-2 py-0.5 rounded">Analysis Confirmed</span>
                  ) : (
                    <>
                      <span className="text-[10px] font-bold theme-text-secondary uppercase tracking-wider">{forecast.actualGrade.actualCondition}</span>
                      {forecast.actualGrade.actualHumidity !== undefined && (
                        <span className="text-[10px] font-bold theme-text-secondary uppercase tracking-wider">{forecast.actualGrade.actualHumidity}% Humidity</span>
                      )}
                    </>
                  )}
                  {forecast.actualGrade.actualWindSpeed !== undefined && (
                    <span className="text-[10px] font-bold theme-text-secondary uppercase tracking-wider">{convertValue(forecast.actualGrade.actualWindSpeed, savedUnit, windUnit, 'speed')} {units.speed} Wind</span>
                  )}
                  {forecast.actualGrade.actualPrecip !== undefined && (
                    <span className="text-[10px] font-bold theme-text-secondary uppercase tracking-wider">{convertValue(forecast.actualGrade.actualPrecip, savedUnit, unitPreference, 'precip')} {units.precip} Precip.</span>
                  )}
                </div>
                
                <p className={`text-xs leading-relaxed italic ${forecast.type === 'flash' ? 'theme-text-secondary border-l-2 border-indigo-500 pl-4 py-2 theme-bg-primary/20' : 'theme-text-secondary'}`}>
                  "{forecast.actualGrade.feedback}"
                </p>

                {/* Silver Lining / Bust Support */}
                {forecast.actualGrade.silverLining && (
                  <div className="mt-4 p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-sm">
                    <div className="flex items-center gap-2 mb-1">
                      <Zap size={10} className="text-indigo-400 animate-pulse" />
                      <span className="text-[8px] font-bold text-indigo-400 uppercase tracking-widest">Model Variance Detected</span>
                    </div>
                    <p className="text-[10px] text-indigo-300 italic leading-snug">
                      "{forecast.actualGrade.silverLining}"
                    </p>
                  </div>
                )}

                {/* Contrarian / Consensus Data */}
                {forecast.actualGrade.contrarianBonus > 0 && (
                  <div className="mt-2 flex items-center gap-2">
                    <span className="text-[8px] font-black uppercase tracking-widest px-2 py-0.5 border border-emerald-500/50 text-emerald-400 theme-bg-primary">
                      Contrarian Pivot +{forecast.actualGrade.contrarianBonus} PI
                    </span>
                    <span className="text-[8px] theme-text-muted uppercase tracking-widest">
                      Crowd Consensus: {Math.round(forecast.actualGrade.crowdMean)}°F
                    </span>
                  </div>
                )}
                <div className="mt-6 flex justify-between items-center">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                    <div className="w-2 h-2 rounded-full theme-bg-input"></div>
                  </div>
                  <button 
                    onClick={handleVerify}
                    disabled={isVerifying}
                    className="text-[9px] font-bold uppercase tracking-widest theme-text-muted hover:theme-text-primary transition-colors flex items-center gap-2"
                  >
                    <RefreshCw size={10} className={isVerifying ? "animate-spin" : ""} />
                    {forecast.type === 'flash' ? 'Recalculate Score' : 'Re-Verify Ground Truth'}
                  </button>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-700/50">
                  {profile?.membership === 'pro' ? (
                    <button 
                      onClick={() => {
                        window.dispatchEvent(new CustomEvent('open-deep-dive', { detail: forecast }));
                      }}
                      className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-[9px] font-black uppercase tracking-[0.2em] py-3 transition-all flex items-center justify-center gap-2 group shadow-lg shadow-indigo-600/20"
                    >
                      <Zap size={14} className="fill-white group-hover:scale-125 transition-transform" />
                      AI Deep Dive Analysis
                    </button>
                  ) : (
                    <button 
                      onClick={() => {
                        window.dispatchEvent(new CustomEvent('open-subscription'));
                      }}
                      className="w-full bg-slate-800 hover:bg-slate-750 text-slate-400 text-[9px] font-bold uppercase tracking-[0.2em] py-3 transition-all flex items-center justify-center gap-2 group border border-slate-700"
                    >
                      <Lock size={12} className="text-slate-500" />
                      Upgrade for Deep Dive
                    </button>
                  )}
                </div>
              </div>

            ) : (
              <div className="flex flex-col h-full justify-between gap-6">
                <p className="text-xs text-slate-500 leading-relaxed italic">
                  {isPast 
                    ? "Event has concluded. Accuracy verification data is available for review." 
                    : "Actual weather data will populate after the event. This determines your final precision score."}
                </p>

                {temporalError && (
                  <p className="text-[10px] font-bold theme-text-error uppercase tracking-widest p-3 theme-bg-error border theme-border">
                    {temporalError}
                  </p>
                )}
                
                {canVerify && (
                  <button 
                    onClick={handleVerify}
                    disabled={isVerifying}
                    className="w-full theme-bg-app theme-text-primary border theme-border text-[10px] font-bold uppercase tracking-[0.2em] py-3 hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    {isVerifying ? (
                      <RefreshCw size={12} className="animate-spin" />
                    ) : (
                      <CheckCircle2 size={12} />
                    )}
                    Verify Results
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
