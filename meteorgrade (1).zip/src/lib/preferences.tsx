import React, { createContext, useContext, useState, useEffect } from 'react';
import { db, doc, onSnapshot, setDoc, updateDoc } from './db';

export type UnitPreference = 'imperial' | 'metric';
export type WindUnit = 'mph' | 'kmh' | 'knots';

interface PreferencesContextType {
  unitPreference: UnitPreference;
  setUnitPreference: (unit: UnitPreference) => Promise<void>;
  windUnit: WindUnit;
  setWindUnit: (unit: WindUnit) => Promise<void>;
  units: {
    temp: string;
    speed: string;
    precip: string;
    pressure: string;
  };
}

const PreferencesContext = createContext<PreferencesContextType | undefined>(undefined);

export function PreferencesProvider({ children, userId }: { children: React.ReactNode, userId?: string }) {
  const [unitPreference, setUnitPreferenceState] = useState<UnitPreference>('imperial');
  const [windUnit, setWindUnitState] = useState<WindUnit>('mph');

  useEffect(() => {
    if (!userId) return;
    
    // Listen to user document for true state
    const unsub = onSnapshot(doc(db, 'users', userId), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.unitPreference) setUnitPreferenceState(data.unitPreference);
        if (data.windUnit) setWindUnitState(data.windUnit);
      }
    });

    return () => unsub();
  }, [userId]);

  const setUnitPreference = async (unit: UnitPreference) => {
    setUnitPreferenceState(unit); // Optimistic
    if (userId) {
      await updateDoc(doc(db, 'users', userId), {
        unitPreference: unit
      });
    }
  };

  const setWindUnit = async (unit: WindUnit) => {
    setWindUnitState(unit); // Optimistic
    if (userId) {
      await updateDoc(doc(db, 'users', userId), {
        windUnit: unit
      });
    }
  };

  const units = {
    temp: unitPreference === 'imperial' ? '°F' : '°C',
    speed: windUnit === 'mph' ? 'mph' : windUnit === 'kmh' ? 'km/h' : 'knots',
    precip: unitPreference === 'imperial' ? 'in' : 'mm',
    pressure: 'mb',
  };

  return (
    <PreferencesContext.Provider value={{ unitPreference, setUnitPreference, windUnit, setWindUnit, units }}>
      {children}
    </PreferencesContext.Provider>
  );
}

export function usePreferences() {
  const context = useContext(PreferencesContext);
  if (context === undefined) {
    throw new Error('usePreferences must be used within a PreferencesProvider');
  }
  return context;
}

export function convertValue(value: number, from: UnitPreference, to: UnitPreference | WindUnit, type: 'temp' | 'speed' | 'precip' | 'pressure') {
  if (value === undefined || value === null || isNaN(value)) return 0;
  
  if (type === 'temp') {
    if (from === (to as UnitPreference)) return value;
    if (to === 'metric') return Math.round((value - 32) * 5/9);
    return Math.round((value * 9/5) + 32);
  }
  
  if (type === 'speed') {
    // Standardize 'from' value to MPH first (input is usually mph/imperial or kmh/metric)
    let mphValue = value;
    if (from === 'metric') {
      mphValue = value / 1.60934;
    }

    // Convert MPH to target unit
    if (to === 'kmh' || to === 'metric') return Math.round(mphValue * 1.60934);
    if (to === 'knots') return Math.round(mphValue * 0.868976);
    return Math.round(mphValue); // mph
  }
  
  if (type === 'precip') {
    if (to === 'metric') return Number((value * 25.4).toFixed(2)); // in to mm
    return Number((value / 25.4).toFixed(2));
  }
  
  if (type === 'pressure') {
    // Standardizing to mb (millibars) regardless of 'to' preference
    if (from === 'imperial') return Math.round(value * 33.8639); // inHg to mb
    return value; // Already in mb/hPa
  }
  
  return value;
}
