import { createClient } from '@supabase/supabase-js';

let _supabase: any = null;

export function getSupabase() {
  if (!_supabase) {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey || supabaseUrl.includes('placeholder')) {
      throw new Error('Supabase configuration missing. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment.');
    }
    _supabase = createClient(supabaseUrl, supabaseAnonKey);
  }
  return _supabase;
}

// -- Supabase/Firestore Shim --
// This maps Firebase API calls to Supabase to prevent the free tier quota limits
// from affecting the massively integrated NWS forecast app.

const toSnakeCase = (str: string) => str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
const toCamelCase = (str: string) => str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());

const convertKeys = (obj: any, converter: (s: string) => string): any => {
  if (typeof obj !== 'object' || obj === null || obj instanceof Date) return obj;
  if (Array.isArray(obj)) return obj.map(item => convertKeys(item, converter));
  return Object.keys(obj).reduce((acc: any, key) => {
    acc[converter(key)] = convertKeys(obj[key], converter);
    return acc;
  }, {});
};

// 1. Auth Shim (Basic mapping)
let _currentUser: any = null;
let _isInitializing = false;
let _subscribers: any[] = [];

// Helper to check if two user objects are logically the same
const isSameUser = (u1: any, u2: any) => {
  if (!u1 && !u2) return true;
  if (!u1 || !u2) return false;
  return u1.uid === u2.uid && u1.email === u2.email;
};

export const getAuth = () => ({
  get currentUser() { return _currentUser; },
  onAuthStateChanged: (callback: any): (() => void) => {
    console.log("[db] onAuthStateChanged subscribed");
    _subscribers.push(callback);
    
    // If we already have a user (or null) and aren't waiting for the first fetch, 
    // call the callback immediately with the stabilized current value.
    if (!_isInitializing) {
      callback(_currentUser);
    }

    // Initialize if not already doing so
    if (!_isInitializing && !_currentUser) {
      _isInitializing = true;
      getSupabase().auth.getSession().then(({ data: { session }, error }) => {
        _isInitializing = false;
        if (error) {
          console.error("[db] Initial getSession Error:", error);
        }
        
        const u = session?.user;
        const mappedUser = u ? {
          uid: u.id,
          email: u.email,
          displayName: u.user_metadata?.full_name || u.email?.split('@')[0],
          photoURL: u.user_metadata?.avatar_url || u.user_metadata?.picture || null,
          emailVerified: !!u.email_confirmed_at,
          isAnonymous: false,
          providerData: []
        } : null;

        if (!isSameUser(_currentUser, mappedUser)) {
          console.log(`[db] Auth State Initialized: ${mappedUser?.email || 'No Session'}`);
          _currentUser = mappedUser;
          _subscribers.forEach(cb => cb(_currentUser));
        }
      }).catch(err => {
        _isInitializing = false;
        console.error("[db] getSession Promise Failed:", err);
      });
    }

    const { data } = getSupabase().auth.onAuthStateChange((event, session) => {
      console.log(`[db] authStateChange Event: ${event}`);
      const u = session?.user;
      const mappedUser = u ? {
        uid: u.id,
        email: u.email,
        displayName: u.user_metadata?.full_name || u.email?.split('@')[0],
        photoURL: u.user_metadata?.avatar_url || u.user_metadata?.picture || null,
        emailVerified: !!u.email_confirmed_at,
        isAnonymous: false,
        providerData: []
      } : null;

      if (!isSameUser(_currentUser, mappedUser)) {
        console.log(`[db] Auth State Changed via Event: ${mappedUser?.email || 'Signed Out'}`);
        _currentUser = mappedUser;
        _subscribers.forEach(cb => cb(_currentUser));
      }
    });

    return () => { 
      _subscribers = _subscribers.filter(cb => cb !== callback);
      data.subscription.unsubscribe(); 
    };
  },
  signInWithPopup: async () => {
    console.log("[db] signInWithPopup initiated");
    const callbackUrl = `${window.location.origin}/auth/callback`;
    
    // Diagnostics
    if (window.self !== window.top) {
      console.warn("[db] Detection: App running in IFRAME. Popup might be blocked or session might not sync correctly.");
    }
    const { data, error } = await getSupabase().auth.signInWithOAuth({ 
      provider: 'google',
      options: {
        redirectTo: callbackUrl,
        skipBrowserRedirect: true
      }
    });
    
    if (error) throw error;
    if (!data.url) throw new Error("No OAuth URL returned from Supabase");

    console.log("[db] Opening OAuth URL:", data.url);

    // 2. Open the popup directly with the Google URL
    const width = 600;
    const height = 700;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;
    
    const popup = window.open(
      data.url,
      'supabase_auth_popup',
      `width=${width},height=${height},left=${left},top=${top},toolbar=no,menubar=no`
    );

    if (!popup) {
      throw new Error("Popup blocked. Please allow popups for this site.");
    }

    // 3. Listen for completion message from our /auth/callback route
    return new Promise((resolve, reject) => {
      let isResolved = false;
      const checkClosed = setInterval(() => {
        if (popup.closed) {
          clearInterval(checkClosed);
          if (!isResolved) {
            // Give it a small window to process any final messages
            setTimeout(() => {
              if (!isResolved) {
                window.removeEventListener('message', handleMsg);
                reject(new Error("Login window closed"));
              }
            }, 1000);
          }
        }
      }, 500);

      const handleMsg = async (event: MessageEvent) => {
        if (event.data?.type === 'SUPABASE_AUTH_COMPLETED') {
          isResolved = true;
          clearInterval(checkClosed);
          window.removeEventListener('message', handleMsg);

          console.log("[db] Callback signal received, checking session...");
          
          // Retry loop for session propagation
          let retries = 5;
          while (retries > 0) {
            const { data: { session } } = await getSupabase().auth.getSession();
            if (session?.user) {
              console.log("[db] Popup login successful");
              resolve(session.user);
              return;
            }
            console.log(`[db] Session not found yet, retrying... (${retries} left)`);
            await new Promise(r => setTimeout(r, 800));
            retries--;
          }
          
          reject(new Error("Login completed but session not found. Please try again."));
        }
      };
      
      window.addEventListener('message', handleMsg);
    });
  },
  signOut: async () => getSupabase().auth.signOut(),
  createUserWithEmailAndPassword: async (_auth: any, e: string, p: string) => getSupabase().auth.signUp({ email: e, password: p }),
  signInWithEmailAndPassword: async (_auth: any, e: string, p: string) => getSupabase().auth.signInWithPassword({ email: e, password: p }),
  getRedirectResult: async () => null,
  GoogleAuthProvider: class {}
});

export const onAuthStateChanged = (auth: any, cb: any) => auth.onAuthStateChanged(cb);
export const signInWithPopup = (auth: any, ...args: any[]) => auth.signInWithPopup();
export const signOut = (auth: any) => auth.signOut();
export const createUserWithEmailAndPassword = (auth: any, e: string, p: string) => auth.createUserWithEmailAndPassword(auth, e, p);
export const signInWithEmailAndPassword = (auth: any, e: string, p: string) => auth.signInWithEmailAndPassword(auth, e, p);
export const GoogleAuthProvider = class {};
export const getRedirectResult = (auth: any) => auth.getRedirectResult();

export const auth = getAuth();
export const db = 'supabase_db';

// 2. Firestore Shim helper to handle missing columns gracefully
const prepareSupabaseData = (path: string, data: any) => {
  const mappedData = convertKeys(data, toSnakeCase);
  if (['forecasts', 'support_tickets', 'announcements', 'missions', 'users', 'weekly_debriefs', 'flashpoints', 'beta_feedback', 'beta_feedback_notes', 'syndicates', 'syndicate_members', 'syndicate_broadcasts', 'syndicate_vaults', 'syndicate_requests', 'syndicate_messages', 'chat_reports', 'logic_upvotes'].includes(path)) {
    const knownColumnsMap: Record<string, string[]> = {
      'syndicates': [
        'id', 'name', 'tag', 'creator_id', 'description', 'logo_url', 'is_classroom', 'organization_name', 'learning_objectives', 'join_code', 'total_pi', 'member_count', 'is_invite_only', 'created_at'
      ],
      'syndicate_broadcasts': [
        'id', 'syndicate_id', 'title', 'message', 'author_id', 'created_at'
      ],
      'syndicate_vaults': [
        'id', 'syndicate_id', 'credits', 'hardware', 'last_updated'
      ],
      'syndicate_messages': [
        'id', 'syndicate_id', 'user_id', 'user_name', 'content', 'created_at'
      ],
      'chat_reports': [
        'id', 'message_id', 'syndicate_id', 'reporter_id', 'reason', 'status', 'created_at'
      ],
      'syndicate_requests': [
        'id', 'syndicate_id', 'user_id', 'status', 'created_at'
      ],
      'syndicate_members': [
        'syndicate_id', 'user_id', 'role', 'joined_at'
      ],
      'logic_upvotes': [
        'forecast_id', 'voter_id', 'syndicate_id', 'created_at'
      ],
      'beta_feedback_notes': [
        'id', 'feedback_id', 'admin_id', 'admin_email', 'content', 'timestamp'
      ],
      'beta_feedback': [
        'id', 'user_id', 'user_email', 'type', 'description', 'path', 'user_agent', 'timestamp', 'status', 'admin_notes', 'updated_at'
      ],
      'flashpoints': [
        'id', 'nws_id', 'event', 'location', 'area_desc', 'severity', 'urgency', 
        'certainty', 'description', 'instruction', 'headline', 'location_coord', 
        'expires', 'effective', 'is_active', 'deactivated_at', 'created_at'
      ],
      'forecasts': [
        'id', 'user_id', 'flashpoint_id', 'user_name', 'user_tier', 'user_score',
        'event_name', 'location', 'lat', 'lon', 'target_date', 'forecast_date',
        'unit_system', 'predicted_condition', 'humidity', 'wind_speed', 'wind_gusts',
        'uv_index', 'precip', 'pressure', 'cape', 'shear', 'location_coord',
        'model_grade', 'severity_level', 'high_temp', 'low_temp', 'predicted_temp',
        'status', 'actual_grade', 'flash_data', 'lock_in_bonus', 'sector_id', 'difficulty_multiplier', 'consensus_delta', 'is_probabilistic', 'risk_profile', 'forecast_mode', 'logic_notes', 'syndicate_id', 'mission_id', 'upvotes', 'created_at',
        'nws_id', 'expires', 'is_active', 'deactivated_at'
      ],
      'support_tickets': [
        'id', 'user_id', 'subject', 'category', 'description', 
        'status', 'priority', 'admin_reply', 'created_at'
      ],
      'announcements': [
        'id', 'title', 'description', 'content', 'type', 'is_active', 'priority', 'expires_at', 'created_at'
      ],
      'missions': [
        'id', 'title', 'description', 'category', 'severity', 'is_active', 'global_id', 'created_at',
        'start_date', 'end_date', 'status', 'is_global', 'user_id', 'is_reviewed', 'syndicate_id'
      ],
      'users': [
        'id', 'email', 'display_name', 'role', 'tier', 'membership', 'upgraded_at', 'onboarded', 'total_forecasts',
        'average_accuracy', 'precision_index', 'streak', 'avatar_url', 'notifications_enabled', 'syndicate_id',
        'fcm_tokens', 'push_subscriptions', 'achievements', 'timezone', 'last_daily_at', 'created_at'
      ],
      'weekly_debriefs': [
        'id', 'user_id', 'insight', 'precision_delta', 'pros', 'cons', 'week_start_date', 'created_at'
      ]
    };

    const knownColumns = knownColumnsMap[path] || [];
    let hasExtra = false;
    const extra: any = {};
    
    // 1. Forced Mappings (Compatibility)
    if (path === 'announcements' && mappedData.content && !mappedData.description) {
      console.log("[db] Mapping 'content' -> 'description' for announcement");
      mappedData.description = mappedData.content;
    }
    
    // 2. Filter & Cull Surplus
    Object.keys(mappedData).forEach(key => {
      const snakeKey = toSnakeCase(key);
      if (knownColumns.includes(snakeKey)) {
        // Correct known property (possibly mis-cased)
        if (key !== snakeKey) {
          mappedData[snakeKey] = mappedData[key];
          delete mappedData[key];
        }
      } else if (!knownColumns.includes(key)) {
        extra[key] = mappedData[key];
        delete mappedData[key];
        hasExtra = true;
      }
    });

    // 3. Unpack/Merge Extra (Only for tables with JSON columns)
    if (hasExtra && path === 'forecasts') {
      const existingActual = mappedData.actual_grade || {};
      mappedData.actual_grade = {
        ...existingActual,
        _extra: {
          ...(existingActual._extra || {}),
          ...extra
        }
      };
    }
  }
  return mappedData;
};

export const collection = (db: any, path: string) => ({ type: 'collection', path: toSnakeCase(path) });
export const doc = (db: any, path: string, ...rest: string[]) => {
  if (rest.length > 0) return { type: 'doc', path: toSnakeCase(path), id: rest[rest.length - 1] };
  const parts = path.split('/');
  const table = toSnakeCase(parts[0]);
  const id = parts.length > 1 ? parts[1] : crypto.randomUUID();
  return { type: 'doc', path: table, id };
};

export const query = (ref: any, ...constraints: any[]) => {
  return { ...ref, constraints: constraints || [] };
};

export const where = (field: string, op: string, value: any) => ({ type: 'where', field, op, value });
export const orderBy = (field: string, dir: string = 'asc') => ({ type: 'orderBy', field, dir });
export const limit = (l: number) => ({ type: 'limit', value: l });

export const getDocs = async (q: any) => {
  console.log(`[db] getDocs: Fetching from ${q.path}, constraints: ${q.constraints?.length || 0}`);
  let builder: any = getSupabase().from(q.path).select('*');
  for (const c of q.constraints || []) {
    if (c.type === 'where') {
      const field = c.field.includes('.') 
        ? c.field.split('.').map(toSnakeCase).join('->') 
        : toSnakeCase(c.field);
      if (c.op === '==') builder = builder.eq(field, c.value);
      if (c.op === '>') builder = builder.gt(field, c.value);
      if (c.op === '<') builder = builder.lt(field, c.value);
      if (c.op === '>=') builder = builder.gte(field, c.value);
      if (c.op === '<=') builder = builder.lte(field, c.value);
      if (c.op === 'in') builder = builder.in(field, c.value);
      if (c.op === 'array-contains') builder = builder.contains(field, [c.value]);
    } else if (c.type === 'orderBy') {
      const fieldPath = c.field.includes('.') 
        ? c.field.split('.').map(toSnakeCase).join('->') 
        : toSnakeCase(c.field);
      builder = builder.order(fieldPath, { ascending: c.dir === 'asc' });
    } else if (c.type === 'limit') {
      builder = builder.limit(c.value);
    }
  }
  const { data, error } = await builder;
  if(error) {
    console.error(`[db] getDocs Error for ${q.path}:`, error);
    if (error.code === 'PGRST205' && (q.path === 'missions' || q.path === 'announcements' || q.path === 'weekly_debriefs' || q.path === 'beta_feedback' || q.path === 'beta_feedback_notes' || q.path.startsWith('syndicate_') || q.path === 'syndicates' || q.path === 'forecasts' || q.path === 'users' || q.path === 'chat_reports')) {
      return { empty: true, size: 0, docs: [] };
    }
    throw error;
  }
  console.log(`[db] getDocs: Success fetching from ${q.path}. Row count: ${data?.length || 0}`);
  return {
    empty: !data || data.length === 0,
    size: data ? data.length : 0,
    docs: (data || []).map((d: any) => {
      // Restore flash_data if hijacked into actual_grade
      if (d.actual_grade) {
        if (d.actual_grade._flash_data) d.flash_data = d.actual_grade._flash_data;
        if (d.actual_grade._extra) {
          Object.assign(d, d.actual_grade._extra);
        }
      }
      
      // Map description to content for announcements UI compatibility
      if (q.path === 'announcements' && d.description && !d.content) {
        d.content = d.description;
      }
      
      if (q.path === 'users' && d.avatar_url && !d.photo_url) {
        d.photo_url = d.avatar_url;
      }

      return {
        id: d.id,
        data: () => convertKeys(d, toCamelCase),
        exists: () => true
      };
    })
  };
};

export const getDocFromServer = async (ref: any) => {
  const { data, error } = await getSupabase().from(ref.path).select('*').eq('id', ref.id).single();
  if (error && error.code !== 'PGRST116') {
    if (error.code === 'PGRST205' && (ref.path === 'missions' || ref.path === 'announcements' || ref.path === 'weekly_debriefs' || ref.path === 'beta_feedback' || ref.path === 'beta_feedback_notes' || ref.path.startsWith('syndicate_') || ref.path === 'users' || ref.path === 'chat_reports')) {
      return { id: ref.id, exists: () => false, data: () => null };
    }
    throw error;
  }
  if (data && data.actual_grade) {
    if (data.actual_grade._flash_data) data.flash_data = data.actual_grade._flash_data;
    if (data.actual_grade._extra) Object.assign(data, data.actual_grade._extra);
  }
  
  // Map description to content for announcements UI compatibility
  if (ref.path === 'announcements' && data && data.description && !data.content) {
    data.content = data.description;
  }

  return {
    id: ref.id,
    exists: () => !!data,
    data: () => data ? convertKeys(data, toCamelCase) : null
  };
}
export const getDoc = getDocFromServer;

export const setDoc = async (ref: any, data: any, options?: { merge: boolean }) => {
  let mappedData = prepareSupabaseData(ref.path, data);
  
  // Handle arrayUnion special object for shimming
  if (mappedData.fcm_tokens && mappedData.fcm_tokens.__type === 'arrayUnion') {
    const newVal = mappedData.fcm_tokens.value;
    const { data: existing } = await getSupabase().from(ref.path).select('fcm_tokens').eq('id', ref.id).single();
    const currentTokens = existing?.fcm_tokens || [];
    if (!currentTokens.includes(newVal)) {
      mappedData.fcm_tokens = [...currentTokens, newVal];
    } else {
      mappedData.fcm_tokens = currentTokens;
    }
  }

  if (mappedData.push_subscriptions && mappedData.push_subscriptions.__type === 'arrayUnion') {
    const newVal = mappedData.push_subscriptions.value;
    const { data: existing } = await getSupabase().from(ref.path).select('push_subscriptions').eq('id', ref.id).single();
    const currentTokens = existing?.push_subscriptions || [];
    
    const newValStr = JSON.stringify(newVal);
    const exists = currentTokens.some((t: any) => JSON.stringify(t) === newValStr);

    if (!exists) {
      mappedData.push_subscriptions = [...currentTokens, newVal];
    } else {
      mappedData.push_subscriptions = currentTokens;
    }
  }

  if (options?.merge) {
    const { error } = await getSupabase().from(ref.path).upsert({ id: ref.id, ...mappedData });
    if(error) {
      if ((error.code === 'PGRST205' || error.code === '42P01') && (ref.path === 'missions' || ref.path === 'announcements' || ref.path === 'weekly_debriefs' || ref.path === 'beta_feedback' || ref.path === 'beta_feedback_notes' || ref.path.startsWith('syndicate_'))) return;
      throw error;
    }
  } else {
    const { error } = await getSupabase().from(ref.path).insert({ id: ref.id, ...mappedData });
    if(error) {
      if ((error.code === 'PGRST205' || error.code === '42P01') && (ref.path === 'missions' || ref.path === 'announcements' || ref.path === 'weekly_debriefs' || ref.path === 'beta_feedback' || ref.path === 'beta_feedback_notes' || ref.path.startsWith('syndicate_'))) return;
      throw error;
    }
  }
};

export const addDoc = async (ref: any, data: any) => {
  const mappedData = prepareSupabaseData(ref.path, data);
  console.log(`[db] ATTEMPTING INSERT into ${ref.path}:`, mappedData);

  const { data: ret, error } = await getSupabase().from(ref.path).insert(mappedData).select().single();
  if (error) {
    console.error(`[db] INSERT REJECTED for ${ref.path}:`, {
      code: error.code,
      message: error.message,
      details: error.details
    });
    if ((error.code === 'PGRST205' || error.code === '42P01') && (ref.path === 'missions' || ref.path === 'announcements' || ref.path === 'weekly_debriefs' || ref.path === 'beta_feedback' || ref.path === 'beta_feedback_notes' || ref.path.startsWith('syndicate_'))) {
      return { id: crypto.randomUUID(), path: ref.path, type: 'doc' };
    }
    throw error;
  }
  console.log(`[db] INSERT SUCCESS into ${ref.path} with ID: ${ret.id}`);
  return { id: ret.id, path: ref.path, type: 'doc' };
};

export const updateDoc = async (ref: any, data: any) => {
  let mappedData = prepareSupabaseData(ref.path, data);
  
  // Smart Merge for JSON fields to prevent data loss
  if (ref.path === 'forecasts' && mappedData.actual_grade) {
    const { data: existing, error: fetchErr } = await getSupabase().from(ref.path).select('actual_grade').eq('id', ref.id).single();
    if (fetchErr) {
      console.warn(`[db] Could not fetch existing data for merge on ${ref.id}:`, fetchErr.message);
    }
    if (existing?.actual_grade) {
      mappedData.actual_grade = {
        ...existing.actual_grade,
        ...mappedData.actual_grade,
        _extra: {
          ...(existing.actual_grade._extra || {}),
          ...(mappedData.actual_grade._extra || {})
        }
      };
    }
  }

  console.log(`[db] ATTEMPTING UPDATE on ${ref.path}/${ref.id}:`, mappedData);
  const { error } = await getSupabase().from(ref.path).update(mappedData).eq('id', ref.id);
  
  if (error) {
    console.error(`[db] UPDATE REJECTED by Database:`, {
      code: error.code,
      message: error.message,
      hint: error.hint,
      details: error.details
    });
    if ((error.code === 'PGRST205' || error.code === '42P01') && (ref.path === 'missions' || ref.path === 'announcements' || ref.path === 'weekly_debriefs' || ref.path === 'beta_feedback' || ref.path === 'beta_feedback_notes' || ref.path.startsWith('syndicate_'))) return;
    throw error;
  }
  console.log(`[db] UPDATE VERIFIED SUCCESS on ${ref.path}/${ref.id}`);
};

export const deleteDoc = async (ref: any) => {
  console.log(`[db] ATTEMPTING DELETE on ${ref.path}/${ref.id}`);
  const { error, count } = await getSupabase().from(ref.path).delete({ count: 'exact' }).eq('id', ref.id);
  
  if (error) {
    console.error(`[db] Supabase delete error on ${ref.path}/${ref.id}:`, error);
    if ((error.code === 'PGRST205' || error.code === '42P01') && (ref.path === 'missions' || ref.path === 'announcements' || ref.path === 'weekly_debriefs' || ref.path === 'beta_feedback' || ref.path === 'beta_feedback_notes')) return;
    throw error;
  }

  if (count === 0) {
    console.warn(`[db] DELETE completed with 0 rows affected. This may be an RLS policy restriction.`);
    if (['beta_feedback', 'beta_feedback_notes'].includes(ref.path)) return;
    throw new Error("Insufficient Permissions: Database rejected the delete request.");
  }
  
  console.log(`[db] DELETE SUCCESS on ${ref.path}/${ref.id}`);
};

export const serverTimestamp = () => new Date().toISOString();

export class Timestamp {
  seconds: number;
  nanoseconds: number;
  constructor(sec: number, nano: number) { this.seconds = sec; this.nanoseconds = nano; }
  toDate() { return new Date(this.seconds * 1000); }
  static now() { return new Timestamp(Math.floor(Date.now() / 1000), 0); }
  static fromDate(d: Date) { return new Timestamp(Math.floor(d.getTime() / 1000), 0); }
}

export type User = {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string | null;
  emailVerified: boolean;
  isAnonymous: boolean;
  providerData: any[];
}

export class GeoPoint {
  latitude: number;
  longitude: number;
  constructor(lat: number, lon: number) { this.latitude = lat; this.longitude = lon; }
  toJSON() { return { lat: this.latitude, lon: this.longitude }; }
}

export const onSnapshot = (ref: any, onNext: any, onError?: any): (() => void) => {
  console.log(`[db] onSnapshot started on ${ref.path} (${ref.type})`);
  const channelName = `ch_${Math.random().toString(36).slice(2)}_${Date.now()}`;
  
  let isStopped = false;
  let channel: any = null;

  // Real-time listener
  const listen = () => {
    if (isStopped) return;
    
    if (ref.type === 'doc') {
      getDocFromServer(ref).then(onNext).catch(onError);
      channel = getSupabase().channel(channelName)
        .on('postgres_changes', { event: '*', schema: 'public', table: ref.path, filter: `id=eq.${ref.id}` }, (payload: any) => {
           if (isStopped) return;
           console.log(`[db] onSnapshot REALTIME EVENT for ${ref.path}/${ref.id}:`, payload.eventType);
           const d = payload.new || payload.old;
           if (!d) {
             getDocFromServer(ref).then(onNext).catch(onError);
             return;
           }
           if (d.actual_grade) {
             if (d.actual_grade._flash_data) d.flash_data = d.actual_grade._flash_data;
             if (d.actual_grade._extra) Object.assign(d, d.actual_grade._extra);
           }
           const converted = convertKeys(d, toCamelCase);
           onNext({ id: ref.id, exists: () => !!d, data: () => d ? converted : null });
        }).subscribe((status: any) => {
          if (!isStopped) {
            console.log(`[db] onSnapshot DOC CHANNEL STATUS for ${ref.path}:`, status);
            if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
              console.warn(`[db] Realtime error on ${ref.path}, will retry...`);
              setTimeout(() => { if (!isStopped) listen(); }, 5000);
            }
          }
        });
    } else {
      getDocs(ref).then(onNext).catch(onError);
      channel = getSupabase().channel(channelName)
        .on('postgres_changes', { event: '*', schema: 'public', table: ref.path }, (payload) => {
           if (isStopped) return;
           console.log(`[db] onSnapshot REALTIME EVENT for ${ref.path} (collection):`, payload.eventType);
           getDocs(ref).then(onNext).catch(onError);
        }).subscribe((status: any) => {
          if (!isStopped) {
            console.log(`[db] onSnapshot COLLECTION CHANNEL STATUS for ${ref.path}:`, status);
            if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
              console.warn(`[db] Realtime error on ${ref.path}, will retry...`);
              setTimeout(() => { if (!isStopped) listen(); }, 5000);
            }
          }
        });
    }
  };

  listen();

  // Polling fallback every 60 seconds
  const pollInterval = setInterval(() => {
    if (isStopped) return;
    console.log(`[db] Pulse check for ${ref.path}`);
    if (ref.type === 'doc') {
      getDocFromServer(ref).then(onNext).catch(onError);
    } else {
      getDocs(ref).then(onNext).catch(onError);
    }
  }, 60000);

  return () => {
    isStopped = true;
    clearInterval(pollInterval);
    if (channel) {
      getSupabase().removeChannel(channel);
    }
    console.log(`[db] onSnapshot stopped for ${ref.path}`);
  };
};

export const arrayUnion = (item: any) => {
   return { __type: 'arrayUnion', value: item };
};
