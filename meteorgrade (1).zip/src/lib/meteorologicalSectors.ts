
export interface MeteorologicalSector {
  id: string;
  name: string;
  description: string;
  multiplier: number;
  color: string;
}

export const METEOROLOGICAL_SECTORS: MeteorologicalSector[] = [
  {
    id: 'plains',
    name: 'Sector: Central Plains',
    description: 'High convective uncertainty. Tornado Alley baseline.',
    multiplier: 1.25,
    color: 'text-amber-500'
  },
  {
    id: 'gulf',
    name: 'Sector: Gulf Coast',
    description: 'Deep moisture profiles and tropical instability.',
    multiplier: 1.20,
    color: 'text-emerald-500'
  },
  {
    id: 'midwest',
    name: 'Sector: Midwest',
    description: 'Variable frontal boundaries and squall line potential.',
    multiplier: 1.15,
    color: 'text-blue-500'
  },
  {
    id: 'northeast',
    name: 'Sector: Northeast',
    description: 'Marine layer complexity and Nor\'easter influence.',
    multiplier: 1.10,
    color: 'text-slate-400'
  },
  {
    id: 'west',
    name: 'Sector: West Coast',
    description: 'Orographic lift and complex boundary layer terrain.',
    multiplier: 1.05,
    color: 'text-indigo-400'
  },
  {
    id: 'baseline',
    name: 'Sector: Standard',
    description: 'Stable synoptic patterns or arid baseline.',
    multiplier: 1.0,
    color: 'text-slate-500'
  }
];

export function resolveSector(lat: number | null, lon: number | null): MeteorologicalSector {
  if (lat === null || lon === null) return METEOROLOGICAL_SECTORS[5]; // Baseline

  // Rough bounding boxes for US Sectors
  // Central Plains (Approx: KS, NE, OK, TX Panhandle, SD, ND)
  if (lat > 32 && lat < 49 && lon > -105 && lon < -95) return METEOROLOGICAL_SECTORS[0];
  
  // Gulf Coast (Approx: TX South, LA, MS, AL, FL)
  if (lat > 24 && lat < 32 && lon > -98 && lon < -79) return METEOROLOGICAL_SECTORS[1];

  // Midwest (Approx: IL, IN, OH, MO, IA, WI, MI)
  if (lat > 36 && lat < 49 && lon > -95 && lon < -80) return METEOROLOGICAL_SECTORS[2];

  // Northeast (Approx: NY, PA, NJ, MD, DE, CT, RI, MA, VT, NH, ME)
  if (lat > 38 && lat < 48 && lon > -80 && lon < -66) return METEOROLOGICAL_SECTORS[3];

  // West Coast (Approx: CA, OR, WA)
  if (lat > 32 && lat < 49 && lon > -125 && lon < -116) return METEOROLOGICAL_SECTORS[4];

  return METEOROLOGICAL_SECTORS[5]; // Default Baseline
}
