/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, Component, ErrorInfo, ReactNode } from 'react';
import { 
  auth, 
  onSnapshot, 
  collection, 
  query, 
  where, 
  orderBy, 
  limit, 
  doc, 
  getDoc,
  getDocFromServer, 
  setDoc, 
  serverTimestamp, 
  User,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  db
} from './lib/db';
import { 
  Cloud, 
  Sun, 
  Wind, 
  Thermometer, 
  LogIn, 
  LogOut, 
  Plus, 
  History,
  TrendingUp,
  Award,
  Search,
  MapPin,
  Calendar as CalendarIcon,
  Menu,
  Globe,
  X,
  Smartphone,
  Radio,
  Shield,
  Zap,
  Activity,
  Share,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getAIGrade, getActualHistoricalGrade } from './services/geminiService';
import { syncFlashpoints } from './services/nwsService';
import { PreferencesProvider } from './lib/preferences';
import NewForecastForm from './components/NewForecastForm';

import ForecastList from './components/ForecastList';
import Sidebar from './components/Sidebar';
import BetaFeedbackFAB from './components/BetaFeedbackFAB';
import AnalyticsDashboard from './components/DashboardView';
import LeaderboardView from './components/LeaderboardView';
import CampaignsView from './components/CampaignsView';
import CreditsView from './components/CreditsView';
import WeeklyDebriefView from './components/WeeklyDebriefView';
import RadarView from './components/RadarView';
import LandingPageView from './components/LandingPageView';
import OnboardingView from './components/OnboardingView';
import SupportView from './components/SupportView';
import AdminPanelView from './components/AdminPanelView';
import FlashpointOverlay from './components/FlashpointOverlay';
import FlashForecastForm from './components/FlashForecastForm';
import { NotificationSettings } from './components/NotificationSettings';
import ProfileSettingsModal from './components/ProfileSettingsModal';
import SubscriptionView from './components/SubscriptionView';
import DeepDiveModal from './components/DeepDiveModal';
import SyndicateView from './components/SyndicateView';
import StrategicDeploymentMap from './components/StrategicDeploymentMap';


class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean, error: Error | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught application error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-10 font-mono">
          <div className="max-w-2xl w-full space-y-6 border border-red-500/30 p-8 bg-red-500/5">
            <h1 className="text-red-500 font-bold uppercase tracking-widest text-sm flex items-center gap-2">
              <X size={20} /> System Execution Failure
            </h1>
            <p className="text-slate-400 text-xs leading-relaxed">
              The application encountered a critical runtime exception. This may be due to missing configuration or local storage corruption.
            </p>
            <div className="bg-black/50 p-4 border border-white/10 rounded overflow-auto max-h-64">
              <code className="text-red-400 text-[10px] whitespace-pre-wrap">{this.state.error?.toString()}</code>
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-white text-black font-bold uppercase tracking-widest text-[10px] hover:bg-red-500 hover:text-white transition-colors"
            >
              Restart Terminal
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}

function AppContent() {
  const ADMIN_EMAIL = 'tylerleedixon@gmail.com';
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<any>(null);
  const profileRef = useRef<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    profileRef.current = profile;
  }, [profile]);
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'choice'>('choice');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showNewForm, setShowNewForm] = useState(false);
  const [activeView, setActiveView] = useState('dashboard');
  const [showSubscription, setShowSubscription] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const [forecasts, setForecasts] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'stable' | 'isolated'>('stable');
  const [nwsSyncStatus, setNwsSyncStatus] = useState<{ lastSync: Date | null, isSyncing: boolean }>({
    lastSync: null,
    isSyncing: false
  });

  const [theme, setTheme] = useState<'light' | 'dark' | 'amber' | 'cyberpunk'>(() => {
    return (localStorage.getItem('terminal_theme') as 'light' | 'dark' | 'amber' | 'cyberpunk') || 'light';
  });

  useEffect(() => {
    document.documentElement.classList.remove('dark', 'theme-amber', 'theme-cyberpunk');
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (theme === 'amber') {
      document.documentElement.classList.add('theme-amber');
    } else if (theme === 'cyberpunk') {
      document.documentElement.classList.add('theme-cyberpunk');
    }
    localStorage.setItem('terminal_theme', theme);
  }, [theme]);

  useEffect(() => {
    const handleOpenSettings = () => setIsProfileModalOpen(true);
    const handleOpenSubscription = () => {
      setActiveView('subscription');
      setIsSidebarOpen(false);
    };
    const handleOpenDeepDive = (e: any) => setDeepDiveTarget(e.detail);

    window.addEventListener('open-profile-settings', handleOpenSettings);
    window.addEventListener('open-subscription', handleOpenSubscription);
    window.addEventListener('open-deep-dive', handleOpenDeepDive);
    
    return () => {
      window.removeEventListener('open-profile-settings', handleOpenSettings);
      window.removeEventListener('open-subscription', handleOpenSubscription);
      window.removeEventListener('open-deep-dive', handleOpenDeepDive);
    };
  }, []);

  const [showInstallGuide, setShowInstallGuide] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [deepDiveTarget, setDeepDiveTarget] = useState<any | null>(null);
  const [activeFlashpoints, setActiveFlashpoints] = useState<any[]>([]);
  const [activeAlertDetail, setActiveAlertDetail] = useState<any | null>(null);
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [isIframe, setIsIframe] = useState(false);

  useEffect(() => {
    setIsIframe(window.self !== window.top);
  }, []);

  const handleDatabaseError = (err: any, source: string) => {
    console.error(`${source} Error:`, err);
    if (err?.message?.includes('Quota exceeded') || err?.code === 'resource-exhausted') {
      setQuotaExceeded(true);
    }
  };

  useEffect(() => {
    // Check for auth errors in URL hash
    const hash = window.location.hash;
    if (hash && hash.includes('error_description') && hash.includes('access_token')) {
      const params = new URLSearchParams(hash.substring(1));
      const error = params.get('error_description');
      if (error) setLoginError(`Auth Error: ${error.replace(/\+/g, ' ')}`);
    }

    // Failsafe: stop loading after timeout
    const failsafeT = setTimeout(() => {
      setLoading(false);
    }, 5000);

    const unsubscribe = onAuthStateChanged(auth, (u) => {
      console.log(`[App] Auth Update: ${u ? u.email : 'No session'}`);
      setUser(u);
      setLoading(false);
      clearTimeout(failsafeT);
    });

    return () => {
      clearTimeout(failsafeT);
      unsubscribe();
    };
  }, []);

  // Profile Sync & Connection Test (When User changes)
  useEffect(() => {
    if (!user) {
      setProfile(null);
      setConnectionStatus('stable');
      return;
    }

    const initUser = async () => {
      try {
        // Connection Check
        await getDocFromServer(doc(db, 'users', user.uid));
        setConnectionStatus('stable');

        // Initial Profile Sync
        const userDocRef = doc(db, 'users', user.uid);
        const userSnap = await getDoc(userDocRef);
        const isAdmin = user.email?.toLowerCase() === ADMIN_EMAIL;

        if (!userSnap.exists()) {
          await setDoc(userDocRef, {
            email: user.email,
            displayName: user.displayName || user.email?.split('@')[0] || 'Unknown Analyst',
            avatarUrl: user.photoURL || null,
            createdAt: serverTimestamp(),
            totalForecasts: 0,
            precisionIndex: 0,
            tier: 'Novice',
            membership: 'basic',
            role: isAdmin ? 'admin' : 'user',
            onboarded: false
          });
        } else {
          // Migration: Ensure membership exists
          if (!userSnap.data()?.membership) {
            await setDoc(userDocRef, { membership: 'basic' }, { merge: true });
          }
          if (isAdmin && userSnap.data()?.role !== 'admin') {
            await setDoc(userDocRef, { role: 'admin' }, { merge: true });
          }
          // Sync photoURL if it exists in auth but not in profile
          if (user.photoURL && !userSnap.data()?.avatarUrl) {
            await setDoc(userDocRef, { avatarUrl: user.photoURL }, { merge: true });
          }
        }
      } catch (err: any) {
        console.warn("Init User Sync Error:", err.message);
        if (err.message?.includes('offline')) setConnectionStatus('isolated');
      }
    };

    initUser();
  }, [user]);

  // Phase 1 Listeners: Critical "Live" Data (Profile + Flashpoints)
  useEffect(() => {
    if (!user) return;

    console.log("[App] Phase 1 Sync: Profile and Live Flashpoints");
    const unsubProfile = onSnapshot(doc(db, 'users', user.uid), (snap) => {
      if (snap.exists()) setProfile(snap.data());
    }, (err) => handleDatabaseError(err, "Profile"));

    const unsubFlash = onSnapshot(
      query(collection(db, 'flashpoints'), where('isActive', '==', true)),
      (snap) => {
        const flashes = snap.docs.map(d => ({ id: d.id, ...d.data() }))
          .filter((f: any) => !f.expires || new Date(f.expires) > new Date());
        setActiveFlashpoints(flashes);
      }, (err) => handleDatabaseError(err, "Flashpoints"));

    return () => {
      unsubProfile();
      unsubFlash();
    };
  }, [user]);

  // Phase 2 Listeners: Historical Data (Forecasts) - Deferred to prioritize initial render
  useEffect(() => {
    if (!user) return;

    const cleanupFuncs: (() => void)[] = [];

    // Wait 1.2s before fetching history to let the live dashboard settle
    const deferTimer = setTimeout(() => {
      console.log(`[App] Phase 2 Sync starting for ${user.uid} (${user.email})`);
      const qForecasts = query(
        collection(db, 'forecasts'),
        where('userId', '==', user.uid),
        orderBy('createdAt', 'desc'),
        limit(500)
      );
      
      const unsubForecasts = onSnapshot(qForecasts, (snap) => {
        const fs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        console.log(`[App] Success: Sync complete. Forecast count: ${fs.length}`);
        setForecasts(fs);
      }, (err) => {
        console.error("[App] Phase 2 Forecast Sync Error:", err);
        handleDatabaseError(err, "Forecasts");
      });

      cleanupFuncs.push(unsubForecasts);
    }, 800);

    return () => {
      clearTimeout(deferTimer);
      cleanupFuncs.forEach(c => c());
    };
  }, [user]);

  // Phase 3 Logic: Metrics & Analytics Calculation - Moved out of the listener to reduce churn
  const isUpdatingMetrics = useRef(false);
  useEffect(() => {
    if (!user || forecasts.length === 0 || isUpdatingMetrics.current) return;

    const completed = forecasts.filter((f: any) => f.status === 'completed' && f.actualGrade);
    if (completed.length === 0) return;

    const rawAvg = completed.reduce((a, b: any) => a + (b.actualGrade?.score || 0), 0) / completed.length;
    const pi = Number((rawAvg * (1 + Math.min(completed.length / 50, 1) * 0.5)).toFixed(1));
    
    let tier = 'Novice';
    if (pi > 120) tier = 'Legend';
    else if (pi > 90) tier = 'Sage';
    else if (pi > 40) tier = 'Specialist';

    const currentPr = profileRef.current;
    if (currentPr && (Math.abs(currentPr.precisionIndex - pi) > 0.1 || currentPr.totalForecasts !== forecasts.length)) {
      console.log("[App] Logic: Recalculating Analyst Status...");
      isUpdatingMetrics.current = true;
      setDoc(doc(db, 'users', user.uid), {
        precisionIndex: pi,
        tier,
        totalForecasts: forecasts.length,
        averageAccuracy: Math.round(rawAvg)
      }, { merge: true })
        .then(() => {
          setTimeout(() => { isUpdatingMetrics.current = false; }, 2000);
        })
        .catch(e => {
          console.warn("Metrics update failed", e);
          isUpdatingMetrics.current = false;
        });
    }
  }, [forecasts, user]);

  // Phase 4: Admin Background Services - Deferred even further
  useEffect(() => {
    if (user?.email?.toLowerCase() !== 'tylerleedixon@gmail.com') return;

    const adminTimer = setTimeout(() => {
      console.log("[App] Phase 4 Sync: Admin Background Services");
      const performSync = async () => {
        setNwsSyncStatus(prev => ({ ...prev, isSyncing: true }));
        try {
          await syncFlashpoints();
          setNwsSyncStatus({ lastSync: new Date(), isSyncing: false });
        } catch (err) {
          console.warn("NWS Sync Error:", err);
          setNwsSyncStatus(prev => ({ ...prev, isSyncing: false }));
        }
      };

      performSync();
      const interval = setInterval(performSync, 300000);
      cleanupsRef.current.push(() => clearInterval(interval));
    }, 5000);

    const cleanupsRef = { current: [] as (() => void)[] };

    return () => {
      clearTimeout(adminTimer);
      cleanupsRef.current.forEach(c => c());
    };
  }, [user]);


  const handleLogin = async () => {
    setLoginLoading(true);
    setLoginError(null);
    
    // Check if Supabase is configured
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    if (!supabaseUrl || supabaseUrl.includes('placeholder')) {
      setLoginLoading(false);
      setLoginError("Meteorological Database not configured. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in project settings.");
      return;
    }

    const provider = new GoogleAuthProvider();
    
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      console.error("Login failed", error);
      setLoginLoading(false);
      
      const msg = error.message || String(error);
      if (msg.includes('Popup blocked')) {
        setLoginError("The authentication window was blocked by your browser. Please allow popups or use the button below to open the hub in a new tab.");
      } else {
        setLoginError(`Diagnostic Error: ${msg}. If this persists, try opening the app in a new browser tab.`);
      }
    }
  };

  const isInIframe = window.self !== window.top;
  const sharedUrl = window.location.origin;

  const handleLogout = () => signOut(auth);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError(null);
    try {
      if (authMode === 'signup') {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (error: any) {
      console.error("Email auth failed", error);
      setLoginLoading(false);
      if (error.code === 'auth/weak-password') {
        setLoginError("Password must be at least 6 characters.");
      } else if (error.code === 'auth/email-already-in-use') {
        setLoginError("This email is already registered. Try logging in instead.");
      } else if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        setLoginError("Invalid email or password.");
      } else {
        setLoginError(`Authentication Error: ${error.message}`);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center font-mono">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
        >
          <Cloud size={48} className="text-indigo-600" />
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <LandingPageView 
          authMode={authMode}
          setAuthMode={setAuthMode}
          loginLoading={loginLoading}
          loginError={loginError}
          handleLogin={handleLogin}
          handleEmailAuth={handleEmailAuth}
          email={email}
          setEmail={setEmail}
          password={password}
          setPassword={setPassword}
          setShowInstallGuide={setShowInstallGuide}
          isIframe={isIframe}
        />
        <AnimatePresence>
          {showInstallGuide && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[100] flex items-center justify-center p-6"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-white max-w-sm w-full p-8 shadow-[20px_20px_0px_#6366f1] space-y-8"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Satellite Link</span>
                    <h3 className="text-2xl font-light uppercase tracking-tighter mt-1">Installation <span className="font-bold">Guide</span></h3>
                  </div>
                  <button onClick={() => setShowInstallGuide(false)} className="text-slate-400 hover:text-slate-900 transition-colors">
                    <X size={20} />
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="space-y-3">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-900 flex items-center gap-2">
                       <div className="w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 text-[9px]">1</div>
                       For Android / Chrome
                    </h4>
                    <p className="text-xs text-slate-500 leading-relaxed pl-7">
                      Tap the <span className="font-bold text-slate-900">three dots (⋮)</span> in Chrome and select <span className="font-bold text-indigo-600">"Install App"</span> or <span className="font-bold text-slate-900">"Add to Home screen."</span>
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-900 flex items-center gap-2">
                      <div className="w-5 h-5 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 text-[9px]">2</div>
                      For iOS / Safari
                    </h4>
                    <p className="text-xs text-slate-500 leading-relaxed pl-7">
                      Tap the <span className="font-bold text-slate-900">Share icon (□ with ↑)</span> and select <span className="font-bold text-indigo-600">"Add to Home Screen."</span>
                    </p>
                  </div>

                  <div className="bg-slate-50 p-4 border-l-4 border-indigo-600">
                    <p className="text-[10px] text-slate-600 leading-relaxed italic">
                      "Once installed, the Intelligence Bureau will run in full-screen mode, bypassing browser interference."
                    </p>
                  </div>
                </div>

                <button 
                  onClick={() => setShowInstallGuide(false)}
                  className="w-full bg-slate-900 text-white font-bold py-4 text-[11px] uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-[8px_8px_0px_#f1f5f9] font-mono"
                >
                  Confirm Satellite Pair
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }

  const handleRestartOnboarding = async () => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'users', user.uid), { onboarded: false }, { merge: true });
      // The onSnapshot listener in App.tsx will pick up this change and show the OnboardingView
    } catch (err) {
      console.error("Failed to restart calibration:", err);
    }
  };

  const renderView = () => {
    console.log(`[App] Rendering view: ${activeView}`);
    switch(activeView) {
      case 'dashboard': 
        return (
          <div className="flex flex-col gap-12">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-[0.25em] text-slate-400 mb-2 underline decoration-indigo-500 underline-offset-8">Active Monitor</h2>
                <p className="text-slate-500 max-w-xl text-sm leading-relaxed">
                  Real-time prediction streams and synchronization control.
                </p>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setShowNewForm(true)}
                  className="bg-slate-900 text-white py-4 px-10 hover:bg-indigo-600 transition-all font-bold uppercase tracking-[0.2em] text-[11px] flex items-center gap-3 whitespace-nowrap shadow-[8px_8px_0px_#f1f5f9]"
                >
                  <Plus size={16} />
                  Submit Forecast
                </button>
              </div>
            </div>
            <ForecastList user={user} forecasts={forecasts} profile={profile} />
          </div>
        );
      case 'analytics':
        return (
          <AnalyticsDashboard 
            forecasts={forecasts} 
            flashpoints={activeFlashpoints} 
            profile={profile}
            onTrackSignal={(fps: any) => {
              setActiveAlertDetail(fps);
              setActiveView('radar');
            }} 
          />
        );
      case 'radar':
        return <RadarView forecasts={forecasts} flashpoints={activeFlashpoints} onRefocus={activeAlertDetail} profile={profile} />;
      case 'leaderboard':
        return <LeaderboardView />;
      case 'syndicates':
        return <SyndicateView user={user} profile={profile} />;
      case 'deployment':
        return <StrategicDeploymentMap user={user} profile={profile} />;
      case 'missions':
        return <CampaignsView user={{ ...user, ...profile }} forecasts={forecasts} />;
      case 'subscription':
        return <SubscriptionView user={user} profile={profile} />;
      case 'debrief':
        return <WeeklyDebriefView user={user} profile={profile} />;
      case 'credits':
        return <CreditsView />;
      case 'settings':
        return (
          <div className="max-w-4xl space-y-12">
            <div>
              <h2 className="text-sm font-bold uppercase tracking-[0.25em] text-slate-400 mb-2 underline decoration-indigo-500 underline-offset-8">Analyst Configuration</h2>
              <p className="text-slate-500 max-w-xl text-sm leading-relaxed">
                Manage your profile, synchronization units, and high-priority pulse notifications.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-8">
                <section>
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-900 mb-4 flex items-center gap-2">
                    <Smartphone size={14} className="text-indigo-600" />
                    Pulse Communications
                  </h3>
                  <NotificationSettings user={user} />
                </section>
                
                <section className="bg-white border border-slate-100 p-8 shadow-[12px_12px_0px_#f8fafc]">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-900 mb-4 flex items-center gap-2">
                    <Globe size={14} className="text-indigo-600" />
                    Atmospheric Units
                  </h3>
                  <p className="text-xs text-slate-500 mb-6">Select your preferred unit system for global weather diagnostics.</p>
                  <div className="flex gap-4">
                    <button 
                      onClick={() => setIsProfileModalOpen(true)}
                      className="bg-slate-900 text-white py-3 px-6 text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-[4px_4px_0px_#f1f5f9]"
                    >
                      Update Profile Preferences
                    </button>
                  </div>
                </section>
              </div>

              <div className="space-y-8">
                <section className="bg-slate-900 text-white p-8 shadow-[12px_12px_0px_#6366f1]">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 mb-4 flex items-center gap-2">
                    <Shield size={14} />
                    Security & Identity
                  </h3>
                  <div className="space-y-4">
                    <div className="border-l-2 border-indigo-500 pl-4 py-1">
                      <p className="text-[9px] text-indigo-300 uppercase tracking-[0.2em] font-bold mb-1">Authenticated As</p>
                      <p className="text-sm font-mono">{user.email}</p>
                    </div>
                    <div className="border-l-2 border-slate-700 pl-4 py-1">
                      <p className="text-[9px] text-slate-500 uppercase tracking-[0.2em] font-bold mb-1">Analyst Status</p>
                      <p className="text-sm font-bold text-amber-400">{profile?.tier || 'Novice'}</p>
                    </div>
                    <button 
                      onClick={handleLogout}
                      className="w-full mt-6 py-3 border border-white/10 text-[10px] font-bold uppercase tracking-widest hover:bg-red-600 hover:border-red-600 transition-all"
                    >
                      Terminate Session
                    </button>
                  </div>
                </section>

                <section className="bg-emerald-50 border border-emerald-100 p-8">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-emerald-900 mb-2">Calibration Status</h3>
                  <p className="text-[11px] text-emerald-700 leading-relaxed mb-4">
                    Your analysis terminal is currently synchronized with the Global Meteorology Bureau.
                  </p>
                  <button 
                    onClick={handleRestartOnboarding}
                    className="text-[10px] font-bold text-emerald-900 underline underline-offset-4 hover:text-emerald-600 transition-colors"
                  >
                    Recalibrate Onboarding Sequence
                  </button>
                </section>
              </div>
            </div>
          </div>
        );
      case 'support':
        return <SupportView user={user} onRestartOnboarding={handleRestartOnboarding} />;
      case 'admin':
        const isAdmin = user?.email?.toLowerCase() === 'tylerleedixon@gmail.com';
        return isAdmin ? (
          <AdminPanelView 
            currentUser={user}
            syncStatus={nwsSyncStatus} 
            onTriggerSync={async () => {
              setNwsSyncStatus(prev => ({ ...prev, isSyncing: true }));
              try {
                await syncFlashpoints();
                setNwsSyncStatus({ lastSync: new Date(), isSyncing: false });
              } catch (err) {
                console.error("Manual NWS Sync Error:", err);
                setNwsSyncStatus(prev => ({ ...prev, isSyncing: false }));
              }
            }}
          />
        ) : <AnalyticsDashboard forecasts={forecasts} flashpoints={activeFlashpoints} profile={profile} />;
      default:
        return <div>View not found</div>;
    }
  };

  return (
    <PreferencesProvider userId={user?.uid}>
      {profile && !profile.onboarded && (
        <OnboardingView 
          user={user} 
          profile={profile} 
          onComplete={() => setProfile({...profile, onboarded: true})} 
        />
      )}
      <div className="min-h-screen theme-bg-app theme-text-primary font-sans flex flex-col lg:flex-row h-screen overflow-hidden">
        {quotaExceeded && (
          <div className="fixed top-0 inset-x-0 bg-red-600 text-white text-[10px] font-bold uppercase tracking-[0.3em] py-2 px-6 z-[200] text-center flex items-center justify-center gap-4">
            <Zap size={14} className="animate-pulse" />
            <span>Operational Limit Exceeded: AI Capacity Reached. System will reset shortly.</span>
            <button onClick={() => setQuotaExceeded(false)} className="ml-auto opacity-60 hover:opacity-100"><X size={14} /></button>
          </div>
        )}
        {/* Mobile Header */}

      <header className="lg:hidden h-16 border-b theme-border px-6 flex items-center justify-between theme-bg-header shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white text-[10px] font-bold overflow-hidden">
            {profile?.avatarUrl ? (
              <img src={profile.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              user.displayName?.[0] || 'U'
            )}
          </div>
          <h1 className="text-sm font-light tracking-tighter">
            METEOR<span className="font-bold text-slate-900">GRADE</span>
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end mr-2">
            <span className="text-[7px] font-bold text-slate-300 uppercase tracking-widest leading-none">Status</span>
            <span className={`text-[9px] font-mono leading-none mt-1 ${connectionStatus === 'stable' ? 'text-indigo-600' : 'text-amber-500 animate-pulse'}`}>
              {connectionStatus === 'stable' ? 'Stable' : 'Isolated'}
            </span>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="w-10 h-10 flex items-center justify-center text-slate-900 border border-slate-100 shadow-sm"
          >
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      {/* Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar Container */}
      <div className={`
        fixed inset-y-0 left-0 z-50 transform transition-transform duration-300 lg:relative lg:translate-x-0 w-64 shrink-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <Sidebar 
          activeView={activeView} 
          setActiveView={(view) => {
            console.log(`[Navigation] ATTEMPTING SWITCH TO: ${view} (from ${activeView})`);
            setActiveView(view);
            setIsSidebarOpen(false);
          }} 
          onLogout={handleLogout} 
          profile={profile}
        />
      </div>

      <main className={`flex-1 overflow-y-auto ${activeView === 'admin' ? 'p-0' : 'p-6 md:p-16'}`}>
        <FlashpointOverlay 
          alerts={activeFlashpoints} 
          onViewAlert={(alert) => setActiveAlertDetail(alert)} 
        />

        <AnimatePresence>
          {activeAlertDetail && (
            <FlashForecastForm 
              alert={activeAlertDetail} 
              user={user} 
              onClose={() => setActiveAlertDetail(null)} 
            />
          )}
        </AnimatePresence>

        <header className="hidden lg:flex justify-between items-center mb-16">
          <div className="flex flex-col">
            <span className="text-[10px] font-bold tracking-[0.2em] uppercase theme-text-secondary">Section / {activeView}</span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end">
              <span className="text-[9px] font-bold theme-text-secondary uppercase tracking-widest">Atmosphere</span>
              <span className={`text-[11px] font-mono ${connectionStatus === 'stable' ? 'text-indigo-600' : 'text-amber-500 animate-pulse'}`}>
                {connectionStatus === 'stable' ? 'Stable' : 'Isolated'}
              </span>
            </div>
            <div className="flex items-center gap-3 theme-bg-secondary border theme-border pl-4 pr-1 py-1 rounded-full group hover:border-indigo-200 transition-colors">
              <div className="flex flex-col items-end mr-1">
                <span className="text-[8px] font-bold theme-text-secondary uppercase tracking-tighter leading-none mb-0.5">Analyst</span>
                <span className="text-[10px] font-bold theme-text-primary leading-none">@{profile?.displayName?.split(' ')[0].toLowerCase() || 'analyst'}</span>
              </div>
              <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white text-[10px] font-bold overflow-hidden shadow-sm">
                {profile?.avatarUrl ? (
                  <img src={profile.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  user.displayName?.[0] || 'U'
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Global Data Feed */}
        <div className="hidden lg:block mb-12 overflow-hidden border-y theme-border py-3 theme-bg-secondary/50">
          <div className="flex whitespace-nowrap animate-marquee">
            {[
              { icon: <Radio size={12} />, text: `CONNECTION STATUS: ${navigator.onLine ? 'OPTIMAL' : 'DEGRADED'} //` },
              { icon: <Zap size={12} />, text: `SEVERE WEATHER EVENTS: ${activeFlashpoints.length} DETECTED //` },
              { icon: <Shield size={12} />, text: `ANALYST LEVEL: ${profile?.tier || 'UNRANKED'} //` },
              { icon: <TrendingUp size={12} />, text: `PRECISION INDEX: ${typeof profile?.precisionIndex === 'number' ? profile.precisionIndex.toFixed(1) : (profile?.precisionIndex || 0)} PI //` },
              { icon: <MapPin size={12} />, text: `LAST NWS SYNC: ${nwsSyncStatus.lastSync?.toLocaleTimeString() || 'PENDING'} //` }
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 px-8 border-r theme-border last:border-r-0">
                <span className="text-indigo-600">{item.icon}</span>
                <span className="text-[9px] font-black theme-text-secondary uppercase tracking-[0.2em] font-mono">{item.text}</span>
              </div>
            ))}
            {/* Duplicate for infinite loop */}
            {[
              { icon: <Radio size={12} />, text: `CONNECTION STATUS: ${navigator.onLine ? 'OPTIMAL' : 'DEGRADED'} //` },
              { icon: <Zap size={12} />, text: `SEVERE WEATHER EVENTS: ${activeFlashpoints.length} DETECTED //` },
              { icon: <Shield size={12} />, text: `ANALYST LEVEL: ${profile?.tier || 'UNRANKED'} //` },
              { icon: <TrendingUp size={12} />, text: `PRECISION INDEX: ${typeof profile?.precisionIndex === 'number' ? profile.precisionIndex.toFixed(1) : (profile?.precisionIndex || 0)} PI //` },
              { icon: <MapPin size={12} />, text: `LAST NWS SYNC: ${nwsSyncStatus.lastSync?.toLocaleTimeString() || 'PENDING'} //` }
            ].map((item, i) => (
              <div key={`dup-${i}`} className="flex items-center gap-3 px-8 border-r theme-border last:border-r-0">
                <span className="text-indigo-600">{item.icon}</span>
                <span className="text-[9px] font-black theme-text-secondary uppercase tracking-[0.2em] font-mono">{item.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* View Header for Mobile */}
        <div className="lg:hidden mb-8 border-b border-slate-100 pb-4">
          <span className="text-[9px] font-bold tracking-[0.2em] uppercase text-indigo-600">{activeView}</span>
        </div>

        <AnimatePresence mode="wait">
          <motion.div 
            key={activeView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>

        <GlobalModals 
          user={user}
          profile={profile}
          setProfile={setProfile}
          isProfileModalOpen={isProfileModalOpen}
          setIsProfileModalOpen={setIsProfileModalOpen}
          showNewForm={showNewForm}
          setShowNewForm={setShowNewForm}
          deepDiveTarget={deepDiveTarget}
          setDeepDiveTarget={setDeepDiveTarget}
          theme={theme}
          setTheme={setTheme}
        />

        <BetaFeedbackFAB user={user} />

        <footer className="mt-20 space-y-8 border-t theme-border pt-12 pb-12">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-4 max-w-lg">
              <div className="flex items-center gap-3">
                 <Shield size={16} className="text-indigo-500" />
                 <span className="text-[10px] font-black uppercase tracking-[0.3em] theme-text-primary">Safety Protocol Directive</span>
              </div>
              <p className="text-[11px] theme-text-muted leading-relaxed uppercase tracking-widest font-bold border-l-2 border-indigo-500 pl-4 bg-indigo-500/5 py-4 pr-6 text-indigo-900 dark:text-indigo-100">
                For educational and competitive use only. Refer to the NWS for official life-safety warnings.
              </p>
              <p className="text-[9px] theme-text-muted leading-relaxed uppercase tracking-[0.2em] opacity-60">
                MeteorGrade analytics are forensic simulations and should not be used for localized tactical decisions during active tornadic or hydrological threats. Always prioritize official government meteorological broadcasts.
              </p>
            </div>
            <div className="flex flex-col items-end gap-2 text-[8px] font-mono theme-text-muted uppercase tracking-widest">
               <span>© 2026 Global Meteorology Bureau // v2.4.0</span>
               <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1"><Activity size={8} className="text-emerald-500" /> System.Nominal</span>
                  <span className="flex items-center gap-1"><Radio size={8} className="text-indigo-500" /> Uplink.Active</span>
               </div>
            </div>
          </div>
        </footer>
      </main>
    </div>
    </PreferencesProvider>
  );
}

function GlobalModals({ user, profile, setProfile, isProfileModalOpen, setIsProfileModalOpen, showNewForm, setShowNewForm, deepDiveTarget, setDeepDiveTarget, theme, setTheme }: any) {
  return (
    <>
      <ProfileSettingsModal 
        isOpen={isProfileModalOpen} 
        onClose={() => setIsProfileModalOpen(false)} 
        profile={profile}
        setProfile={setProfile}
        theme={theme}
        setTheme={setTheme}
      />
      <DeepDiveModal 
        isOpen={!!deepDiveTarget}
        onClose={() => setDeepDiveTarget(null)}
        forecast={deepDiveTarget}
      />
      <AnimatePresence>
        {showNewForm && (
          <NewForecastForm 
            onClose={() => setShowNewForm(false)} 
            user={user}
            profile={profile}
          />
        )}
      </AnimatePresence>
    </>
  );
}
