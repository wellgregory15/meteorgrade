import { doc, setDoc, getDoc, arrayUnion, db } from '../lib/db';

const VAPID_PUBLIC_KEY = (import.meta.env.VITE_VAPID_KEY && import.meta.env.VITE_VAPID_KEY.length > 20) 
  ? import.meta.env.VITE_VAPID_KEY 
  : 'BMVhPPfW7m9VMZzm4PEYCcu3Xd-Oklga_fXKWAi377m-vpckdv5hvNEzLgBP2CbBmjhdQGz-clrhqSSO7ObgjEM';

export async function requestNotificationPermission() {
  if (!('Notification' in window)) {
    console.error('This browser does not support notifications.');
    return false;
  }

  const permission = await Notification.requestPermission();
  return permission === 'granted';
}

export async function registerPushSubscription(userId: string) {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    console.warn('[Push] Service Worker or Push Manager not supported');
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    
    // Check if we already have a subscription
    let subscription = await registration.pushManager.getSubscription();
    
    // Check if the key has changed since last registration
    const lastKey = localStorage.getItem('mg_vapid_key');
    const keyChanged = lastKey !== VAPID_PUBLIC_KEY;

    if (subscription && keyChanged) {
      console.log('[Push] Key mismatch detected. Resetting subscription.');
      await subscription.unsubscribe();
      subscription = null;
    }

    if (!subscription || keyChanged) {
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
      });

      console.log('[Push] Registered with signaling coordinates');
      
      // Store subscription in Supabase
      const userRef = doc(db, 'users', userId);
      await setDoc(userRef, {
        pushSubscriptions: arrayUnion(JSON.stringify(subscription)),
        notificationsEnabled: true
      }, { merge: true });

      localStorage.setItem('mg_vapid_key', VAPID_PUBLIC_KEY);
    }

    console.log('[Push] Subscription synchronized with Bureau Hub');
    return true;
  } catch (error) {
    console.error('[Push] Synchronization failed:', error);
    return false;
  }
}

export async function unregisterPushSubscription(userId: string) {
  if (!('serviceWorker' in navigator)) return false;

  try {
    const registration = await navigator.serviceWorker.getRegistration();
    if (registration) {
      const subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        const subJson = JSON.stringify(subscription);
        await subscription.unsubscribe();
        
        // Try to remove this specific sub from the array if possible
        // Note: Our arrayUnion/ shim doesn't support arrayRemove easily, 
        // but setting notificationsEnabled to false is the priority.
      }
    }

    // Update Supabase
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, {
      notificationsEnabled: false
    }, { merge: true });

    console.log('[Push] Subscription revoked');
    return true;
  } catch (error) {
    console.error('[Push] Revocation failed:', error);
    return false;
  }
}

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
