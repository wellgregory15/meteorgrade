import { collection, query, where, getDocs, addDoc, serverTimestamp, updateDoc, doc, GeoPoint, limit } from '../lib/db';
import { db } from '../lib/db';
import { generateMissionInfo } from './geminiService';

const playAlertSound = () => {
  try {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    audio.volume = 0.4;
    audio.play().catch(() => {
      // Browsers often block audio until first user interaction
    });
  } catch (err) {
    // Fail silently
  }
};

const NWS_API_BASE = 'https://api.weather.gov/alerts/active';

export interface NWSAlert {
  id: string;
  properties: {
    event: string;
    areaDesc: string;
    severity: string;
    urgency: string;
    certainty: string;
    description: string;
    instruction?: string;
    effective?: string;
    expires: string;
    parameters?: {
       NWSheadline?: string[];
    };
  };
  geometry?: {
    type: string;
    coordinates: any;
  };
}

// Internal helper to broadcast to server
async function broadcastNotification(title: string, body: string) {
  try {
    // 1. Get tokens from users with notifications enabled
    const q = query(collection(db, 'users'), where('notificationsEnabled', '==', true), limit(500));
    const snap = await getDocs(q);
    const tokens: string[] = [];
    snap.docs.forEach(d => {
      const data = d.data();
      if (data.pushSubscriptions && Array.isArray(data.pushSubscriptions)) {
        tokens.push(...data.pushSubscriptions);
      }
    });

    if (tokens.length === 0) return;

    // 2. Call server endpoint
    await fetch('/api/notifications/broadcast', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, body, tokens })
    });
  } catch (err) {
    console.error("Failed to broadcast notification:", err);
  }
}

let alertCache: { data: NWSAlert[], timestamp: number } | null = null;
const CLIENT_CACHE_TTL = 60000; // 60 seconds client-side cache

export async function fetchActiveNWSAlerts(): Promise<NWSAlert[] | null> {
  // Check client-side cache first
  if (alertCache && (Date.now() - alertCache.timestamp < CLIENT_CACHE_TTL)) {
    return alertCache.data;
  }

  try {
    // Removing specific filters to ensure we catch all offices/events as requested
    const response = await fetch(`/api/nws-stream/alerts`);
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error(`NWS Proxy returned ${response.status}:`, errorData);
      
      // If we have stale cache and proxy fails, return stale cache as fallback
      if (alertCache) {
        console.warn("Serving stale NWS data from client cache due to proxy failure.");
        return alertCache.data;
      }
      return null;
    }

    const data = await response.json();
    const features = data.features || [];
    
    // Update client cache
    alertCache = { data: features, timestamp: Date.now() };
    
    return features;
  } catch (error) {
    console.error("NWS Proxy Fetch Error:", error);
    // Fallback to stale cache
    if (alertCache) return alertCache.data;
    return null;
  }
}

export async function syncFlashpoints() {
  const alerts = await fetchActiveNWSAlerts();
  if (alerts === null) {
     console.warn("NWS Sync aborted due to fetch failure.");
     return;
  }
  
  const highStakesEvents = alerts.filter(alert => {
    const event = alert.properties.event.toLowerCase();
    const severity = alert.properties.severity.toLowerCase();

    // STRICT FILTER: Only convective severe weather as requested (Severe Storms, Thunderstorms, Tornadoes)
    const isTargetType = 
      event.includes('thunderstorm') || 
      event.includes('tornado') || 
      event.includes('severe storm') ||
      event.includes('squall') ||
      event.includes('flash flood');
    
    // Priority level: Only show if it's a Warning, Watch, or Emergency
    const isPriority = 
      event.includes('warning') || 
      event.includes('watch') || 
      event.includes('emergency');

    const isHighStakes = isTargetType && isPriority;
    
    return isHighStakes;
  });

  if (highStakesEvents.length === 0) return;

  // 1. Mark existing flashpoints that are no longer in the high-stakes feed as inactive
  const activeQuery = query(collection(db, 'flashpoints'), where('isActive', '==', true));
  const activeSnap = await getDocs(activeQuery);
  const currentNwsIds = new Set(highStakesEvents.map(a => a.id));
  console.log(`Currently have ${activeSnap.size} active flashpoints in local DB.`);

  for (const docSnap of activeSnap.docs) {
    const data = docSnap.data();
    const isExpired = data.expires ? new Date(data.expires) < new Date() : false;

    if (!currentNwsIds.has(data.nwsId) || isExpired) {
      await updateDoc(doc(db, 'flashpoints', docSnap.id), {
        isActive: false
      });
    }
  }

  // 2. Process new alerts
  const newAlerts: any[] = [];

  for (const alert of highStakesEvents) {
    const nwsId = alert.id;
    
    // Check if we already registered this flashpoint
    const q = query(collection(db, 'flashpoints'), where('nwsId', '==', nwsId));
    const snap = await getDocs(q);
    
    if (snap.empty) {
      newAlerts.push(alert);
      // Extract a representative point from geometry
      let lat = 39.8283; // Default center of US
      let lon = -98.5795;
      
      if (alert.geometry && alert.geometry.type === 'Polygon') {
        const coords = alert.geometry.coordinates[0];
        const sum = coords.reduce((acc: any, curr: any) => [acc[0] + curr[1], acc[1] + curr[0]], [0, 0]);
        lat = sum[0] / coords.length;
        lon = sum[1] / coords.length;
      } else if (alert.geometry && alert.geometry.type === 'MultiPolygon') {
        const coords = alert.geometry.coordinates[0][0];
        const sum = coords.reduce((acc: any, curr: any) => [acc[0] + curr[1], acc[1] + curr[0]], [0, 0]);
        lat = sum[0] / coords.length;
        lon = sum[1] / coords.length;
      }

      const displayArea = alert.properties.areaDesc || alert.properties.description?.split('\n')[0]?.split('...')[0]?.slice(0, 100) || 'Active Alert Area';
      
      // Create new Flashpoint
      try {
        await addDoc(collection(db, 'flashpoints'), {
          nwsId,
          event: alert.properties.event,
          location: displayArea, // Readable name
          areaDesc: alert.properties.areaDesc,
          severity: alert.properties.severity,
          urgency: alert.properties.urgency,
          certainty: alert.properties.certainty || 'Unknown',
          description: alert.properties.description,
          instruction: alert.properties.instruction || null,
          headline: alert.properties.parameters?.NWSheadline?.[0] || null,
          expires: alert.properties.expires,
          effective: alert.properties.effective || null,
          locationCoord: new GeoPoint(lat, lon), // Coordinates
          isActive: true,
          createdAt: serverTimestamp()
        });
      } catch (err: any) {
        if (err.code === '23505' || err.message?.includes('duplicate key')) {
          console.warn(`Flashpoint ${nwsId} already exists, skipping.`);
        } else {
          console.error("Error creating flashpoint:", err);
        }
      }
    } else {
      // Update existing ones to ensure they have the full data
      try {
        const docId = snap.docs[0].id;
        await updateDoc(doc(db, 'flashpoints', docId), {
          event: alert.properties.event,
          severity: alert.properties.severity,
          urgency: alert.properties.urgency,
          certainty: alert.properties.certainty || 'Unknown',
          description: alert.properties.description,
          instruction: alert.properties.instruction || null,
          headline: alert.properties.parameters?.NWSheadline?.[0] || null,
          expires: alert.properties.expires,
          effective: alert.properties.effective || null,
          isActive: true // Ensure it stays active if we just saw it in the feed
        });
      } catch (err) {
        console.error("Error updating existing flashpoint:", err);
      }
    }
  }

  // 3. Consolidated Notification
  if (newAlerts.length > 0) {
    playAlertSound();
    if (newAlerts.length === 1) {
      const alert = newAlerts[0];
      const displayArea = alert.properties.areaDesc || 'Active Sector';
      broadcastNotification(
        `SEVERE ALERT: ${alert.properties.event}`,
        `New threat detected in ${displayArea.split(';')[0]}. Strategic intercept window open.`
      );
    } else {
      const eventTypes = Array.from(new Set(newAlerts.map(a => a.properties.event)));
      const typeSummary = eventTypes.length === 1 ? eventTypes[0] : "Multiple threats";
      broadcastNotification(
        `MULTIPLE SEVERE ALERTS`,
        `${newAlerts.length} new ${typeSummary.toLowerCase()} cells detected. Major atmospheric instability.`
      );
    }
  }
}

let threatCache: { data: any, timestamp: number } | null = null;
const THREAT_CACHE_TTL = 60000; // 1 minute threat level cache

export async function getGlobalThreatLevel() {
  if (threatCache && (Date.now() - threatCache.timestamp < THREAT_CACHE_TTL)) {
    return threatCache.data;
  }

  const alerts = await fetchActiveNWSAlerts();
  if (!alerts) {
    if (threatCache) return threatCache.data;
    return { level: 3, label: 'STABLE', color: 'text-emerald-500', description: 'Sensor connection interrupted. Monitoring via primary backup.' };
  }
  
  const extremeCount = alerts.filter(a => a.properties.severity === 'Extreme').length;
  const severeCount = alerts.filter(a => a.properties.severity === 'Severe').length;
  
  let result;
  if (extremeCount > 5) {
    result = { level: 1, label: 'CRITICAL', color: 'text-red-600', description: 'Significant hazardous condition density reported across multiple sectors.' };
  } else if (extremeCount > 0 || severeCount > 10) {
    result = { level: 2, label: 'ELEVATED', color: 'text-amber-500', description: 'Active severe weather clusters detected. High precision required.' };
  } else {
    result = { level: 3, label: 'STABLE', color: 'text-emerald-500', description: 'Standard atmospheric flow. No immediate severe warnings overhead.' };
  }

  threatCache = { data: result, timestamp: Date.now() };
  return result;
}
