import { GoogleGenAI, Type } from "@google/genai";

// Standardized model identifier for mission intelligence
const CORE_MODEL = "gemini-3-flash-preview";

// Initialize AI directly (platform provides process.env.GEMINI_API_KEY to frontend)
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

// Direct client-side intelligence caller
async function callAI(contents: string, config?: any) {
  try {
    const response = await ai.models.generateContent({
      model: CORE_MODEL,
      contents,
      config: config || { responseMimeType: "application/json" }
    });

    if (!response.text) {
      throw new Error("Intelligence core returned an empty signal.");
    }

    return response.text;
  } catch (error: any) {
    console.error("[INTELLIGENCE ERROR]", error);
    // Standardized high-stakes error message
    throw new Error(`Atmospheric Intelligence Sync Failed: ${error.message || 'Unknown protocol error'}`);
  }
}

export interface WeatherGrade {
  score: number;
  feedback: string;
}

export interface WeeklyInsight {
  insight: string;
  precisionDelta: number;
  pros: string[];
  cons: string[];
}

/**
 * AI Assessment: Grades a forecast based on model-based verification
 */
export async function getModelGrade(params: {
  location: string;
  date: string;
  highTemp: number;
  lowTemp: number;
  condition: string;
  reasoning?: string;
  extraFields?: any;
}): Promise<WeatherGrade> {
  const { location, date, highTemp, lowTemp, condition, reasoning, extraFields } = params;
  const prompt = `
    Verify a high-stakes weather forecast against atmospheric potential.
    
    LOCATION: ${location}
    DATE: ${date}
    
    USER FORECAST:
    - High Temp: ${highTemp}°F
    - Low Temp: ${lowTemp}°F
    - Condition: ${condition}
    - Logic: ${reasoning || 'No logic provided'}
    - Extras: ${JSON.stringify(extraFields || {})}
    
    AUTHENTICATION PROTOCOL:
    1. Assess if the temperature range aligns with historical/model potential.
    2. Evaluate the reasoning for scientific depth.
    
    Return JSON with properties: "score" (0-100) and "feedback" (concise, professional).
  `;

  try {
    const text = await callAI(prompt, {
      responseMimeType: "application/json",
      tools: [{ googleSearch: {} }],
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          feedback: { type: Type.STRING },
        },
        required: ["score", "feedback"],
      },
    });

    const result = JSON.parse(text || '{}');
    return {
      score: result.score,
      feedback: result.feedback,
    };
  } catch (error: any) {
    console.error("Gemini grading error:", error);
    throw new Error(`AI Grading Failed: ${error.message || "Unknown intelligence failure"}`);
  }
}

// Alias for migration compatibility
export const getAIGrade = getModelGrade;

/**
 * Historical Validation: Grades based on actual historical data once the event passes
 */
export async function getActualGrade(params: {
  forecast?: any;
  location?: string;
  targetDate?: string;
  highTemp?: number;
  lowTemp?: number;
  predictedCondition?: string;
  extraFields?: any;
}): Promise<any> {
  const { forecast, location, targetDate, highTemp, lowTemp, predictedCondition, extraFields } = params;
  
  // Backward compatibility: If 1st param is string, it might be the old format (location, date, high, low, condition, extras)
  // But since I control the call sites, I'll just fix call sites.
  
  const loc = location || forecast?.location;
  const date = targetDate || forecast?.targetDate;
  const mode = forecast?.forecastMode || extraFields?.forecastMode || 'standard';

  const prompt = `
    ACTUAL DATA SEARCH: Find the actual weather results for ${loc} on ${date}.
    USER FORECAST: ${highTemp || forecast?.highTemp}°F high, ${lowTemp || forecast?.lowTemp}°F low, ${predictedCondition || forecast?.predictedCondition}.
    FORCAST MODALITY: ${mode.toUpperCase()}
    ${mode === 'tactical' ? `RISK PROFILE: Min ${forecast?.riskProfile?.min}°F, Max ${forecast?.riskProfile?.max}°F, Expected ${forecast?.riskProfile?.expected}°F.` : ''}
    
    GRADING MODALITY SELECTION:
    1. IF mode == "STANDARD":
       - Evaluate using Linear Proximity. Pure accuracy.
       - Focus the "feedback" on basic cause-and-effect (e.g., "The front arrived late, keeping temps higher").
    
    2. IF mode == "TACTICAL":
       - Evaluate using Acme Distribution Logic (Accuracy + Risk).
       - SHARPNESS CHECK: If the user provided a narrow spread (< 3 degrees between Min/Max) and the actual temp was within that spread, grant a "Precision Operative" bonus (+15 points).
       - CALIBRATION CHECK: If the actual telemetry falls in the "tails" of their predicted curve (outside the provided Min/Max), apply the "Overconfidence Penalty" (Lower the score significantly).
       - Focus the "feedback" on mesoscale nuances (e.g., "The CAPE was sufficient, but the capping inversion held").

    MISSION DIRECTIVE: Verify using best available regional historical data (Search Grounding).

    Return JSON with:
    "score" (0-100), "feedback" (comparison), "actualHigh", "actualLow", "actualCondition", "isHistoryAvailable" (boolean),
    "silverLining" (optional string - if the score is below 65, provide a technical 1-sentence note explaining why humans/models both struggled).

    ${mode === 'tactical' ? 'IMPORTANT: Weight the score heavily on the Ground Truth falling within the provided Min/Max range and the sharpness of the prediction.' : ''}
  `;

  try {
    const text = await callAI(prompt, {
      responseMimeType: "application/json",
      tools: [{ googleSearch: {} }],
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          feedback: { type: Type.STRING },
          actualHigh: { type: Type.NUMBER },
          actualLow: { type: Type.NUMBER },
          actualCondition: { type: Type.STRING },
          isHistoryAvailable: { type: Type.BOOLEAN },
          silverLining: { type: Type.STRING }
        },
        required: ["score", "feedback", "actualHigh", "actualLow", "actualCondition", "isHistoryAvailable"],
      },
    });

    return JSON.parse(text || '{}');
  } catch (error: any) {
    console.error("Gemini history error:", error);
    throw new Error(`History sync failed: ${error.message}`);
  }
}

// Alias
export const getActualHistoricalGrade = getActualGrade;

/**
 * Weekly Debrief Generation
 */
export async function getWeeklyDebrief(
  forecasts: any[],
  avgScore?: number
): Promise<WeeklyInsight> {
  const prompt = `Analyze this week's forecasting performance. ${avgScore !== undefined ? `(Avg Score: ${avgScore})` : ''}
    Forecasts: ${JSON.stringify(forecasts)}
    Return JSON with "insight", "precisionDelta" (number), "pros" (array), "cons" (array).`;

  try {
    const text = await callAI(prompt, {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          insight: { type: Type.STRING },
          precisionDelta: { type: Type.NUMBER },
          pros: { type: Type.ARRAY, items: { type: Type.STRING } },
          cons: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["insight", "precisionDelta", "pros", "cons"],
      },
    });
    
    return JSON.parse(text || '{}');
  } catch (error: any) {
    console.error("AI Debrief failed", error);
    return {
      insight: "Weekly report processing delayed due to model backlog.",
      precisionDelta: 0,
      pros: ["Analysis Pending"],
      cons: ["System Busy"]
    };
  }
}

// Alias
export const getWeeklyDebriefAI = getWeeklyDebrief;

/**
 * Mission Generation
 */
export async function generateMissionInfo(storm: any): Promise<{ title: string, description: string }> {
  const prompt = `
    TASK: Generate a high-fidelity meteorological mission briefing for a specific severe weather event.
    EVENT: ${storm.event} in ${storm.location}.
    TIMESTAMP: ${new Date().toISOString()}
    
    GUIDELINES:
    1. AVOID generic "Intelligence Bureau" flavor text like "initialize precision protocols" or "atmospheric disturbance detected" if it lacks real data.
    2. USE real meteorological context. Reference actual upcoming threats, regional impacts, or scientific components (e.g. convective potential, pressure gradients).
    3. The tone must be professional, technical, and data-driven.
    
    Return as JSON: { "title": "REAL_TITLE", "description": "REAL_TECHNICAL_DESCRIPTION" }
  `;

  try {
    const text = await callAI(prompt, {
      responseMimeType: "application/json",
      tools: [{ googleSearch: {} }],
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING }
        },
        required: ["title", "description"]
      }
    });

    return JSON.parse(text || '{}');
  } catch (error) {
    console.error("Mission Generation Error:", error);
    return { title: `Mission: ${storm.event}`, description: `Detailed scientific tracking and verification of ${storm.event} systems impacting ${storm.location}. Focus on precision grading and spatial variance analysis.` };
  }
}

// Alias
export const generateLiveMission = generateMissionInfo;

/**
 * Deep Dive Post-Game Analysis
 */
export async function getDeepDiveAnalysis(forecast: any): Promise<any> {
   const prompt = `
      PERFORM: DEEP DIVE POST-GAME ANALYSIS.
      ANALYST FORECAST: ${JSON.stringify(forecast)}
      
      GOAL: Provide a strictly real meteorological intelligence report on why the analyst succeeded or failed. 
      Use exact values for the target date/location by searching for the ACTUAL weather observed.
      Avoid "neural uplink" flavor if it detracts from technical precision.
      
      OUTPUT: JSON with:
      - "overallScore": Calculate a final Precision Index (0-100) based on how accurate the forecast was against reality using all available data metrics. Grade it rigorously.
      - "summary": A 2-3 sentence technical briefing based on real findings.
      - "breakdown": Array of { "label": "Temp/Wind/Cond", "score": 0-100, "delta": number, "diagnostic": "brief technical note" }
      - "telemetry": Array of 3 specific meteorological "anomalies" or data points detected in the real verification data.
      - "rank": "S", "A", "B", "C", "D"
      - "recommendation": One specific strategic adjustment for the analyst.
      - "protocolCode": A technical serial number (e.g. "REV-2024-X").
      - "processTime": string like "0.42ms"
   `;

   try {
      const text = await callAI(prompt, {
         responseMimeType: "application/json",
         tools: [{ googleSearch: {} }],
         responseSchema: {
            type: Type.OBJECT,
            properties: {
               overallScore: { type: Type.NUMBER },
               summary: { type: Type.STRING },
               breakdown: {
                  type: Type.ARRAY,
                  items: {
                     type: Type.OBJECT,
                     properties: {
                        label: { type: Type.STRING },
                        score: { type: Type.NUMBER },
                        delta: { type: Type.NUMBER },
                        diagnostic: { type: Type.STRING }
                     },
                     required: ["label", "score", "delta", "diagnostic"]
                  }
               },
               telemetry: { type: Type.ARRAY, items: { type: Type.STRING } },
               rank: { type: Type.STRING },
               recommendation: { type: Type.STRING },
               protocolCode: { type: Type.STRING },
               processTime: { type: Type.STRING }
            },
            required: ["overallScore", "summary", "breakdown", "telemetry", "rank", "recommendation", "protocolCode", "processTime"]
         }
      });
      return JSON.parse(text || '{}');
   } catch (error: any) {
      console.error("Deep Dive failed", error);
      throw new Error(`Technical Deep Dive failed: ${error.message}`);
   }
}

/**
 * Mission Telemetry Injection: Provides real-time atmospheric data search for Pro users
 */
export async function getMissionTelemetry(mission: any): Promise<any> {
  const prompt = `
    TASK: RETRIEVE ARCHIVAL ATMOSPHERIC TELEMETRY.
    MISSION: ${mission.title}
    WINDOW: ${mission.start_date || mission.startDate} to ${mission.end_date || mission.endDate}
    CONTEXT: ${mission.description}
    
    SEARCH REQUIREMENTS: 
    1. Search for REAL meteorological data, NWS logs, SPC bulletins, or observed satellite trends corresponding to this EXACT mission window.
    2. Extract strictly high-fidelity, real-world data points (e.g. "Surface pressure dropped to 994mb", "Winds gusted to 58kt at KORD", "CAPE values reached 3500 J/kg").
    3. NO placeholder text. If no specific data is found for the exact minute, provide the broader verified event context for that day/hour.
    
    Return JSON with:
    - "findings": Array of 5-8 REAL "archival logs" with timestamps (e.g. "[18:00Z] Storm reports indicate hail up to 1.5 inches...").
    - "summary": A dense, technical summary of the atmospheric situation during this window.
    - "dataPoints": Object with categories ("Atmos_Kinematics", "Surface_Dynamics", "Moisture_Profiles") and their real values.
    - "status": "COORDINATED_VERIFICATION"
  `;

  try {
    const text = await callAI(prompt, {
      responseMimeType: "application/json",
      tools: [{ googleSearch: {} }],
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          findings: { type: Type.ARRAY, items: { type: Type.STRING } },
          summary: { type: Type.STRING },
          dataPoints: { 
            type: Type.OBJECT,
            properties: {
              Atmos_Kinematics: { type: Type.STRING },
              Surface_Dynamics: { type: Type.STRING },
              Moisture_Profiles: { type: Type.STRING }
            },
            required: ["Atmos_Kinematics", "Surface_Dynamics", "Moisture_Profiles"]
          },
          status: { type: Type.STRING }
        },
        required: ["findings", "summary", "dataPoints", "status"]
      }
    });
    return JSON.parse(text || '{}');
  } catch (error: any) {
    console.error("Telemetry fetch failed", error);
    throw new Error(`Telemetry Uplink Failed: ${error.message}`);
  }
}
