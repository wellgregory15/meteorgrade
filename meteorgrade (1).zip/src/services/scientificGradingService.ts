import { GeoPoint } from '../lib/db';

export interface FlashGroundTruth {
  peakWind?: number;
  maxHail?: number;
  tornadoConfirmed?: boolean;
  upgradeOccurred?: boolean;
}

export function parseNWSDescriptionForStats(description: string): FlashGroundTruth {
  const stats: FlashGroundTruth = {};
  const desc = description.toUpperCase();

  // Look for Wind
  const windMatch = desc.match(/WIND[^\d]*(\d+)\s*MPH/);
  if (windMatch) stats.peakWind = parseInt(windMatch[1]);

  // Look for Hail
  const hailMatch = desc.match(/HAIL[^\d]*(\d+(?:\.\d+)?)\s*IN/);
  if (hailMatch) stats.maxHail = parseFloat(hailMatch[1]);

  // Look for Tornado
  if (desc.includes('TORNADO...OBSERVED') || desc.includes('TORNADO...CONFIRMED')) {
    stats.tornadoConfirmed = true;
  } else if (desc.includes('TORNADO...RADAR INDICATED')) {
    stats.tornadoConfirmed = false; // Not "confirmed" as observed yet
  }

  return stats;
}

export function calculateFlashScientificScore(
  prediction: {
    peakWind?: number;
    maxHail?: number;
    tornadoRisk?: number;
    upgradeProb?: string;
  },
  actual: FlashGroundTruth
): { score: number; feedback: string } {
  let score = 100;
  let deductions = 0;
  const components: string[] = [];

  // Wind Grading (Weight: 30%)
  if (prediction.peakWind !== undefined && actual.peakWind !== undefined) {
    const diff = Math.abs(prediction.peakWind - actual.peakWind);
    const windDeduction = Math.min(30, (diff / actual.peakWind) * 50);
    deductions += windDeduction;
    components.push(`Wind (${actual.peakWind}mph observed vs ${prediction.peakWind}mph predicted): ${100 - Math.round(windDeduction * 3.33)}%`);
  }

  // Hail Grading (Weight: 30%)
  if (prediction.maxHail !== undefined && actual.maxHail !== undefined) {
    const diff = Math.abs(prediction.maxHail - actual.maxHail);
    const hailDeduction = Math.min(30, diff * 20); // 0.5 inch off = 10 pts
    deductions += hailDeduction;
    components.push(`Hail (${actual.maxHail}" observed vs ${prediction.maxHail}" predicted): ${100 - Math.round(hailDeduction * 3.33)}%`);
  }

  // Tornado Risk (Weight: 40%)
  if (prediction.tornadoRisk !== undefined && actual.tornadoConfirmed !== undefined) {
    const target = actual.tornadoConfirmed ? 100 : 0;
    const diff = Math.abs(prediction.tornadoRisk - target);
    const tornadoDeduction = Math.min(40, (diff / 100) * 40);
    deductions += tornadoDeduction;
    const outcomeStr = actual.tornadoConfirmed ? "Confirmed" : "None Observed";
    components.push(`Threat Detect (${outcomeStr} vs ${prediction.tornadoRisk}% risk): ${100 - Math.round(tornadoDeduction * 2.5)}%`);
  }

  score = Math.max(0, 100 - deductions);

  let feedback = `Scientific verification complete. ${components.join(' | ')}.`;
  if (components.length === 0) {
    feedback = "Telemetry analyzed. Broad meteorological parameters limit high-precision grading. Defaulting to baseline verification status.";
    score = 85; // Baseline for "on record" without specific ground truth
  }

  return { score: Math.round(score), feedback };
}
